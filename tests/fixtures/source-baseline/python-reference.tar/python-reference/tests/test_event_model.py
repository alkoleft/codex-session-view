from __future__ import annotations

import unittest

from codex_worker.event_model import EventProjector, summarize_event
from codex_worker.models import EventRecord


def make_event(event_type: str, payload: dict, ts: str = "2026-03-23T00:00:00Z") -> EventRecord:
    return EventRecord(
        schema_version=1,
        ts=ts,
        task_id="demo",
        run_id="run-1",
        seq=1,
        event_type=event_type,
        raw_type=event_type,
        parse_status="parsed",
        payload=payload,
    )


class EventModelTests(unittest.TestCase):
    def test_projector_builds_agent_tree_and_timeline(self) -> None:
        projector = EventProjector(timeline_limit=10, agent_line_limit=4)
        projector.reset_run("demo", "Demo", "run-1", "/repo")
        projector.apply_event(make_event("thread.started", {"thread_id": "parent"}))
        projector.apply_event(
            make_event(
                "tool.result",
                {
                    "tool_name": "spawn_agent",
                    "phase": "completed",
                    "status": "completed",
                    "thread_id": "parent",
                    "sender_thread_id": "parent",
                    "receiver_thread_ids": ["sub-1"],
                    "agents_states": {"sub-1": {"status": "pending_init", "message": "warming up"}},
                },
            )
        )
        projector.apply_event(
            make_event(
                "agent.session",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-1",
                    "parent_thread_id": "parent",
                    "agent_nickname": "Lovelace",
                    "agent_role": "reviewer",
                    "cwd": "/repo",
                },
            )
        )
        projector.apply_event(make_event("agent.message", {"actor_type": "subagent", "thread_id": "sub-1", "parent_thread_id": "parent", "text": "checking"}))
        projector.apply_event(make_event("tool.call", {"actor_type": "subagent", "thread_id": "sub-1", "tool_name": "exec_command"}))
        projector.apply_event(make_event("tool.result", {"actor_type": "subagent", "thread_id": "sub-1", "tool_name": "exec_command", "output": "14\n"}))

        snapshot = projector.snapshot
        self.assertEqual(snapshot.task_id, "demo")
        self.assertEqual(snapshot.root_thread_id, "parent")
        self.assertIn("parent", snapshot.agents)
        self.assertIn("sub-1", snapshot.agents)
        self.assertEqual(snapshot.agents["sub-1"].parent_thread_id, "parent")
        self.assertEqual(snapshot.agents["sub-1"].nickname, "Lovelace")
        self.assertEqual(snapshot.agents["sub-1"].role, "reviewer")
        self.assertIsNotNone(snapshot.agents["sub-1"].color)
        self.assertTrue(any("warming up" in line for line in snapshot.agents["sub-1"].recent_lines))
        self.assertTrue(any("result exec_command: 14" in line for line in snapshot.agents["sub-1"].recent_lines))
        self.assertTrue(any(entry.label.startswith("subagent: spawn_agent") for entry in snapshot.timeline))

    def test_projector_releases_subagent_color_after_completion(self) -> None:
        projector = EventProjector(timeline_limit=10, agent_line_limit=4)

        projector.apply_event(make_event("thread.started", {"thread_id": "parent"}))
        projector.apply_event(
            make_event(
                "agent.session",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-1",
                    "parent_thread_id": "parent",
                    "agent_nickname": "Lovelace",
                },
            )
        )
        claimed_color = projector.snapshot.agents["sub-1"].color

        projector.apply_event(
            make_event(
                "agent.meta",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-1",
                    "parent_thread_id": "parent",
                    "meta_type": "task_complete",
                },
            )
        )

        self.assertIsNotNone(claimed_color)
        self.assertIsNone(projector.snapshot.agents["sub-1"].color)

        projector.apply_event(
            make_event(
                "agent.session",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-2",
                    "parent_thread_id": "parent",
                    "agent_nickname": "Confucius",
                },
            )
        )

        self.assertEqual(projector.snapshot.agents["sub-2"].color, claimed_color)

    def test_summarize_event_formats_subagent_state(self) -> None:
        summary = summarize_event(
            make_event(
                "tool.result",
                {
                    "tool_name": "wait",
                    "phase": "completed",
                    "status": "completed",
                    "receiver_thread_ids": ["sub-1"],
                    "agents_states": {"sub-1": {"status": "completed", "message": "ok"}},
                },
            )
        )
        self.assertIn("subagent: wait", summary)
        self.assertIn("agents=sub-1", summary)
        self.assertIn("states=sub-1:completed", summary)

    def test_summarize_event_formats_file_change(self) -> None:
        summary = summarize_event(
            make_event(
                "file.change",
                {
                    "changes": [
                        {"kind": "update", "path": "/tmp/demo.py"},
                        {"kind": "add", "path": "/tmp/new.py"},
                    ]
                },
            )
        )
        self.assertIn("files: update", summary)
        self.assertIn("/tmp/demo.py", summary)
        self.assertIn("(+1)", summary)

    def test_summarize_event_formats_command_execution_with_command(self) -> None:
        call_summary = summarize_event(
            make_event(
                "tool.call",
                {
                    "tool_name": "command_execution",
                    "input": {"command": "git status --short"},
                },
            )
        )
        result_summary = summarize_event(
            make_event(
                "tool.result",
                {
                    "tool_name": "command_execution",
                    "input": {"command": "git status --short"},
                    "exit_code": 0,
                },
            )
        )
        self.assertEqual(call_summary, "tool: command_execution git status --short")
        self.assertEqual(result_summary, "tool result: command_execution git status --short exit=0")

    def test_summarize_event_truncates_overlong_command_lines(self) -> None:
        summary = summarize_event(
            make_event(
                "tool.call",
                {
                    "tool_name": "command_execution",
                    "input": {"command": "python -c '" + ("x" * 200) + "'"},
                },
            )
        )
        self.assertLess(len(summary), 150)
        self.assertIn("...", summary)

    def test_summarize_event_formats_web_search_result_with_query(self) -> None:
        summary = summarize_event(
            make_event(
                "tool.result",
                {
                    "tool_name": "web_search",
                    "output": {
                        "query": "https://developers.openai.com/codex/cli",
                        "action": {
                            "type": "open_page",
                            "url": "https://developers.openai.com/codex/cli",
                        },
                    },
                },
            )
        )
        self.assertIn("tool result: web_search", summary)
        self.assertIn("query=https://developers.openai.com/codex/cli", summary)
        self.assertIn("action=open_page", summary)
        self.assertIn("url=https://developers.openai.com/codex/cli", summary)

    def test_summarize_event_formats_web_search_call_without_query(self) -> None:
        summary = summarize_event(
            make_event(
                "tool.call",
                {
                    "tool_name": "web_search",
                    "input": {
                        "query": "",
                        "action": {"type": "other"},
                    },
                },
            )
        )
        self.assertEqual(summary, "tool: web_search query=<pending> action=other")

    def test_summarize_event_formats_subagent_meta_variants(self) -> None:
        user_summary = summarize_event(
            make_event(
                "agent.meta",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-1",
                    "meta_type": "user_message",
                    "text": "Inspect docs/technical-documentation.md",
                },
            )
        )
        token_summary = summarize_event(
            make_event(
                "agent.meta",
                {
                    "actor_type": "subagent",
                    "thread_id": "sub-1",
                    "meta_type": "token_count",
                    "total_tokens": 1234,
                    "rate_limits": {"primary": {"used_percent": 4.0}},
                },
            )
        )
        self.assertEqual(user_summary, "subagent[sub-1] user: Inspect docs/technical-documentation.md")
        self.assertEqual(token_summary, "subagent[sub-1] tokens total=1234 primary=4.0%")

    def test_summarize_event_formats_error_event(self) -> None:
        summary = summarize_event(
            make_event(
                "error",
                {
                    "message": "Falling back from WebSockets to HTTPS transport.",
                },
            )
        )
        self.assertEqual(summary, "error: Falling back from WebSockets to HTTPS transport.")

    def test_summarize_event_includes_text_link_context(self) -> None:
        summary = summarize_event(
            make_event(
                "error",
                {
                    "message": "Reconnecting... 2/5",
                    "text_links": {
                        "request_id": "8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec",
                        "status_code": 403,
                        "host": "chatgpt.com",
                        "cf_ray": "9e0ef7775a834d74-FRA",
                    },
                },
            )
        )
        self.assertIn("request_id=8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec", summary)
        self.assertIn("status=403", summary)
        self.assertIn("host=chatgpt.com", summary)
        self.assertIn("cf_ray=9e0ef7775a834d74-FRA", summary)

    def test_summarize_event_formats_turn_failed_with_text_links(self) -> None:
        summary = summarize_event(
            make_event(
                "agent.turn.failed",
                {
                    "error": {
                        "message": "stream disconnected before completion",
                    },
                    "text_links": {
                        "request_id": "e5bb5dbd-7494-4d6b-b105-f00335db8b6f",
                        "host": "chatgpt.com",
                    },
                },
            )
        )
        self.assertIn("agent turn failed", summary)
        self.assertIn("stream disconnected before completion", summary)
        self.assertIn("request_id=e5bb5dbd-7494-4d6b-b105-f00335db8b6f", summary)


if __name__ == "__main__":
    unittest.main()
