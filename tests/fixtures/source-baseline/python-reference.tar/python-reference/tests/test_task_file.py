from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from codex_worker.task_file import (
    TaskFileError,
    archive_snapshot_if_completed,
    claim_next_task,
    load_snapshot,
    recover_stale_tasks,
)


TASK_TEXT = """# Tasks

# [ ] First task
Body line

## nested heading is allowed

# [>] Running task
id: task-2
cwd: /tmp/work
last_heartbeat_at: 2000-01-01T00:00:00Z
lease_pid: 999999

Body
"""


class TaskFileTests(unittest.TestCase):
    def test_load_snapshot_parses_heading_delimited_tasks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(TASK_TEXT, encoding="utf-8")
            snapshot = load_snapshot(path)
            self.assertEqual(len(snapshot.tasks), 2)
            self.assertIn("nested heading is allowed", snapshot.tasks[0].body)
            self.assertEqual(snapshot.tasks[0].task_id, "first-task")

    def test_duplicate_id_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [ ] One
id: same
cwd: /tmp

X

# [ ] Two
id: same
cwd: /tmp

Y
""",
                encoding="utf-8",
            )
            with self.assertRaises(TaskFileError):
                load_snapshot(path)

    def test_free_form_body_without_metadata_is_allowed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [ ] Свободная задача
Сделай что-нибудь полезное
Потом проверь результат
""",
                encoding="utf-8",
            )
            snapshot = load_snapshot(path)
            self.assertEqual(snapshot.tasks[0].task_id, "task")
            self.assertIn("Сделай что-нибудь полезное", snapshot.tasks[0].body)

    def test_generated_id_avoids_collision_with_explicit_id(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [ ] Явная
id: task

One

# [ ] Свободная задача
Two
""",
                encoding="utf-8",
            )
            snapshot = load_snapshot(path)
            self.assertEqual([task.task_id for task in snapshot.tasks], ["task", "task-1"])

    def test_prompt_metadata_is_parsed_as_regular_task_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [ ] Task
prompt: Answer in Russian

Body
""",
                encoding="utf-8",
            )
            snapshot = load_snapshot(path)
            self.assertEqual(snapshot.tasks[0].metadata["prompt"], "Answer in Russian")
            self.assertEqual(snapshot.tasks[0].body, "Body")

    def test_multiple_non_ascii_free_form_tasks_get_unique_ids(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [ ] Первая задача
One

# [ ] Вторая задача
Two

# [ ] Третья задача
Three
""",
                encoding="utf-8",
            )
            snapshot = load_snapshot(path)
            self.assertEqual([task.task_id for task in snapshot.tasks], ["task", "task-1", "task-2"])

    def test_recover_stale_running_marks_failed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(TASK_TEXT, encoding="utf-8")
            snapshot = load_snapshot(path)
            content, recovered = recover_stale_tasks(snapshot, stale_after=1)
            self.assertEqual(recovered, ["task-2"])
            self.assertIn("worker_interrupted", content)

    def test_claim_next_task_accepts_running_status(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [>] Running
id: running-task

Resume work
""",
                encoding="utf-8",
            )
            snapshot = load_snapshot(path)
            claimed = claim_next_task(snapshot, "run-1", "worker-1")
            self.assertIsNotNone(claimed)
            assert claimed is not None
            content, task = claimed
            self.assertEqual(task.task_id, "running-task")
            self.assertIn("last_run_id: run-1", content)
            self.assertIn("lease_owner: worker-1", content)

    def test_archive_snapshot_moves_file_when_all_tasks_completed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [x] Done
id: done

Finished
""",
                encoding="utf-8",
            )
            archived_path = archive_snapshot_if_completed(path, path.read_text(encoding="utf-8"))
            self.assertEqual(archived_path, Path(tmp) / "archive" / "task.md")
            self.assertFalse(path.exists())
            assert archived_path is not None
            self.assertTrue(archived_path.exists())

    def test_archive_snapshot_skips_incomplete_tasks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "task.md"
            path.write_text(
                """# [x] Done
id: done

Finished

# [ ] Pending
id: pending

Todo
""",
                encoding="utf-8",
            )
            archived_path = archive_snapshot_if_completed(path, path.read_text(encoding="utf-8"))
            self.assertIsNone(archived_path)
            self.assertTrue(path.exists())


if __name__ == "__main__":
    unittest.main()
