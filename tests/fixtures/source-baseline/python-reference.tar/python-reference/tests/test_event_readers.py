from __future__ import annotations

import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path

from codex_worker.event_readers import EventLogFileReader, JsonOutputEventReader, RunEventContext


class JsonOutputEventReaderTests(unittest.TestCase):
    def make_reader(self) -> JsonOutputEventReader:
        return JsonOutputEventReader(RunEventContext(task_id="demo", run_id="run-1"))

    def test_reader_emits_agent_tool_and_file_event_types(self) -> None:
        reader = self.make_reader()
        seq = 0
        tool_counts: Counter[str] = Counter()
        subagent_counts: Counter[str] = Counter()
        subagent_threads: set[str] = set()

        seq, event = reader.parse_main_output_line(
            seq,
            json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}),
            tool_counts,
            subagent_counts,
            subagent_threads,
        )
        self.assertEqual(event.event_type, "agent.message")

        seq, event = reader.parse_main_output_line(
            seq,
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "type": "command_execution",
                        "id": "cmd-1",
                        "command": "git status --short",
                        "status": "completed",
                        "exit_code": 0,
                    },
                }
            ),
            tool_counts,
            subagent_counts,
            subagent_threads,
        )
        self.assertEqual(event.event_type, "tool.result")

        seq, event = reader.parse_main_output_line(
            seq,
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "type": "file_change",
                        "id": "fc-1",
                        "changes": [{"kind": "update", "path": "/tmp/demo.py"}],
                    },
                }
            ),
            tool_counts,
            subagent_counts,
            subagent_threads,
        )
        self.assertEqual(event.event_type, "file.change")

    def test_reader_emits_error_event_type_for_item_error(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "id": "item_0",
                        "type": "error",
                        "message": "Falling back from WebSockets to HTTPS transport.",
                    },
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        self.assertEqual(event.event_type, "error")
        self.assertEqual(reader.state.item_errors[0]["message"], "Falling back from WebSockets to HTTPS transport.")
        self.assertEqual(type(event.payload_obj()).__name__, "ErrorPayload")

    def test_reader_extracts_text_links_from_item_error(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "id": "item_0",
                        "type": "error",
                        "message": "Falling back from WebSockets to HTTPS transport. Please include the request ID ce2d4bff-3a69-481f-9219-7deb60d3f722 in your message.",
                    },
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        payload = event.payload_obj()
        self.assertTrue(payload.is_fallback)
        self.assertEqual(payload.fallback_from, "websocket")
        self.assertEqual(payload.fallback_to, "https")
        self.assertEqual(payload.request_id, "ce2d4bff-3a69-481f-9219-7deb60d3f722")

    def test_reader_emits_error_event_type_for_top_level_error(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "error",
                    "message": "Reconnecting... 2/5 (stream disconnected before completion)",
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        self.assertEqual(event.event_type, "error")
        self.assertEqual(event.parse_status, "parsed")
        self.assertEqual(event.payload_obj().message, "Reconnecting... 2/5 (stream disconnected before completion)")

    def test_reader_extracts_text_links_from_top_level_error(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "error",
                    "message": "Reconnecting... 2/5 (unexpected status 403 Forbidden: 154c, url: wss://chatgpt.com/backend-api/codex/responses, cf-ray: 9e0ef7775a834d74-FRA). Please include the request ID 8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec in your message.",
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        payload = event.payload_obj()
        self.assertEqual(payload.request_id, "8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec")
        self.assertEqual(payload.reconnect_attempt, 2)
        self.assertEqual(payload.reconnect_limit, 5)
        self.assertEqual(payload.text_links.status_code, 403)
        self.assertEqual(payload.text_links.status_text, "Forbidden")
        self.assertEqual(payload.text_links.url, "wss://chatgpt.com/backend-api/codex/responses")
        self.assertEqual(payload.text_links.scheme, "wss")
        self.assertEqual(payload.text_links.host, "chatgpt.com")
        self.assertEqual(payload.text_links.cf_ray, "9e0ef7775a834d74-FRA")

    def test_reader_extracts_text_links_from_turn_failed(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "turn.failed",
                    "error": {
                        "message": "stream disconnected before completion: An error occurred while processing your request. Please include the request ID e5bb5dbd-7494-4d6b-b105-f00335db8b6f in your message."
                    },
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        payload = event.payload_obj()
        self.assertEqual(event.event_type, "agent.turn.failed")
        self.assertEqual(payload.text_links.request_id, "e5bb5dbd-7494-4d6b-b105-f00335db8b6f")
        self.assertEqual(payload.text_links.disconnect_reason, "stream disconnected before completion")

    def test_reader_preserves_agent_message_id_and_text_links(self) -> None:
        reader = self.make_reader()
        _, event = reader.parse_main_output_line(
            0,
            json.dumps(
                {
                    "type": "item.completed",
                    "item": {
                        "id": "item_42",
                        "type": "agent_message",
                        "text": "See failure request ID 01234567-89ab-cdef-0123-456789abcdef.",
                    },
                }
            ),
            Counter(),
            Counter(),
            set(),
        )

        payload = event.payload_obj()
        self.assertEqual(payload.item_id, "item_42")
        self.assertEqual(payload.text_links.request_id, "01234567-89ab-cdef-0123-456789abcdef")


class EventLogFileReaderTests(unittest.TestCase):
    def test_load_events_restores_internal_namespaced_model(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "events.jsonl"
            path.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "ts": "2026-03-23T00:00:00Z",
                        "task_id": "demo",
                        "run_id": "run-1",
                        "seq": 1,
                        "event_type": "tool.result",
                        "raw_type": "item.completed",
                        "parse_status": "parsed",
                        "payload": {"tool_name": "command_execution"},
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            events = EventLogFileReader.load_events(path)

            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].event_type, "tool.result")
            self.assertEqual(type(events[0].payload_obj()).__name__, "ToolResultPayload")

    def test_load_events_restores_nested_text_links(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "events.jsonl"
            path.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "ts": "2026-03-23T00:00:00Z",
                        "task_id": "demo",
                        "run_id": "run-1",
                        "seq": 1,
                        "event_type": "error",
                        "raw_type": "error",
                        "parse_status": "parsed",
                        "payload": {
                            "message": "msg",
                            "text_links": {
                                "request_id": "8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec",
                                "status_code": 403,
                            },
                        },
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            events = EventLogFileReader.load_events(path)

            self.assertEqual(events[0].payload_obj().text_links.request_id, "8c25d52e-8391-4ef8-8ffc-ef0fdcc2b3ec")
            self.assertEqual(events[0].payload_obj().text_links.status_code, 403)


if __name__ == "__main__":
    unittest.main()
