from __future__ import annotations

import unittest
from io import StringIO
from pathlib import Path

from codex_worker.console_ui import WorkerConsole
from codex_worker.models import EventRecord, WorkerConfig


class WorkerConsoleTests(unittest.TestCase):
    TS = "2026-03-24T09:41:00Z"

    def make_console(self) -> WorkerConsole:
        return WorkerConsole(WorkerConfig(task_file=Path("tasks.md"), poll_interval=1.0))

    def test_status_line_uses_compact_infographic_format(self) -> None:
        console = self.make_console()
        console.projector.set_claimed("task", "Переработай строку состояния", "f369e241-8c5f-46e7-984b-35f81ee3d0db")
        console._update_status_line()

        self.assertEqual(console.status_line, "◔ claim · Переработай строку состояния · #f369e241")
        self.assertNotIn("status:", console.status_line)
        self.assertNotIn("task:", console.status_line)
        self.assertNotIn("run:", console.status_line)

    def test_status_line_falls_back_to_status_badge_only(self) -> None:
        console = self.make_console()
        console.projector.set_status("idle")
        console._update_status_line()

        self.assertEqual(console.status_line, "○ idle")

    def test_on_result_prints_task_title_in_finish_banner(self) -> None:
        console = self.make_console()
        stream = StringIO()
        console.console.file = stream
        console.status_enabled = False

        console.on_result("task-1", "Починить оформление завершения", "run-123", "completed")

        output = stream.getvalue()
        self.assertIn("○ Задача завершена:", output)
        self.assertIn("Починить оформление завершения", output)
        self.assertIn("id=task-1", output)
        self.assertIn("run=run-123", output)
        self.assertIn("status=completed", output)

    def test_on_claim_prints_task_title_in_start_banner(self) -> None:
        console = self.make_console()
        stream = StringIO()
        console.console.file = stream
        console.status_enabled = False

        console.on_claim(type("Task", (), {"task_id": "task-1", "title": "Починить оформление начала"})(), "run-123")

        output = stream.getvalue()
        self.assertIn("○ Задача взята в работу:", output)
        self.assertIn("Починить оформление начала", output)
        self.assertIn("id=task-1", output)
        self.assertIn("run=run-123", output)

    def test_assistant_messages_render_as_timeline_rows(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="agent.message",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "text": "Сообщение ассистента"},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ assistant: Сообщение ассистента")
        self.assertEqual(rendered.spans[-1].style, "white")

    def test_tool_events_render_as_timeline_rows(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="tool.call",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "tool_name": "exec_command"},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ tool: exec_command")
        styles = [span.style for span in rendered.spans]
        self.assertIn("bold cyan", styles)
        self.assertIn("bold white", styles)

    def test_web_search_event_bolds_structured_prefix(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="tool.call",
            raw_type="",
            parse_status="parsed",
            payload={
                "actor_type": "agent",
                "thread_id": "root",
                "tool_name": "web_search",
                "input": {"query": "", "action": {"type": "other"}},
            },
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ tool: web_search query=<pending> action=other")
        self.assertEqual(rendered.spans[1].style, "bold white")

    def test_multiline_tool_commands_render_with_timeline_continuation(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="tool.call",
            raw_type="",
            parse_status="parsed",
            payload={
                "actor_type": "agent",
                "thread_id": "root",
                "tool_name": "command_execution",
                "input": {
                    "command": "/bin/bash -lc \"python3 - <<'PY'\nfrom pathlib import Path\nprint(Path.cwd())\nPY\""
                },
            },
        )

        rendered = console._format_event_line(event)

        self.assertEqual(
            rendered.plain,
            "○ tool: command_execution /bin/bash -lc \"python3 - <<'PY'\n"
            "│   from pathlib import Path\n"
            "│   print(Path.cwd())\n"
            "│   PY\"",
        )
        styles = [span.style for span in rendered.spans]
        self.assertIn("bold cyan", styles)
        self.assertIn("white", styles)

    def test_tool_results_render_as_success_timeline_rows(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=2,
            event_type="tool.result",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "tool_name": "exec_command", "exit_code": 0},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ tool result: exec_command exit=0")
        styles = [span.style for span in rendered.spans]
        self.assertIn("bold cyan", styles)
        self.assertIn("white", styles)

    def test_tool_results_use_red_badge_for_failed_exit_code(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=2,
            event_type="tool.result",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "tool_name": "exec_command", "exit_code": 1, "stderr": "permission denied"},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ tool result: exec_command exit=1 -> permission denied")
        styles = [span.style for span in rendered.spans]
        self.assertIn("bold red", styles)
        self.assertIn("white", styles)

    def test_file_add_changes_render_as_timeline_rows(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="file.change",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "changes": [{"kind": "add", "path": "src/codex_worker/console_ui.py"}]},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ files: add src/codex_worker/console_ui.py")
        self.assertIn("bold blue", [span.style for span in rendered.spans])

    def test_file_update_changes_render_as_timeline_rows(self) -> None:
        console = self.make_console()
        event = EventRecord(
            schema_version=1,
            ts=self.TS,
            task_id="task-1",
            run_id="run-1",
            seq=1,
            event_type="file.change",
            raw_type="",
            parse_status="parsed",
            payload={"actor_type": "agent", "thread_id": "root", "changes": [{"kind": "updated", "path": "src/codex_worker/console_ui.py"}]},
        )

        rendered = console._format_event_line(event)

        self.assertEqual(rendered.plain, "○ files: updated src/codex_worker/console_ui.py")
        self.assertIn("bold blue", [span.style for span in rendered.spans])



if __name__ == "__main__":
    unittest.main()
