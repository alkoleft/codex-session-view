from __future__ import annotations

import os
import io
import json
import tempfile
import textwrap
import time
import unittest
from collections import Counter
from contextlib import redirect_stderr, redirect_stdout
from datetime import date
from pathlib import Path

from codex_worker.cli import main as cli_main
from codex_worker.logs import RunPaths
from codex_worker.models import WorkerConfig
from codex_worker.runner import CodexWorker


def write_fake_codex(path: Path, script: str) -> None:
    path.write_text(script, encoding="utf-8")
    path.chmod(0o755)


class RunnerTests(unittest.TestCase):
    def _resolved_task_file(self, worker: CodexWorker, task_file: Path) -> Path:
        return worker.config.task_file if worker.config.task_file.exists() else task_file

    def test_cli_missing_task_file_is_reported_without_traceback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            missing = root / "missing-task.md"
            buffer = io.StringIO()
            with redirect_stderr(buffer):
                exit_code = cli_main(["run-next", "--task-file", str(missing), "--quiet"])
            output = buffer.getvalue()
            self.assertEqual(exit_code, 1)
            self.assertIn("codex-worker error", output)
            self.assertIn("Task file was not found.", output)
            self.assertIn(str(missing), output)
            self.assertIn("--task-file", output)
            self.assertNotIn("Traceback", output)

    def test_successful_run_completes_task_and_writes_logs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "tool_use", "id": "a1", "name": "spawn_agent", "input": {"task": "review"}}}))
print(json.dumps({"type": "turn.completed"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "done"}}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            content = self._resolved_task_file(worker, task_file).read_text(encoding="utf-8")
            self.assertIn("## [x] Demo", content)
            self.assertIn("last_result: success", content)
            logs_root = root / ".codex-worker"
            self.assertTrue(any(logs_root.rglob("summary.json")))
            events = next(logs_root.rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "tool.call"', events)
            summary = next(logs_root.rglob("summary.json")).read_text(encoding="utf-8")
            self.assertIn('"spawn_agent": 1', summary)

    def test_task_prompt_metadata_is_appended_to_built_prompt(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}
                    prompt: Always answer in Russian

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
prompt = sys.stdin.read()
if "Additional Instructions:\\nAlways answer in Russian" not in prompt:
    sys.exit(7)
if "Task Metadata:\\nid: demo" not in prompt:
    sys.exit(8)
if "prompt: Always answer in Russian" in prompt:
    sys.exit(9)
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            content = self._resolved_task_file(worker, task_file).read_text(encoding="utf-8")
            self.assertIn("prompt: Always answer in Russian", content)
            prompt_path = next((root / ".codex-worker").rglob("prompt.md"))
            built_prompt = prompt_path.read_text(encoding="utf-8")
            self.assertIn("Additional Instructions:\nAlways answer in Russian", built_prompt)
            self.assertNotIn("prompt: Always answer in Russian", built_prompt)

    def test_successful_run_archives_task_file_when_all_tasks_completed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "done"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            archived_task_file = root / "archive" / "task.md"
            self.assertFalse(task_file.exists())
            self.assertTrue(archived_task_file.exists())
            self.assertEqual(worker.config.task_file, archived_task_file)
            content = archived_task_file.read_text(encoding="utf-8")
            self.assertIn("## [x] Demo", content)

    def test_real_codex_event_order_succeeds_when_agent_message_precedes_turn_completed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            content = self._resolved_task_file(worker, task_file).read_text(encoding="utf-8")
            self.assertIn("## [x] Demo", content)

    def test_invalid_json_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import sys
_ = sys.stdin.read()
print('{"type":"thread.started"}')
print('{bad json')
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 1)
            content = task_file.read_text(encoding="utf-8")
            self.assertIn("## [!] Demo", content)
            self.assertIn("last_result: runtime_output_invalid", content)
            raw_unparsed = next((root / ".codex-worker").rglob("raw_unparsed/main.jsonl"))
            self.assertTrue(raw_unparsed.exists())
            self.assertIn('"event_type": "raw.unparsed"', raw_unparsed.read_text(encoding="utf-8"))
            problem_examples = next((root / ".codex-worker").rglob("problem_examples/main.jsonl"))
            self.assertTrue(problem_examples.exists())
            self.assertIn('"event_type": "raw.unparsed"', problem_examples.read_text(encoding="utf-8"))

    def test_connection_failure_is_classified_in_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Trigger connection failure
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "error", "message": "Reconnecting... 2/5 (unexpected status 403 Forbidden, url: wss://chatgpt.com/backend-api/codex/responses)"}))
print("2026-03-23T16:38:10.171205Z ERROR codex_api::endpoint::responses_websocket: failed to connect to websocket: HTTP error: 403 Forbidden, url: wss://chatgpt.com/backend-api/codex/responses", file=sys.stderr)
sys.exit(1)
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30, log_to_stdout=False))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 1)
            summary_path = next((root / ".codex-worker").rglob("summary.json"))
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            self.assertEqual(summary["failure_reason"], "connection_error")
            self.assertEqual(summary["failure_analysis"]["category"], "authz_forbidden")
            self.assertEqual(summary["failure_analysis"]["http_status"], 403)
            self.assertEqual(
                summary["failure_analysis"]["endpoint"],
                "wss://chatgpt.com/backend-api/codex/responses",
            )
            self.assertEqual(summary["failure_analysis"]["hosts"], ["chatgpt.com"])

    def test_connection_failure_is_classified_from_problem_examples_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Trigger connection failure from problem examples
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "error", "message": "Reconnecting... 2/5 (unexpected status 403 Forbidden: 154c, url: wss://chatgpt.com/backend-api/codex/responses)"}))
sys.exit(1)
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30, log_to_stdout=False))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 1)
            summary_path = next((root / ".codex-worker").rglob("summary.json"))
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            self.assertEqual(summary["failure_reason"], "connection_error")
            self.assertEqual(summary["failure_analysis"]["category"], "authz_forbidden")
            self.assertEqual(summary["failure_analysis"]["hosts"], ["chatgpt.com"])
            self.assertEqual(summary["failure_analysis"]["endpoints"], ["wss://chatgpt.com/backend-api/codex/responses"])
            self.assertEqual(len(summary["failure_analysis"]["failure_chain"]), 1)
            self.assertEqual(summary["failure_analysis"]["failure_chain"][0]["status_code"], 403)
            self.assertEqual(summary["failure_analysis"]["incident_groups"][0]["count"], 1)

            problem_examples = next((root / ".codex-worker").rglob("problem_examples/main.jsonl"))
            self.assertIn('"raw_type": "error"', problem_examples.read_text(encoding="utf-8"))

    def test_connection_failure_with_https_fallback_is_classified_from_problem_examples_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Trigger websocket 403 with HTTPS fallback 403
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "error", "message": "Reconnecting... 2/5 (unexpected status 403 Forbidden: 154c, url: wss://chatgpt.com/backend-api/codex/responses, cf-ray: 9e0ef7775a834d74-FRA)"}))
print(json.dumps({"type": "error", "message": "Reconnecting... 3/5 (unexpected status 403 Forbidden: 154c, url: wss://chatgpt.com/backend-api/codex/responses, cf-ray: 9e0ef77b4863e34f-VIE)"}))
print(json.dumps({"type": "item.completed", "item": {"id": "item_0", "message": "Falling back from WebSockets to HTTPS transport. unexpected status 403 Forbidden: 154c, url: wss://chatgpt.com/backend-api/codex/responses, cf-ray: 9e0ef7a3bcf41ad4-FRA", "type": "error"}}))
print(json.dumps({"type": "error", "message": "Reconnecting... 1/5 (unexpected status 403 Forbidden: <html><head><meta name=\\"viewport\\" content=\\"width=device-width, initial-scale=1\\" /></head><body>blocked</body></html>, url: https://chatgpt.com/backend-api/codex/responses, cf-ray: 9e0ef7a5ed5cd40f-FRA)"}))
sys.exit(1)
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30, log_to_stdout=False))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 1)
            summary_path = next((root / ".codex-worker").rglob("summary.json"))
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            self.assertEqual(summary["failure_reason"], "connection_error")
            self.assertEqual(summary["failure_analysis"]["category"], "authz_forbidden")
            self.assertEqual(summary["failure_analysis"]["http_status"], 403)
            self.assertEqual(
                summary["failure_analysis"]["endpoint"],
                "wss://chatgpt.com/backend-api/codex/responses",
            )
            self.assertEqual(summary["failure_analysis"]["transport"], "websocket")
            self.assertIn("9e0ef7775a834d74-FRA", summary["failure_analysis"]["cf_rays"])
            self.assertIn("chatgpt.com", summary["failure_analysis"]["hosts"])
            self.assertEqual(len(summary["failure_analysis"]["failure_chain"]), 4)
            self.assertEqual(len(summary["failure_analysis"]["incident_groups"]), 2)
            self.assertEqual(summary["failure_analysis"]["incident_groups"][0]["transport"], "websocket")
            self.assertEqual(summary["failure_analysis"]["incident_groups"][0]["count"], 3)
            self.assertEqual(summary["failure_analysis"]["incident_groups"][1]["transport"], "https")
            self.assertEqual(summary["failure_analysis"]["incident_groups"][1]["count"], 1)

            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "error"', events)
            self.assertNotIn(
                '"event_type": "raw.unparsed", "parse_status": "best_effort", "payload": {"raw": {"id": "item_0"',
                events,
            )

            problem_examples = next((root / ".codex-worker").rglob("problem_examples/main.jsonl"))
            examples_text = problem_examples.read_text(encoding="utf-8")
            self.assertIn("Falling back from WebSockets to HTTPS transport", examples_text)
            self.assertIn("https://chatgpt.com/backend-api/codex/responses", examples_text)

    def test_subagent_unparsed_events_are_copied_to_dedicated_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            codex_home = root / ".codex"
            sessions_dir = codex_home / "sessions" / "2026" / "03" / "23"
            sessions_dir.mkdir(parents=True)
            session_file = sessions_dir / "rollout-2026-03-23T03-55-30-sub-1.jsonl"
            session_file.write_text('{"timestamp":"2026-03-23T00:55:30.887Z","type":"broken"\n', encoding="utf-8")
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Use subagent
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "parent-1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"id": "item_1", "type": "collab_tool_call", "tool": "spawn_agent", "sender_thread_id": "parent-1", "receiver_thread_ids": ["sub-1"], "prompt": "check", "agents_states": {"sub-1": {"status": "completed", "message": "ok"}}, "status": "completed"}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "done"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(
                WorkerConfig(
                    task_file=task_file,
                    codex_bin=str(fake),
                    codex_home=codex_home,
                    stale_after=30,
                )
            )
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            raw_unparsed = next((root / ".codex-worker").rglob("raw_unparsed/subagents.jsonl"))
            self.assertTrue(raw_unparsed.exists())
            self.assertIn('"event_type": "raw.unparsed"', raw_unparsed.read_text(encoding="utf-8"))
            problem_examples = next((root / ".codex-worker").rglob("problem_examples/subagents.jsonl"))
            self.assertTrue(problem_examples.exists())
            self.assertIn('"event_type": "raw.unparsed"', problem_examples.read_text(encoding="utf-8"))

    def test_run_next_processes_following_task_after_success(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] First
                    id: first
                    cwd: {repo}

                    Reply with first

                    # [ ] Second
                    id: second
                    cwd: {repo}

                    Reply with second
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
prompt = sys.stdin.read()
reply = "first" if "Reply with first" in prompt else "second"
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": reply}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            content = self._resolved_task_file(worker, task_file).read_text(encoding="utf-8")
            self.assertIn("## [x] First", content)
            self.assertIn("## [x] Second", content)
            runs = sorted((root / ".codex-worker").rglob("summary.json"))
            self.assertEqual(len(runs), 2)

    def test_stdout_logging_emits_progress_lines(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Implement something
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            output = buffer.getvalue()
            self.assertEqual(exit_code, 0)
            self.assertIn("Задача взята в работу:", output)
            self.assertIn("Demo", output)
            self.assertIn("Запуск worker в", output)
            self.assertIn("assistant: ok", output)
            self.assertIn("Задача завершена:", output)
            self.assertIn("status=completed", output)

    def test_stdout_logging_shows_command_execution_command(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Run command
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"type": "command_execution", "id": "cmd-1", "command": "git status --short", "status": "in_progress"}}))
print(json.dumps({"type": "item.completed", "item": {"type": "command_execution", "id": "cmd-1", "command": "git status --short", "status": "completed", "exit_code": 0, "aggregated_output": ""}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            output = buffer.getvalue()
            self.assertEqual(exit_code, 0)
            self.assertIn("tool: command_execution git status --short", output)
            self.assertIn("tool result: command_execution git status --short exit=0", output)

    def test_collab_tool_call_is_pretty_printed_and_normalized(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Use subagent
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"id": "item_1", "type": "collab_tool_call", "tool": "spawn_agent", "sender_thread_id": "t1", "receiver_thread_ids": [], "prompt": "check", "agents_states": {}, "status": "in_progress"}}))
print(json.dumps({"type": "item.completed", "item": {"id": "item_1", "type": "collab_tool_call", "tool": "spawn_agent", "sender_thread_id": "t1", "receiver_thread_ids": ["sub-1"], "prompt": "check", "agents_states": {"sub-1": {"status": "pending_init", "message": None}}, "status": "completed"}}))
print(json.dumps({"type": "item.started", "item": {"id": "item_2", "type": "collab_tool_call", "tool": "wait", "sender_thread_id": "t1", "receiver_thread_ids": ["sub-1"], "prompt": None, "agents_states": {}, "status": "in_progress"}}))
print(json.dumps({"type": "item.completed", "item": {"id": "item_2", "type": "collab_tool_call", "tool": "wait", "sender_thread_id": "t1", "receiver_thread_ids": ["sub-1"], "prompt": None, "agents_states": {"sub-1": {"status": "completed", "message": "ok"}}, "status": "completed"}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "done"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("subagent: spawn_agent phase=started status=in_progress", output)
            self.assertIn("subagent: spawn_agent phase=completed status=completed agents=sub-1", output)
            self.assertIn("states=sub-1:pending_init", output)
            self.assertIn("subagent: wait phase=completed status=completed agents=sub-1", output)
            self.assertIn("states=sub-1:completed", output)
            self.assertIn("session missing thread_id=sub-1", output)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertNotIn("raw_unparsed", events)
            self.assertIn('"event_type": "tool.result"', events)

    def test_free_form_task_without_metadata_runs_with_default_cwd(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    """\
                    # [ ] Free form
                    Say ok
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(
                WorkerConfig(
                    task_file=task_file,
                    codex_bin=str(fake),
                    stale_after=30,
                    default_cwd=repo,
                )
            )
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            content = self._resolved_task_file(worker, task_file).read_text(encoding="utf-8")
            self.assertIn("## [x] Free form", content)

    def test_file_change_item_is_parsed_without_raw_unparsed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Report file change
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"type": "file_change", "id": "fc1", "status": "completed", "changes": [{"kind": "update", "path": "/tmp/demo.py"}]}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("○ files: update /tmp/demo.py", output)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "file.change"', events)
            self.assertNotIn('"event_type": "raw.unparsed"', events)

    def test_mcp_tool_call_item_is_parsed_without_raw_unparsed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Report mcp tool call
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"type": "mcp_tool_call", "id": "item_4", "tool": "list_mcp_resources", "server": "codex", "status": "in_progress", "arguments": {}}}))
print(json.dumps({"type": "item.completed", "item": {"type": "mcp_tool_call", "id": "item_4", "tool": "list_mcp_resources", "server": "codex", "status": "completed", "arguments": {}, "error": None, "result": {"content": [{"type": "text", "text": "{\\"resources\\":[]}"}]}}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "tool.call"', events)
            self.assertIn('"event_type": "tool.result"', events)
            self.assertIn('"tool_name": "list_mcp_resources"', events)
            self.assertNotIn('"event_type": "raw.unparsed"', events)

    def test_web_search_item_is_parsed_without_raw_unparsed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Report web search
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"type": "web_search", "id": "ws_1", "query": "", "action": {"type": "other"}}}))
print(json.dumps({"type": "item.completed", "item": {"type": "web_search", "id": "ws_1", "query": "https://developers.openai.com/codex/cli", "action": {"type": "open_page", "url": "https://developers.openai.com/codex/cli"}}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "tool.call"', events)
            self.assertIn('"event_type": "tool.result"', events)
            self.assertIn('"tool_name": "web_search"', events)
            self.assertNotIn('"event_type": "raw.unparsed"', events)

    def test_todo_list_item_events_are_parsed_without_raw_unparsed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Report todo list progress
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": False, "text": "inspect"}, {"completed": False, "text": "document"}]}}))
print(json.dumps({"type": "item.updated", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": True, "text": "inspect"}, {"completed": False, "text": "document"}]}}))
print(json.dumps({"type": "item.completed", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": True, "text": "inspect"}, {"completed": True, "text": "document"}]}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("todo started: 0/2", output)
            self.assertIn("todo updated: 1/2", output)
            self.assertIn("todo completed: 2/2", output)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "todo.update"', events)
            self.assertNotIn('"event_type": "raw.unparsed"', events)

    def test_nested_item_wrapper_todo_list_events_are_parsed_without_raw_unparsed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Report wrapped todo list progress
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "t1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.started", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": False, "text": "inspect"}, {"completed": False, "text": "document"}]}}))
print(json.dumps({"type": "item.updated", "item": {"type": "item.updated", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": True, "text": "inspect"}, {"completed": False, "text": "document"}]}}}))
print(json.dumps({"type": "item.completed", "item": {"type": "todo_list", "id": "item_5", "items": [{"completed": True, "text": "inspect"}, {"completed": True, "text": "document"}]}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "ok"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(WorkerConfig(task_file=task_file, codex_bin=str(fake), stale_after=30))
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("todo started: 0/2", output)
            self.assertIn("todo updated: 1/2", output)
            self.assertIn("todo completed: 2/2", output)
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "todo.update"', events)
            self.assertNotIn('"event_type": "raw.unparsed"', events)

    def test_imports_subagent_session_from_codex_home_and_pretty_prints_trace(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            codex_home = root / ".codex"
            sessions_dir = codex_home / "sessions" / "2026" / "03" / "23"
            sessions_dir.mkdir(parents=True)
            session_file = sessions_dir / "rollout-2026-03-23T03-55-30-sub-1.jsonl"
            session_file.write_text(
                "\n".join(
                    [
                        '{"timestamp":"2026-03-23T00:55:30.887Z","type":"session_meta","payload":{"id":"sub-1","forked_from_id":"parent-1","cwd":"'
                        + str(repo)
                        + '","source":{"subagent":{"thread_spawn":{"parent_thread_id":"parent-1","depth":1,"agent_nickname":"Lovelace","agent_role":"default"}}},"agent_nickname":"Lovelace","agent_role":"default"}}',
                        '{"timestamp":"2026-03-23T00:55:35.438Z","type":"event_msg","payload":{"type":"agent_message","message":"Проверяю файл отдельным подсчётом через терминал.","phase":"commentary"}}',
                        '{"timestamp":"2026-03-23T00:55:36.737Z","type":"response_item","payload":{"type":"function_call","name":"exec_command","arguments":"{\\"cmd\\":\\"wc -l '
                        + str(repo / "demo.txt")
                        + '\\"}","call_id":"call_1"}}',
                        '{"timestamp":"2026-03-23T00:55:36.767Z","type":"response_item","payload":{"type":"function_call_output","call_id":"call_1","output":"14\\n"}}',
                        '{"timestamp":"2026-03-23T00:55:39.131Z","type":"event_msg","payload":{"type":"agent_message","message":"14, проверил через awk.","phase":"final_answer"}}',
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Use subagent
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            write_fake_codex(
                fake,
                """#!/usr/bin/env python3
import json, sys
_ = sys.stdin.read()
print(json.dumps({"type": "thread.started", "thread_id": "parent-1"}))
print(json.dumps({"type": "turn.started"}))
print(json.dumps({"type": "item.completed", "item": {"id": "item_1", "type": "collab_tool_call", "tool": "spawn_agent", "sender_thread_id": "parent-1", "receiver_thread_ids": ["sub-1"], "prompt": "check", "agents_states": {"sub-1": {"status": "completed", "message": "14"}}, "status": "completed"}}))
print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "done"}}))
print(json.dumps({"type": "turn.completed"}))
""",
            )
            worker = CodexWorker(
                WorkerConfig(
                    task_file=task_file,
                    codex_bin=str(fake),
                    codex_home=codex_home,
                    stale_after=30,
                )
            )
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("session_imported thread_id=sub-1", output)
            self.assertIn("subagent session loaded: sub-1", output)
            self.assertIn("subagent[sub-1]: Проверяю файл отдельным подсчётом через терминал.", output)
            self.assertIn("tool exec_command", output)
            self.assertIn("result exec_command", output)
            self.assertIn("14", output)
            self.assertIn("14, проверил через awk.", output)
            imported = next((root / ".codex-worker").rglob("subagents/sub-1.jsonl"))
            self.assertTrue(imported.exists())
            events = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8")
            self.assertIn('"event_type": "agent.session"', events)
            self.assertIn('"event_type": "tool.call"', events)
            self.assertIn('"event_type": "tool.result"', events)
            self.assertIn('"event_type": "agent.message"', events)

    def test_find_session_file_uses_recent_day_dirs_without_recursive_scan(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            codex_home = root / ".codex"
            today = date.today()
            sessions_dir = codex_home / "sessions" / f"{today.year:04d}" / f"{today.month:02d}" / f"{today.day:02d}"
            sessions_dir.mkdir(parents=True)
            session_file = sessions_dir / "rollout-demo-sub-1.jsonl"
            session_file.write_text("", encoding="utf-8")
            worker = CodexWorker(
                WorkerConfig(
                    task_file=root / "task.md",
                    codex_home=codex_home,
                    stale_after=30,
                    log_to_stdout=False,
                )
            )

            original_rglob = Path.rglob

            def fail_rglob(self: Path, pattern: str):  # type: ignore[override]
                raise AssertionError(f"unexpected recursive scan for {pattern}")

            try:
                Path.rglob = fail_rglob  # type: ignore[assignment]
                found = worker._find_session_file(codex_home / "sessions", "sub-1")
            finally:
                Path.rglob = original_rglob  # type: ignore[assignment]

            self.assertEqual(found, session_file)

    def test_missing_subagent_session_lookup_is_throttled_between_sync_ticks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            codex_home = root / ".codex"
            (codex_home / "sessions").mkdir(parents=True)
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Use subagent
                    """
                ),
                encoding="utf-8",
            )
            worker = CodexWorker(
                WorkerConfig(
                    task_file=task_file,
                    codex_home=codex_home,
                    stale_after=30,
                    log_to_stdout=False,
                )
            )
            claimed = worker._claim_next_task()
            assert claimed is not None
            subagent_threads = {"sub-1"}
            session_tails = {}
            calls: list[tuple[str, bool]] = []
            original_find = worker._find_session_file
            paths = RunPaths(root / ".codex-worker", claimed.task, claimed.run_id, "2026-03-23T00:00:00Z")
            paths.ensure()

            def fake_find(sessions_root: Path, thread_id: str, exhaustive: bool = False) -> Path | None:
                calls.append((thread_id, exhaustive))
                return None

            worker._find_session_file = fake_find  # type: ignore[assignment]
            try:
                seq = worker._sync_subagent_sessions(
                    claimed,
                    paths,
                    0,
                    Counter(),
                    Counter(),
                    Counter(),
                    subagent_threads,
                    "parent-1",
                    session_tails,
                    final=False,
                )
                self.assertEqual(seq, 0)
                seq = worker._sync_subagent_sessions(
                    claimed,
                    paths,
                    seq,
                    Counter(),
                    Counter(),
                    Counter(),
                    subagent_threads,
                    "parent-1",
                    session_tails,
                    final=False,
                )
                self.assertEqual(seq, 0)
                self.assertEqual(calls, [("sub-1", False)])
            finally:
                worker._find_session_file = original_find  # type: ignore[assignment]

    def test_tails_subagent_session_live_before_parent_finishes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            codex_home = root / ".codex"
            sessions_dir = codex_home / "sessions" / "2026" / "03" / "23"
            sessions_dir.mkdir(parents=True)
            session_file = sessions_dir / "rollout-2026-03-23T03-55-30-sub-1.jsonl"
            task_file = root / "task.md"
            task_file.write_text(
                textwrap.dedent(
                    f"""\
                    # [ ] Demo
                    id: demo
                    cwd: {repo}

                    Use subagent
                    """
                ),
                encoding="utf-8",
            )
            fake = root / "fake-codex"
            script = textwrap.dedent(
                """\
                #!/usr/bin/env python3
                import json, pathlib, sys, time
                _ = sys.stdin.read()
                session_path = pathlib.Path(__SESSION_PATH__)
                session_path.parent.mkdir(parents=True, exist_ok=True)
                print(json.dumps({"type": "thread.started", "thread_id": "parent-1"}), flush=True)
                print(json.dumps({"type": "turn.started"}), flush=True)
                print(json.dumps({"type": "item.completed", "item": {"id": "item_1", "type": "collab_tool_call", "tool": "spawn_agent", "sender_thread_id": "parent-1", "receiver_thread_ids": ["sub-1"], "prompt": "check", "agents_states": {"sub-1": {"status": "in_progress", "message": None}}, "status": "completed"}}), flush=True)
                with session_path.open("a", encoding="utf-8", buffering=1) as handle:
                    handle.write(json.dumps({"timestamp":"2026-03-23T00:55:30.887Z","type":"session_meta","payload":{"id":"sub-1","forked_from_id":"parent-1","cwd":__REPO_PATH__,"source":{"subagent":{"thread_spawn":{"parent_thread_id":"parent-1","depth":1,"agent_nickname":"Lovelace","agent_role":"default"}}},"agent_nickname":"Lovelace","agent_role":"default"}}) + "\\n")
                    handle.flush()
                    time.sleep(0.35)
                    handle.write(json.dumps({"timestamp":"2026-03-23T00:55:35.438Z","type":"event_msg","payload":{"type":"agent_message","message":"live line","phase":"commentary"}}) + "\\n")
                    handle.flush()
                    time.sleep(0.35)
                    handle.write(json.dumps({"timestamp":"2026-03-23T00:55:36.737Z","type":"response_item","payload":{"type":"function_call","name":"exec_command","arguments":"{\\"cmd\\":\\"echo 14\\"}","call_id":"call_1"}}) + "\\n")
                    handle.write(json.dumps({"timestamp":"2026-03-23T00:55:36.767Z","type":"response_item","payload":{"type":"function_call_output","call_id":"call_1","output":"14\\n"}}) + "\\n")
                    handle.write(json.dumps({"timestamp":"2026-03-23T00:55:39.131Z","type":"event_msg","payload":{"type":"agent_message","message":"live done","phase":"final_answer"}}) + "\\n")
                    handle.flush()
                    time.sleep(0.35)
                print(json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "parent done"}}), flush=True)
                print(json.dumps({"type": "turn.completed"}), flush=True)
                time.sleep(0.2)
                """
            )
            script = script.replace("__SESSION_PATH__", repr(str(session_file))).replace("__REPO_PATH__", repr(str(repo)))
            write_fake_codex(
                fake,
                script,
            )
            worker = CodexWorker(
                WorkerConfig(
                    task_file=task_file,
                    codex_bin=str(fake),
                    codex_home=codex_home,
                    stale_after=30,
                )
            )
            buffer = io.StringIO()
            with redirect_stdout(buffer):
                exit_code = worker.run_next()
            self.assertEqual(exit_code, 0)
            output = buffer.getvalue()
            self.assertIn("subagent session loaded: sub-1", output)
            self.assertIn("live line", output)
            self.assertIn("live done", output)
            self.assertLess(output.index("subagent session loaded: sub-1"), output.index("agent.turn.completed"))
            events_lines = next((root / ".codex-worker").rglob("events.jsonl")).read_text(encoding="utf-8").splitlines()
            subagent_session_index = next(i for i, line in enumerate(events_lines) if '"event_type": "agent.session"' in line)
            turn_completed_index = next(i for i, line in enumerate(events_lines) if '"event_type": "agent.turn.completed"' in line)
            self.assertLess(subagent_session_index, turn_completed_index)

    def test_ignores_foreign_session_meta_in_subagent_session_file(self) -> None:
        worker = CodexWorker(WorkerConfig(task_file=Path("/tmp/nonexistent-task.md"), stale_after=30, log_to_stdout=False))
        imported_path = Path("/tmp/subagent-session.jsonl")

        own_event = worker._parse_subagent_session_line(
            task_id="demo",
            run_id="run-1",
            seq=1,
            parsed={
                "timestamp": "2026-03-23T00:55:30.887Z",
                "type": "session_meta",
                "payload": {
                    "id": "sub-1",
                    "forked_from_id": "parent-1",
                    "cwd": "/repo",
                    "source": {"subagent": {"thread_spawn": {"parent_thread_id": "parent-1"}}},
                    "agent_nickname": "Lovelace",
                    "agent_role": "default",
                },
            },
            imported_path=imported_path,
            parent_thread_id="parent-1",
            thread_id="sub-1",
            call_names={},
            tool_counts=Counter(),
            subagent_counts=Counter(),
        )

        foreign_event = worker._parse_subagent_session_line(
            task_id="demo",
            run_id="run-1",
            seq=2,
            parsed={
                "timestamp": "2026-03-23T00:55:30.888Z",
                "type": "session_meta",
                "payload": {
                    "id": "parent-1",
                    "cwd": "/repo",
                },
            },
            imported_path=imported_path,
            parent_thread_id="parent-1",
            thread_id="sub-1",
            call_names={},
            tool_counts=Counter(),
            subagent_counts=Counter(),
        )

        assert own_event is not None
        self.assertEqual(own_event.event_type, "agent.session")
        self.assertEqual(own_event.payload["thread_id"], "sub-1")
        self.assertIsNone(foreign_event)

    def test_parses_modern_subagent_session_events_from_example(self) -> None:
        worker = CodexWorker(WorkerConfig(task_file=Path("/tmp/nonexistent-task.md"), stale_after=30, log_to_stdout=False))
        imported_path = Path(
            "examples/.codex-worker/tasks/task--0ebb429f/runs/20260323T152728Z--8246a1ec-4ff0-4a4b-95d8-f7160927c9c6/subagents/019d1b51-956b-7e52-b521-1c53f10bf207.jsonl"
        )
        if not imported_path.exists():
            self.skipTest(f"missing example fixture: {imported_path}")
        call_names: dict[str, str] = {}
        tool_counts: Counter[str] = Counter()
        subagent_counts: Counter[str] = Counter()
        parsed_events = []
        for seq, line in enumerate(imported_path.read_text(encoding="utf-8").splitlines(), start=1):
            event = worker._parse_subagent_session_line(
                task_id="demo",
                run_id="run-1",
                seq=seq,
                parsed=json.loads(line),
                imported_path=imported_path,
                parent_thread_id="019d1b4e-eae7-7671-999d-9c986342b2d0",
                thread_id="019d1b51-956b-7e52-b521-1c53f10bf207",
                call_names=call_names,
                tool_counts=tool_counts,
                subagent_counts=subagent_counts,
            )
            if event is not None:
                parsed_events.append(event)

        kinds = Counter(event.event_type for event in parsed_events)
        self.assertEqual(kinds["agent.session"], 1)
        self.assertEqual(kinds["agent.message"], 11)
        self.assertEqual(kinds["tool.call"], 29)
        self.assertEqual(kinds["tool.result"], 29)
        self.assertEqual(kinds["agent.meta"], 69)

        user_message = next(
            event for event in parsed_events if event.event_type == "agent.meta" and event.payload.get("meta_type") == "user_message"
        )
        self.assertIn("Проведи ревью технической документации", str(user_message.payload.get("text")))

        assistant_response = next(
            event
            for event in parsed_events
            if event.event_type == "agent.meta"
            and event.payload.get("meta_type") == "message"
            and event.payload.get("role") == "assistant"
        )
        self.assertEqual(assistant_response.payload.get("phase"), "commentary")
        self.assertIn("Проверю `docs/technical-documentation.md`", str(assistant_response.payload.get("text")))

        token_count = next(
            event
            for event in parsed_events
            if event.event_type == "agent.meta"
            and event.payload.get("meta_type") == "token_count"
            and event.payload.get("total_tokens") is not None
        )
        self.assertEqual(token_count.payload.get("total_tokens"), 11293)

        turn_context = next(
            event for event in parsed_events if event.event_type == "agent.meta" and event.payload.get("meta_type") == "turn_context"
        )
        self.assertEqual(turn_context.payload.get("cwd"), "/home/alko/develop/open-source/ai/infrastructure/codex-worker")
        self.assertEqual(turn_context.payload.get("current_date"), "2026-03-23")
        self.assertEqual(turn_context.payload.get("timezone"), "Europe/Moscow")
        self.assertEqual(turn_context.payload.get("approval_policy"), "never")
        self.assertEqual(turn_context.payload.get("sandbox_policy_type"), "danger-full-access")
        self.assertEqual(turn_context.payload.get("model"), "gpt-5.3-codex")
        self.assertEqual(turn_context.payload.get("effort"), "high")
        self.assertEqual(turn_context.payload.get("collaboration_mode_kind"), "default")

        task_complete = next(
            event for event in parsed_events if event.event_type == "agent.meta" and event.payload.get("meta_type") == "task_complete"
        )
        self.assertIn("needs changes", str(task_complete.payload.get("last_agent_message")))

if __name__ == "__main__":
    unittest.main()
