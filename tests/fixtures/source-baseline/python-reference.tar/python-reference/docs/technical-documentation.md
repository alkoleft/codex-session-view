# Техническая документация `codex-worker`

## 1. Назначение и требования

`codex-worker` это последовательный файловый orchestration worker вокруг `codex exec`. Приложение читает markdown-task-file, атомарно захватывает первую задачу со статусом pending, запускает `codex exec --json`, нормализует поток событий в единый `EventRecord`, обновляет состояние задачи и сохраняет историю выполнения в `.codex-worker/`.

### Функциональные требования

1. Поддерживать file-based очередь задач в markdown-файле.
2. Гарантировать, что одна задача в момент времени захвачена только одним worker-процессом.
3. Поддерживать режим исполнения `run-next`: выполнить все доступные pending-задачи до первой ошибки или до опустошения очереди.
4. Передавать в `codex exec` промпт, состоящий из системного шаблона `prompts/orchestrator.md`, metadata задачи, опционального дополнительного `prompt` и её markdown-body.
5. Поддерживать явный `cwd` задачи и fallback на `--default-cwd`.
6. Фиксировать жизненный цикл выполнения:
   - claim задачи;
   - heartbeat пока дочерний процесс активен;
   - final status `completed` или `failed`;
   - восстановление stale-running задач.
7. Сохранять артефакты каждого запуска:
   - prompt;
   - stdout/stderr;
   - нормализованные события;
   - summary;
   - импортированные subagent sessions;
   - raw/problem examples для неразобранных событий.
8. Отображать live-status через Rich UI во время `run-next`.
9. Нормализовать как корневые события `codex exec`, так и события субагентов из `<codex_home>/sessions`.
10. Fail closed при некорректном runtime output: отсутствие `thread.started`, отсутствие `turn.completed`, non-zero exit, top-level error, invalid JSON, отсутствие итогового сообщения агента.

### Нефункциональные требования

1. Атомарное обновление task file через временный файл + `os.replace`.
2. Межпроцессная синхронизация через lock file и `fcntl.flock`.
3. Совместимость с Python 3.10+.
4. Минимальные внешние зависимости: runtime зависит только от `rich`.
5. Логи и summary должны быть пригодны для пост-мортема без повторного запуска задачи.

## 2. Архитектура

### Основные модули

- `src/codex_worker/cli.py`: CLI и парсинг аргументов для `run-next`.
- `src/codex_worker/runner.py`: основной orchestration loop, запуск `codex exec`, heartbeat, парсинг и запись событий, tail subagent sessions.
- `src/codex_worker/task_file.py`: парсинг markdown task file, claim/finalize/recovery, детекция конфликтов.
- `src/codex_worker/lockfile.py`: файловый lock и payload блокировки.
- `src/codex_worker/logs.py`: структура каталогов запуска и сериализация событий/summary.
- `src/codex_worker/event_model.py`: проекция event log в timeline и tree состояний агентов.
- `src/codex_worker/console_ui.py`: live terminal UI поверх `EventProjector`.

### Контракты данных

- `TaskBlock`: единица очереди, извлекаемая из markdown.
- `ClaimedTask`: task + runtime lease metadata.
- `EventRecord`: канонический внутренний формат событий.
- `RunSummary`: итог запуска, счётчики событий и пути к артефактам.
- `RunSnapshot`: агрегированное текущее состояние для live UI.

## 3. Процессы

### Основной процесс выполнения

```mermaid
flowchart TD
    A[CLI: run-next] --> B[Открыть task file lock]
    B --> C[Загрузить snapshot]
    C --> D[Восстановить stale tasks]
    D --> E{Есть pending task?}
    E -- нет --> F[Idle / sleep]
    E -- да --> G[Claim task и записать run metadata]
    G --> H[Собрать prompt]
    H --> I[Создать RunPaths и артефакты]
    I --> J[Запустить codex exec --json]
    J --> K[Потоки чтения stdout/stderr]
    J --> L[Поток heartbeat]
    K --> M[Парсинг stdout -> EventRecord]
    K --> N[stderr -> stderr_line]
    M --> O[Запись events.jsonl и UI update]
    N --> O
    O --> P[Sync subagent sessions]
    P --> Q{Процесс завершён?}
    Q -- нет --> K
    Q -- да --> R[Вычислить RunSummary и result]
    R --> S[Finalize task]
    S --> T{Все задачи done?}
    T -- да --> U[Архивировать task file]
    T -- нет --> V[Следующая задача / завершение]
```

### Процесс восстановления stale-задач

```mermaid
flowchart TD
    A[Загрузка snapshot] --> B[Найти tasks со статусом running]
    B --> C[Проверить last_heartbeat_at]
    C --> D[Проверить lease_pid через process_exists]
    D --> E{Процесс жив и heartbeat свежий?}
    E -- да --> F[Оставить task running]
    E -- нет --> G[Пометить task failed]
    G --> H[last_result=worker_interrupted]
    H --> I[last_error=stale_running_recovered]
```

## 4. Диаграмма состояний

### Состояния задачи

```mermaid
stateDiagram-v2
    [*] --> Pending
    Pending --> Running: claim_next_task
    Running --> Completed: valid run summary
    Running --> Failed: invalid runtime output / process exit / stale recovery
    Completed --> Archived: archive_snapshot_if_completed
    Failed --> [*]
    Archived --> [*]
```

### Состояния run snapshot / root agent

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Claimed: set_claimed
    Claimed --> Running: reset_run
    Running --> Completed: turn_completed
    Running --> Failed: turn_failed
```

## 5. Технические особенности реализации

### 5.1 Формат task file

Worker распознаёт задачи по heading pattern `^(?P<level>#+) \\[(?P<status>[ >x!])\\] (?P<title>.+?)\\s*$`.

Поддерживаемые статусы:

- `[ ]` pending
- `[>]` running
- `[x]` completed
- `[!]` failed

Metadata читается только из верхнего непрерывного блока строк `key: value`. Если `id` отсутствует, он генерируется из title через `slugify`, с устранением коллизий.

Зарезервированное metadata-поле `prompt` не передаётся как обычная строка metadata. Вместо этого worker добавляет его содержимое отдельным блоком `Additional Instructions:` в итоговый prompt для `codex exec`. Это позволяет задавать дополнительные инструкции выполнения на уровне конкретной задачи.

Парсер принимает задачи на любом уровне heading (`#`, `##`, `###`, ...), но при любой последующей записи `serialize_task()` нормализует заголовок задачи к форме `## [status] Title`. Исходный уровень заголовка не сохраняется.

### 5.2 Claim и conflict model

При claim worker записывает в задачу:

- `last_run_id`
- `last_started_at`
- `last_heartbeat_at`
- `last_result=running`
- `last_error=""`
- `lease_owner`
- `lease_pid`

Перед finalize выполняются две независимые группы проверок:

1. `has_non_worker_conflict`: если пользователь изменил title/body/status или non-worker metadata, worker аварийно завершает finalize через `RunnerError("task_file_conflict")`.
2. Проверка lease ownership:
   - внутри `finalize_task` текущие `lease_owner` и `last_run_id` обязаны совпадать с исходным claim;
   - внутри `refresh_heartbeat` проверяется только `lease_owner`.
   При нарушении выбрасывается `TaskFileError`.

### 5.3 Fail-closed критерии успешного запуска

Run считается успешным только если одновременно выполнены условия:

1. `codex exec` завершился с кодом `0`.
2. stdout содержал валидный JSON-стрим.
3. Был получен `thread.started`.
4. Был получен `turn.completed`.
5. Не было `turn.failed`.
6. Не было top-level `error`.
7. Последнее терминальное событие это `turn.completed`.
8. Зафиксировано финальное сообщение агента.

Иначе задача переводится в failed, а `last_result` принимает причину вроде `process_exit_nonzero`, `runtime_output_invalid` или `process_error`.

### 5.4 Организация логов

Для каждого task создаётся каталог:

`<logs_root>/tasks/<task-slug>--<hash8(task_id)>/`

Для каждого run создаётся каталог:

`runs/<started_at>--<run_id>/`

Внутри него:

- `prompt.md`
- `stdout.jsonl`
- `stderr.log`
- `events.jsonl`
- `summary.json`
- `subagents/*.jsonl`
- `raw_unparsed/*.jsonl`
- `problem_examples/*.jsonl`

### 5.5 Live UI

`WorkerConsole` не хранит собственную бизнес-логику состояния. Он опирается на `EventProjector`, который преобразует поток `EventRecord` в:

- `RunSnapshot.status`
- `root_thread_id`
- дерево агентов с `parent_thread_id`
- последние строки по каждому агенту
- timeline последних значимых событий

### 5.6 Post-mortem анализ connection failures

`problem_examples/*.jsonl` используется не только как "склад сырья" для ручного разбора, но и как дополнительный источник для `failure_analysis`, если run завершился без структурированного `turn.failed`.

Текущая реализация объединяет три источника текста:

- `stderr.log`
- top-level `error.message`, накопленные в `stream_state["top_errors"]`
- `payload.raw.message` из `problem_examples/main.jsonl`

После этого `_analyze_failure()` ищет сигнатуры вроде `failed to connect to websocket` или `unexpected status`, извлекает первый встретившийся `wss?://...` endpoint и HTTP-статус, а затем нормализует итог в `summary.failure_analysis`.

Практический пример из run `20260323T165554Z--792452c7-ad30-4c75-880b-5ea5a32f9b9d`:

1. Несколько `raw_unparsed`-событий с `Reconnecting... N/5` и `403 Forbidden` для `wss://chatgpt.com/backend-api/codex/responses`.
2. Отдельное error-событие внутри `item.completed` с текстом `Falling back from WebSockets to HTTPS transport...`.
3. После fallback появляются новые `403 Forbidden` уже для `https://chatgpt.com/backend-api/codex/responses`, причём тело ответа содержит HTML block-page.

Смысл этого паттерна: отказ происходит не на одном сообщении, а как последовательность `WebSocket 403 -> fallback to HTTPS -> HTTPS 403`. Для post-mortem это важно, потому что указывает на внешний deny-path уровня auth/proxy/WAF, а не на локальную ошибку парсера.

Текущее ограничение анализа: `_analyze_failure()` берёт первый найденный endpoint и жёстко маркирует `transport=websocket`, поэтому даже при наличии HTTPS fallback итоговый `failure_analysis` сейчас остаётся привязан к исходному websocket endpoint. Документация фиксирует это как фактическое поведение текущей версии.

## 6. Форматы событий и схема преобразований

### Важное уточнение про `cursor`

В текущей реализации приложение **не обрабатывает события Cursor IDE** и не имеет отдельного Cursor protocol adapter. Термин `cursor` внутри кода относится к служебному курсору чтения `SubagentSessionTail.read_cursor`, который хранит оффсет уже импортированной части subagent session file из `<codex_home>/sessions`.

Поэтому корректно выделять два слоя:

1. Входные event streams:
   - JSON stdout от `codex exec`;
   - JSONL session events субагентов из `<codex_home>/sessions`.
2. Cursor-based ingestion:
   - инкрементальное дочитывание session file по `read_cursor`;
   - сборка неполной строки через `partial_line`;
   - преобразование внешних событий в внутренний `EventRecord`.

### 6.1 Канонический внутренний формат

Все разобранные и best-effort события приводятся к `EventRecord`:

```json
{
  "schema_version": 1,
  "ts": "2026-03-23T00:00:00Z",
  "task_id": "demo",
  "run_id": "run-1",
  "seq": 42,
  "kind": "tool_call",
  "raw_type": "item.started",
  "parse_status": "parsed",
  "payload": {}
}
```

Поля:

- `kind`: внутренняя нормализованная категория.
- `raw_type`: исходный тип внешнего события.
- `parse_status`: `parsed`, `best_effort` или `unparsed`.
- `payload`: нормализованный бизнес-payload.

### 6.2 События основного потока `codex exec`

Поддерживаемые top-level `type`:

| Исходный `type` | Условие | `EventRecord.kind` | Основной payload |
| --- | --- | --- | --- |
| `thread.started` | всегда | `thread_started` | `thread_id`, `model` |
| `turn.started` | всегда | `turn_started` | `{}` |
| `turn.completed` | всегда | `turn_completed` | `usage`, `result` |
| `turn.failed` | всегда | `turn_failed` | `error`, `message` |
| `error` | всегда | `raw_unparsed` | `raw` |
| `stderr stream` | каждая строка stderr | `stderr_line` | `text` |
| `item.started/item.updated/item.completed` | `item.type=agent_message` | `assistant_message` | `text` |
| `item.started/item.updated/item.completed` | `item.type=reasoning` | `reasoning` | `text` |
| `item.started/item.updated/item.completed` | `item.type=todo_list` | `todo_list` | `phase`, normalized `items[]`, `completed_count`, `total_count` |
| `item.started/item.updated/item.completed` | `item.type=command_execution` | `tool_call/tool_result` | `tool_name=command_execution`, `input.command`, `exit_code`, `stderr`, `output` |
| `item.started/item.updated/item.completed` | `item.type=mcp_tool_call` | `tool_call/tool_result` | `tool_name`, `server`, `input` или `output` |
| `item.started/item.updated/item.completed` | `item.type=web_search` | `tool_call/tool_result` | `query`, `action` |
| `item.started/item.updated/item.completed` | `item.type=collab_tool_call` | `subagent_event` | orchestration state: `tool_name`, `phase`, `status`, `sender_thread_id`, `receiver_thread_ids`, `agents_states`, `prompt`, `detection_*` |
| `item.started/item.updated/item.completed` | `item.type=tool_use` | `tool_call` или `subagent_event` | `tool_name`, `input`; в `subagent_event` попадают только subagent-management tools |
| `item.started/item.updated/item.completed` | `item.type=tool_result` | `tool_result` | `tool_name`, `output`, `stderr`, `error` |
| `item.started/item.updated/item.completed` | `item.type=file_change` | `file_change` | normalized `changes[]` |
| любой другой payload | fallback | `raw_unparsed` | `raw` |

### 6.3 События subagent session files

Subagent session импортируется только после того, как основной поток дал `subagent_event`, из которого были извлечены `receiver_thread_ids`. На практике thread id для импорта приходят только из `item.type=collab_tool_call`. Одного `item.type=tool_use` с `name=spawn_agent` для запуска tail-нга session file недостаточно: такое событие тоже нормализуется в `subagent_event`, но у него нет `receiver_thread_ids`, поэтому оно не может запустить import/tail session file.

Практически это означает, что у событий субагента есть два независимых, но связанных слоя:

1. Control-plane события из основного stdout (`subagent_event`):
   - отражают orchestration-level вызовы вроде `spawn_agent`, `wait`, а также best-effort распознанные `spawn_agent/send_input/wait_agent/close_agent/resume_agent` из `tool_use`;
   - для `collab_tool_call` несут `phase`, `status`, `sender_thread_id`, `receiver_thread_ids`, `agents_states`, `prompt`, `detection_source=tool_payload`, `raw_ref`;
   - для `tool_use` несут `tool_name`, `input`, `detection_source=tool_name`, `raw_ref`, но не содержат `receiver_thread_ids`;
   - только ветка `collab_tool_call` даёт thread id, по которым можно начать tail subagent session file; `tool_use`-ветка нужна для timeline и статистики, но не для запуска импорта сессии.
2. Детальные события из session file:
   - содержат сообщения, tool calls/results и служебные meta-события уже внутри конкретного субагента;
   - привязываются к `subagent_thread_id` и пишутся как отдельные `subagent_*` записи в `events.jsonl`;
   - импортируются инкрементально отдельным tailer-ом уже после появления control-plane thread id в основном потоке.

Важно различать имена инструментов на этих слоях: orchestration-level `collab_tool_call` в текущих логах использует `tool=wait`, тогда как прямые tool API и session-level `response_item.function_call` используют `wait_agent`.

Краткая карта поддержанных современных session-file событий:

- `session_meta` открывает сессию субагента и даёт базовые identity-поля (`subagent_thread_id`, `parent_thread_id`, `agent_nickname`, `agent_role`, `cwd`).
- Если в импортируемом session file встречается `session_meta` для чужого `id` (например, из forked history родительского треда), он игнорируется и не создаёт отдельный `subagent_session`.
- `response_item.function_call` и `response_item.function_call_output` формируют пару `subagent_tool_call/subagent_tool_result`.
- `response_item.message` и `response_item.reasoning` не попадают в `subagent_message`: они сохраняются как `subagent_meta` с `meta_type=message|reasoning`, ролью (`role`) и фазой (`phase`).
- `event_msg.agent_message` даёт только человекочитаемую реплику агента и нормализуется в `subagent_message`.
- Остальные `event_msg.*` сейчас нормализуются в `subagent_meta`, включая `user_message`, `task_started`, `task_complete`, `token_count` и любые неизвестные `meta_type`.
- `turn_context` также идёт в `subagent_meta`, но отдельной веткой, потому что содержит execution context (`cwd`, `current_date`, `timezone`, `approval_policy`, `sandbox_policy_type`, `model`, `effort`, `summary`, `collaboration_mode_kind`).

Ещё одно важное ограничение текущей реализации: при tail/import session file в `_parse_subagent_session_line()` аргумент `parent_thread_id` передаётся из `stream_state["thread_id"]` корневого потока. Поэтому:

- `subagent_session.parent_thread_id` может быть восстановлен из `payload.source.subagent.thread_spawn.parent_thread_id` и тогда отражает реального родителя;
- `subagent_tool_call`, `subagent_tool_result`, `subagent_message` и большинство `subagent_meta` получают `parent_thread_id` из корневого thread id родительского run, а не из вложенной цепочки spawn-ов;
- для nested-subagent topology это означает, что дерево в live UI может быть точнее на уровне `subagent_session`, чем на уровне последующих импортированных строк той же session file.

Поддерживаемые `type` JSONL-сессии:

| Исходный `type` | Условие | `EventRecord.kind` | Основной payload |
| --- | --- | --- | --- |
| `session_meta` | `payload` object | `subagent_session` | `subagent_thread_id`, `parent_thread_id`, `forked_from_id`, `cwd`, `agent_nickname`, `agent_role`, `session_path` |
| `response_item` | `payload.type=function_call` | `subagent_tool_call` | `tool_name`, `tool_use_id`, `input`, `session_path` |
| `response_item` | `payload.type=function_call_output` | `subagent_tool_result` | `tool_name`, `tool_use_id`, `output`, `session_path` |
| `response_item` | `payload` object и `payload.type=message` | `subagent_meta` | `meta_type=message`, `role`, `phase`, extracted `text`, `session_path` |
| `response_item` | `payload` object и `payload.type=reasoning` | `subagent_meta` | `meta_type=reasoning`, `role`, `phase`, extracted `text` из `summary[]`, `session_path` |
| `event_msg` | `payload.type=agent_message` | `subagent_message` | `text`, `phase`, `session_path` |
| `event_msg` | `payload` object и `payload.type=user_message` | `subagent_meta` | `meta_type=user_message`, `text`, `images_count`, `local_images_count`, `text_elements_count`, `session_path` |
| `event_msg` | `payload` object и `payload.type=task_started` | `subagent_meta` | `meta_type=task_started`, `turn_id`, `model_context_window`, `collaboration_mode_kind`, `session_path` |
| `event_msg` | `payload` object и `payload.type=task_complete` | `subagent_meta` | `meta_type=task_complete`, `turn_id`, `last_agent_message`, `session_path` |
| `event_msg` | `payload` object и `payload.type=token_count` | `subagent_meta` | `meta_type=token_count`, `total_tokens`, `rate_limits`, `session_path` |
| `event_msg` | любой другой `payload` object | `subagent_meta` | `meta_type`, `raw`, `session_path` |
| `turn_context` | `payload` object | `subagent_meta` | `meta_type=turn_context`, `turn_id`, `cwd`, `current_date`, `timezone`, `approval_policy`, `sandbox_policy_type` из `sandbox_policy.type`, `model`, `effort`, `summary`, `collaboration_mode_kind` из `collaboration_mode.mode`, `session_path` |
| неизвестный `type` или неподдерживаемый `payload` object | valid JSON object | `subagent_raw_unparsed` | `subagent_thread_id`, `parent_thread_id`, `session_path`, `raw` |
| invalid JSON / non-object JSON | на этапе tail до `_parse_subagent_session_line` | `subagent_raw_unparsed` | `subagent_thread_id`, `text` |

Дополнительные замечания по payload:

- Для `item.type=collab_tool_call` поле `detection_confidence` сейчас выставляется как `high` только для `spawn_agent` и `wait`, иначе `medium`.
- Для `item.type=tool_use` в `subagent_event` попадают только имена `spawn_agent`, `send_input`, `wait_agent`, `close_agent`, `resume_agent`; остальные `tool_use` остаются обычными `tool_call`.
- Для `subagent_event` это даёт два разных семейства orchestration-level записей: `collab_tool_call` обычно несёт реальные `receiver_thread_ids`, а `tool_use` служит best-effort сигналом для timeline и счётчиков, но сам по себе не запускает import session file.
- Для `response_item.function_call` поле `arguments` парсится из JSON-строки в object best-effort; если парсинг не удался, сохраняется исходная строка.
- Для `response_item.function_call_output` имя инструмента восстанавливается по ранее увиденному `call_id`; если соответствующий вызов не был импортирован, используется `tool_name=unknown`.
- Для `session_meta.parent_thread_id` приоритет у `payload.source.subagent.thread_spawn.parent_thread_id`, а если его нет, берётся `parent_thread_id`, известный из основного потока.
- Для `turn_context` поля `sandbox_policy_type` и `collaboration_mode_kind` берутся из вложенных объектов `sandbox_policy.type` и `collaboration_mode.mode`; если вложенного объекта нет, значение остаётся `null`.
- Для `subagent_tool_call/result/message/meta` поле `session_path` всегда указывает на импортированную копию внутри run directory (`runs/.../subagents/<thread_id>.jsonl`), а не на исходный файл в `<codex_home>/sessions`.
- `tool_counts` для session-level вызовов увеличивается и на `function_call`, и на `function_call_output`, поэтому суммарный счётчик по инструменту отражает количество записей call/result, а не только число логических вызовов.
- `subagent_counts` для session-level вызовов увеличивается только на `response_item.function_call` с именами `spawn_agent/send_input/wait_agent/close_agent/resume_agent`; `function_call_output` эти счётчики не увеличивает.
- Современный пример из фикстуры `tests/test_runner.py::test_parses_modern_subagent_session_events_from_example` ожидает, что один session file может содержать одновременно `subagent_session`, `subagent_message`, `subagent_tool_call`, `subagent_tool_result` и большое число `subagent_meta`, поэтому `subagent_meta` нужно рассматривать как основной контейнер для служебных событий, а не как редкий fallback.

### 6.4 Как subagent-события попадают в live UI

`EventProjector` и `WorkerConsole` используют не все subagent-события одинаково:

- `subagent_event` создаёт или обновляет узлы агентов по `receiver_thread_ids` и `agents_states`; именно этот слой обычно первым показывает `pending_init/in_progress/completed`, ещё до импорта session file.
- `subagent_session` заполняет карточку найденного агента метаданными `parent_thread_id`, `agent_nickname`, `agent_role`, `cwd` и переводит агент в состояние `session_loaded`.
- `subagent_tool_call`, `subagent_tool_result` и `subagent_message` пополняют `recent_lines` конкретного субагента; в UI путь строится по дереву родителей, а для дочерних узлов показывается nickname без суффикса `[thread_id]`, если nickname известен.
- `subagent_meta` влияет на живое состояние только частично:
  - `task_started` переводит агент в `running`;
  - `task_complete` переводит агент в `completed`, добавляет `last_agent_message` в `recent_lines` и освобождает цвет агента;
  - `user_message` добавляет строку `user: ...` в `recent_lines`;
  - остальные варианты (`message`, `reasoning`, `token_count`, `turn_context` и прочие) сейчас участвуют в timeline/history, но не меняют `recent_lines` и не двигают state machine агента.
- В summary/timeline `subagent_meta` форматируется по `meta_type`: `message` показывает `role + text`, `task_started` дополнительно показывает `collaboration_mode_kind`, `task_complete` выводит `last_agent_message`, `token_count` показывает `total_tokens` и `rate_limits.primary.used_percent`, `turn_context` показывает сокращённый `cwd`.
- `subagent_tool_call` сам переводит агента в состояние `working`, а `subagent_tool_result` только добавляет строку результата и состояние уже не меняет.
- При `subagent_event` цвет субагента освобождается не только на `close_agent`, но и при статусах `completed/failed/cancelled`, пришедших через `status` или `agents_states`.

### 6.5 Схемы преобразований

#### A. Main stdout -> internal event

```mermaid
flowchart LR
    A[stdout line] --> B{valid JSON object?}
    B -- нет --> C[raw_unparsed]
    B -- да --> D[прочитать type]
    D --> E{top-level type}
    E --> F[direct mapping для thread/turn]
    E --> G[item.started/item.completed]
    G --> H{item.type}
    H --> I[assistant_message / reasoning]
    H --> J[tool_call / tool_result]
    H --> K[subagent_event]
    H --> L[file_change]
    H --> M[raw_unparsed fallback]
    F --> N[EventRecord]
    I --> N
    J --> N
    K --> N
    L --> N
    M --> N
```

#### B. Subagent session file -> internal event

```mermaid
flowchart LR
    A[thread_id из subagent_event] --> B[найти session file в <codex_home>/sessions]
    B --> C[seek(read_cursor)]
    C --> D[дочитать chunk]
    D --> E[склеить с partial_line]
    E --> F[разбить на complete lines]
    F --> G{valid JSON object?}
    G -- нет --> H[subagent_raw_unparsed]
    G -- да --> I[прочитать session event type]
    I --> J[subagent_session]
    I --> K[subagent_tool_call/result]
    I --> L[subagent_message/meta]
    I --> N[subagent_raw_unparsed fallback]
    J --> M[EventRecord]
    K --> M
    L --> M
    N --> M
```

#### C. Internal event -> live UI state

```mermaid
flowchart LR
    A[EventRecord] --> B[EventProjector._apply_event_state]
    B --> C[RunSnapshot.status]
    B --> D[root_thread_id]
    B --> E[agents tree]
    B --> F[recent_lines]
    A --> G[summarize_event]
    G --> H[timeline entry]
```

### 6.6 Что именно делает cursor в ingestion pipeline

`SubagentSessionTail` хранит:

- `session_path`: текущий найденный JSONL-файл субагента.
- `read_cursor`: текстовая позиция `tell()/seek()` для уже импортированной части файла.
- `partial_line`: хвост неполной строки между итерациями tail.
- `call_names`: map `call_id -> tool_name` для связывания `function_call_output` с исходным вызовом.

Это означает, что "cursor schema" в текущем приложении выглядит так:

1. Найти session file по `thread_id`.
2. Перейти на `read_cursor`.
3. Считать только новый chunk.
4. Обновить `read_cursor = source.tell()`.
5. Склеить chunk с `partial_line`.
6. В обычном режиме обработать только полные строки, а остаток сохранить в `partial_line`.
7. В финальном проходе обработать все строки из накопленного буфера, включая последнюю строку без завершающего перевода строки.
8. Нормализовать каждую строку в `EventRecord`.

## 7. Ограничения и наблюдения по корректности документации

1. Документация отражает **фактическую реализацию**, а не желаемое поведение.
2. В системе нет отдельного обработчика `tool_use` на уровне subagent session files: там современные вызовы `spawn_agent/send_input/wait_agent/close_agent/resume_agent` приходят как `response_item.function_call`.
3. Успешность run завязана не только на код завершения процесса, но и на строгую форму event sequence.
4. `stdout.jsonl` называется JSONL, но туда пишутся исходные строки stdout процесса как есть; корректность JSON проверяется отдельно в parser.
5. Поиск subagent session file выполняется по ожидаемой структуре `<codex_home>/sessions/YYYY/MM/DD/*.jsonl`: сначала проверяются недавние day directories, а при финальной синхронизации при необходимости перебираются все day directories. Повторные lookup для ещё не появившегося thread id троттлятся, чтобы не гонять тяжёлый поиск на каждом тике основного цикла.
6. Если `<codex_home>/sessions` недоступен, основной run всё равно может завершиться успешно; при этом логируется `sessions root not found`. Если каталог существует, но файл для конкретного thread не найден, логируется `session missing`.
7. `subagent_event` и `subagent_session/subagent_message/subagent_tool_*` не дублируют друг друга: первое отражает orchestration-level состояние вызова, второе даёт детальную ленту жизни уже найденной сессии субагента.
8. `subagent_raw_unparsed` возникает в двух разных случаях:
   - строка session file не распарсилась как JSON object;
   - JSON object распарсился, но его `type/payload` не попал в поддержанные ветки `_parse_subagent_session_line`.
9. Корневой каталог subagent sessions задаётся так:
   - `WorkerConfig.codex_home`, если передан `--codex-home`;
   - иначе переменная окружения `CODEX_HOME`;
   - иначе fallback `~/.codex`.
10. После полного завершения очереди task file может быть перемещён в `archive/`; последующие обращения должны использовать уже архивный путь.

## 8. Трассируемость по коду

- Жизненный цикл worker: `src/codex_worker/runner.py`
- Модель задач и run summary: `src/codex_worker/models.py`
- Парсинг task file и conflict/recovery: `src/codex_worker/task_file.py`
- Tail субагентских сессий и cursor ingestion: `src/codex_worker/runner.py`
- Проекция событий в состояние UI: `src/codex_worker/event_model.py`
- Рендер live-статуса: `src/codex_worker/console_ui.py`
