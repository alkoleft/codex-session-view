# System Overview

## 1. Основные сущности

- `Project` - зарегистрированная папка проекта на хосте или remote environment.
- `Workspace` - среда исполнения проекта: host workspace или `devcontainer`.
- `Task` - единица работы, привязанная к проекту и целевому workspace.
- `Run` - конкретная попытка исполнения задачи.
- `Worker` - агент-процесс, который может брать задачи и выполнять их.
- `Lease` - временное владение задачей конкретным worker.
- `Artifact` - файлы run: prompt, stdout, stderr, events, summary, patches и прочее.

## 2. Предлагаемые bounded contexts

### 2.1 Control Plane

Отвечает за:

- реестр проектов;
- реестр workspace и worker;
- очередь задач;
- назначение задач;
- агрегированное состояние для UI;
- аудит ручных действий оператора.

### 2.2 Worker Runtime

Отвечает за:

- claim задачи;
- выполнение локального orchestration pipeline;
- heartbeat;
- поток событий и логов;
- публикацию run-артефактов в общее хранилище.

### 2.3 UI

Отвечает за:

- единое окно управления;
- просмотр очереди, состояния worker pool и активных run;
- ручные операции: pause, retry, cancel, reassign, reopen task;
- drill-down до логов и артефактов.

## 3. Логическая схема

```mermaid
flowchart LR
    U[Operator UI] --> API[Control Plane API]
    API --> IDX[State Index]
    API --> FS[(File Storage)]
    API --> SCH[Scheduler]
    SCH --> Q[Task Queue]
    Q --> W1[Worker on Host]
    Q --> W2[Worker in Devcontainer]
    W1 --> FS
    W2 --> FS
    W1 --> EVT[Telemetry Stream]
    W2 --> EVT
    EVT --> IDX
    FS --> IDX
    IDX --> API
```

## 4. Рекомендуемая модель управления

Не делать "толстый" peer-to-peer протокол между UI и worker. Лучше разделить систему так:

- control plane управляет жизненным циклом задач и воркеров;
- worker занимается только исполнением и публикацией фактов;
- UI не пишет напрямую в task artifacts, кроме операторских команд через control plane.

Это ограничивает гонки и упрощает восстановление после падений.

## 5. Почему web UI лучше как базовый слой

`Tauri` имеет смысл, если нужен desktop shell, tray, нативные уведомления и удобная доставка single-binary приложения. Но как первичный выбор он жёстче связывает архитектуру с desktop runtime.

Для первой версии разумнее:

- backend: отдельный локальный сервис;
- frontend: web SPA;
- desktop: позже как `Tauri`-обёртка над тем же frontend/backend.

Такой путь сохраняет опцию web-доступа и не мешает локальному desktop UX.

## 6. Минимальный набор backend-компонентов

- `project-registry` - знает список проектов и доступных workspace.
- `task-service` - CRUD задач, dependencies, retry policy, priority.
- `scheduler` - раздаёт задачи с учётом тегов, capabilities и affinity.
- `worker-registry` - состояние worker, heartbeat, version, capabilities.
- `run-indexer` - собирает file artifacts в быстрый индекс для UI.
- `audit-log` - отдельный поток операторских событий.

## 7. Ключевые решения

- Артефакты хранить только в файлах.
- Производный индекс состояния можно держать тоже в файлах, а позже вынести в SQLite при росте.
- Планировщик не должен зависеть от конкретного транспорта между host и `devcontainer`.
- У каждого worker должны быть `capabilities`: `host`, `devcontainer`, `docker`, `python`, `node`, `gpu`, теги проекта и так далее.
