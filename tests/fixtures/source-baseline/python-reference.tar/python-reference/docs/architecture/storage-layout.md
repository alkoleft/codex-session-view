# Storage Layout

## 1. Почему file-based storage подходит

У вас уже есть file-based DNA в текущем проекте. Для orchestration-системы это даёт:

- прозрачные артефакты;
- простую резервную копию;
- удобный post-mortem без специальных инструментов;
- меньше скрытого состояния.

Слабое место такого подхода не в артефактах, а в конкурентных обновлениях индексных файлов. Поэтому нужно разделить:

- immutable artifacts;
- mutable indexes.

## 2. Предлагаемая структура

```text
.control-plane/
  projects/
    projects.json
    <project-id>.json
  workspaces/
    <workspace-id>.json
  workers/
    <worker-id>/
      worker.json
      heartbeat.json
      current-run.json
      commands.jsonl
  tasks/
    queue.jsonl
    index.json
    by-id/
      <task-id>.json
    leases/
      <task-id>.lease.json
  runs/
    <project-id>/
      <task-id>/
        <run-id>/
          run.json
          prompt.md
          stdout.jsonl
          stderr.log
          events.jsonl
          summary.json
          artifacts/
  telemetry/
    events/
      YYYY-MM-DD.jsonl
    metrics/
      YYYY-MM-DD.jsonl
  audit/
    YYYY-MM-DD.jsonl
```

## 3. Правила хранения

- `runs/**` считать immutable после завершения run, кроме late-import subagent artifacts.
- `tasks/by-id/*.json` это каноническое состояние задачи.
- `tasks/index.json` это производный ускоряющий индекс для UI.
- `queue.jsonl` это append-only журнал появления задач и смен статусов.
- `workers/*/heartbeat.json` обновляется часто и не должен участвовать в тяжёлых транзакциях.

## 4. Модель синхронизации

### Канонический слой

- `tasks/by-id/<task-id>.json`
- `workers/<worker-id>/worker.json`
- `runs/**`

### Производный слой

- `tasks/index.json`
- daily telemetry rollups
- aggregated UI snapshots

Идея простая: если производный слой потерян или повреждён, его можно пересобрать.

## 5. Атомарность

Для любых mutable JSON-файлов:

- писать во временный файл;
- делать `fsync`;
- затем `rename/replace`.

Для lease-файлов:

- использовать отдельный файл на задачу;
- включать `task_id`, `worker_id`, `run_id`, `lease_expires_at`;
- при claim применять file lock или atomic create.

## 6. Когда SQLite всё же понадобится

Если вырастет одно из условий:

- десятки тысяч задач;
- тяжёлые фильтры и full-text поиск по UI;
- несколько операторов одновременно;
- сложные аналитические запросы.

Тогда логичный шаг:

- оставить артефакты в файлах;
- вынести только индекс и query layer в SQLite.

Это мягкая миграция, а не переделка всей системы.
