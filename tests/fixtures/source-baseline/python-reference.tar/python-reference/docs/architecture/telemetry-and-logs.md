# Telemetry And Logs

## 1. Цель наблюдаемости

Система должна отвечать на четыре вопроса:

1. Что сейчас происходит?
2. Что происходило с конкретной задачей или worker?
3. Почему run завершился неуспешно?
4. Где узкое место: scheduler, worker, среда, модель, сеть, проект?

## 2. Разделение сигналов

### Logs

Подробный текст и сырой поток исполнения.

Примеры:

- `stderr.log`
- `stdout.jsonl`
- worker diagnostic log
- control plane access log

### Events

Структурированные факты бизнес-уровня.

Примеры:

- `task.created`
- `task.claimed`
- `task.requeued`
- `worker.heartbeat`
- `run.started`
- `run.completed`
- `run.failed`
- `operator.cancel_requested`

### Metrics

Числовые агрегаты и latency.

Примеры:

- queue depth
- task wait time
- run duration
- worker busy ratio
- fail rate by workspace kind

### Audit

Отдельный поток операторских действий.

Примеры:

- кто создал задачу;
- кто перевёл задачу в paused;
- кто перезапустил failed run;
- кто привязал проект к новому workspace.

## 3. Минимальная схема event record

```json
{
  "ts": "2026-03-24T00:00:00Z",
  "event_id": "evt_123",
  "event_type": "task.claimed",
  "project_id": "proj_demo",
  "task_id": "task_42",
  "run_id": "run_99",
  "worker_id": "worker_host_a",
  "workspace_id": "ws_devcontainer_a",
  "severity": "info",
  "payload": {
    "lease_expires_at": "2026-03-24T00:05:00Z"
  }
}
```

## 4. Какие логи нужны по слоям

### Control Plane

- API requests
- scheduler decisions
- claim conflicts
- lease recovery
- indexing failures

### Worker

- lifecycle log процесса;
- heartbeat transitions;
- запуск внешних команд;
- импорт subagent events;
- ошибки публикации артефактов.

### UI

- только клиентские ошибки и UX telemetry;
- не дублировать backend events.

## 5. Практическая рекомендация

Не складывать всё в один "универсальный лог". Лучше сразу развести:

- run artifacts рядом с run;
- operational events в `telemetry/events/*.jsonl`;
- operator actions в `audit/*.jsonl`;
- worker-local debug log рядом с worker state.

Это резко упрощает расследования.

## 6. Что показывать в едином окне

На уровне dashboard:

- online/offline workers;
- queue depth;
- running tasks;
- failed tasks за период;
- среднее время ожидания и выполнения;
- ошибки по типам workspace.

На уровне task/run:

- timeline событий;
- stdout/stderr;
- связанные patch/artifact файлы;
- информация о lease и heartbeat;
- точка исполнения: host или `devcontainer`.

## 7. Корреляция

Во всех файлах и событиях должны проходить одинаковые идентификаторы:

- `project_id`
- `workspace_id`
- `task_id`
- `run_id`
- `worker_id`
- `trace_id` для одного orchestrated run

Если этого не сделать с самого начала, поиск причин сбоев быстро станет дорогим.

## 8. Этапы внедрения

Этап 1:

- JSONL events;
- текстовые логи;
- summary per run;
- audit trail в файлах.

Этап 2:

- rollup metrics;
- alerting по stale worker и queue backlog;
- простые SLA charts в UI.

Этап 3:

- экспорт в внешнюю observability систему при необходимости, но file artifacts оставить первичными.
