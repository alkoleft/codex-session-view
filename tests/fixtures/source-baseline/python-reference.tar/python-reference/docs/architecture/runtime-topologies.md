# Runtime Topologies

## 1. Цель

Нужно поддержать один control plane и несколько вариантов исполнения worker:

- на хосте;
- внутри `devcontainer`;
- смешанный режим.

## 2. Топология A: все на хосте

```mermaid
flowchart TD
    UI[Web UI] --> API[Control Plane]
    API --> FS[(Control Plane Storage)]
    API --> WH[Host Worker]
    WH --> P1[Project Folder A]
    WH --> P2[Project Folder B]
```

Плюсы:

- проще всего поднять;
- минимум сетевых hop;
- легко отлаживать.

Минусы:

- слабая изоляция окружений;
- больше риск "works on my machine".

## 3. Топология B: control plane на хосте, worker в devcontainer

```mermaid
flowchart TD
    UI[Web UI] --> API[Control Plane on Host]
    API --> FS[(Shared Storage)]
    API --> WC[Worker inside Devcontainer]
    WC --> PRJ[Mounted Project Folder]
```

Плюсы:

- повторяемая среда исполнения;
- лучше контроль зависимостей.

Минусы:

- нужно аккуратно организовать доступ к shared storage;
- сложнее lifecycle container.

## 4. Топология C: гибридный пул

```mermaid
flowchart TD
    UI[Web UI] --> API[Control Plane]
    API --> FS[(Shared Storage)]
    API --> WH[Host Worker]
    API --> WC1[Devcontainer Worker A]
    API --> WC2[Devcontainer Worker B]
```

Это предпочтительный целевой вариант.

Он даёт:

- единое окно управления;
- разные execution targets под разные проекты;
- возможность маршрутизации по capabilities.

## 5. Практический контракт между control plane и worker

Для первого этапа не нужен тяжёлый message broker. Достаточно:

- файловой очереди задач;
- файла команд для worker;
- heartbeat-файла;
- локального HTTP API control plane для UI и ручных команд.

Worker цикл:

1. читает назначенные задачи или общий queue index;
2. пытается atomically claim задачу;
3. пишет `heartbeat.json`;
4. во время исполнения публикует `events.jsonl`, `stdout.jsonl`, `stderr.log`, `summary.json`;
5. снимает lease при завершении.

## 6. Как различать host и devcontainer

У workspace должны быть явные поля:

- `workspace_id`
- `project_id`
- `kind`: `host` | `devcontainer`
- `root_path`
- `container_name` или `devcontainer_id`
- `mount_map`
- `capabilities`
- `status`

У worker:

- `worker_id`
- `workspace_id`
- `kind`
- `version`
- `supported_runtimes`
- `last_heartbeat_at`
- `busy_task_id`

## 7. Рекомендация по запуску

На первом этапе:

- control plane запускать на хосте;
- web UI тоже на хосте;
- worker оставлять как отдельный локальный бинарь/CLI;
- для `devcontainer` запускать worker внутри контейнера, но направлять его в общее файловое хранилище control plane.

Это даёт минимум новых moving parts и сохраняет совместимость с текущим `codex-worker`.
