# Документация

- `technical-documentation.md` — техническая документация по архитектуре, состояниям, процессам и преобразованию событий, включая control-plane и session-file события субагентов, поддержанные современные payload-ветки (`session_meta`, `response_item.*`, `event_msg.*`, `turn_context`) и их проекцию в live UI.
- `architecture/README.md` — наброски следующего этапа: единый task manager, управление проектами/workspace/worker, file-based storage, host и `devcontainer` topology, телеметрия и логи.
