# codex-worker

Sequential file-based worker wrapper around `codex exec`.

## Documentation

- `docs/technical-documentation.md` — architecture, requirements, process/state diagrams, root/subagent event formats, control-plane vs session-file subagent events, supported modern subagent session payloads (`session_meta`, `response_item.*`, `event_msg.*`, `turn_context`) and cursor-based session ingestion.

## Task format

Each task starts with a heading marker `#+ [ ]`:

```md
# [ ] Title
id: unique-task-id
cwd: /abs/path/to/workdir
prompt: Additional instruction appended to every `codex exec` call

Task body in markdown.
```

Statuses:

- `[ ]` pending
- `[>]` running
- `[x]` completed
- `[!]` failed

## Run

```bash
PYTHONPATH=src python3 -m codex_worker run-next --task-file ./examples/tasks-smoke.md
```

## Console UI

`run-next` renders a live terminal dashboard via `rich`:

- task list with current statuses
- agent tree with recent output lines
- recent activity feed for the active run

Problematic raw examples are copied into a dedicated per-run `problem_examples/` directory for later post-analysis, alongside the existing `raw_unparsed/` logs.

## Dev Container

The repo includes a VS Code dev container in `.devcontainer/devcontainer.json`.

When opened in the container it:

- uses a Python 3.12 base image
- installs the project in editable mode
- installs `pytest` for local test runs
- configures VS Code testing to use `tests/`
