from __future__ import annotations

import json
from pathlib import Path

from codex_worker.models import EventRecord, RunSummary, TaskBlock
from codex_worker.util import ensure_parent, hash8, slugify


class RunPaths:
    def __init__(self, base_dir: Path, task: TaskBlock, run_id: str, started_at: str):
        task_slug = f"{slugify(task.task_id)}--{hash8(task.task_id)}"
        self.task_dir = base_dir / "tasks" / task_slug
        self.run_dir = self.task_dir / "runs" / f"{started_at.replace(':', '').replace('-', '')}--{run_id}"
        self.subagents_dir = self.run_dir / "subagents"
        self.raw_unparsed_dir = self.run_dir / "raw_unparsed"
        self.problem_examples_dir = self.run_dir / "problem_examples"
        self.prompt = self.run_dir / "prompt.md"
        self.stdout = self.run_dir / "stdout.jsonl"
        self.stderr = self.run_dir / "stderr.log"
        self.events = self.run_dir / "events.jsonl"
        self.summary = self.run_dir / "summary.json"
        self.task_json = self.task_dir / "task.json"
        self.runs_jsonl = self.task_dir / "runs.jsonl"

    def ensure(self) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.task_dir.mkdir(parents=True, exist_ok=True)
        self.subagents_dir.mkdir(parents=True, exist_ok=True)
        self.raw_unparsed_dir.mkdir(parents=True, exist_ok=True)
        self.problem_examples_dir.mkdir(parents=True, exist_ok=True)


def write_event(path: Path, event: EventRecord) -> None:
    ensure_parent(path)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event.to_dict(), ensure_ascii=True, sort_keys=True) + "\n")


def write_summary(path: Path, summary: RunSummary) -> None:
    ensure_parent(path)
    path.write_text(json.dumps(summary.__dict__, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def update_task_snapshot(path: Path, task: TaskBlock, last_run_path: str) -> None:
    ensure_parent(path)
    payload = {
        "task_id": task.task_id,
        "title": task.title,
        "status": task.status,
        "metadata": task.metadata,
        "last_run_path": last_run_path,
    }
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def append_task_run(path: Path, payload: dict) -> None:
    ensure_parent(path)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=True, sort_keys=True) + "\n")
