from __future__ import annotations

import argparse
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from codex_worker.models import WorkerConfig
from codex_worker.runner import CodexWorker, RunnerError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="codex-worker")
    subparsers = parser.add_subparsers(dest="command", required=True)
    run_next = subparsers.add_parser("run-next")
    run_next.add_argument("--task-file", required=True)
    run_next.add_argument("--codex-bin", default="codex")
    run_next.add_argument("--codex-home")
    run_next.add_argument("--logs-dir")
    run_next.add_argument("--default-cwd")
    run_next.add_argument("--model")
    run_next.add_argument("--sandbox")
    run_next.add_argument("--approval-policy")
    run_next.add_argument("--prompt-template")
    run_next.add_argument("--poll-interval", type=float, default=2.0)
    run_next.add_argument("--stale-after", type=float, default=30.0)
    run_next.add_argument("--dry-run", action="store_true")
    run_next.add_argument("--quiet", action="store_true")
    return parser


def config_from_args(args: argparse.Namespace) -> WorkerConfig:
    return WorkerConfig(
        task_file=Path(args.task_file).resolve(),
        codex_bin=args.codex_bin,
        codex_home=Path(args.codex_home).expanduser().resolve() if args.codex_home else None,
        logs_dir=Path(args.logs_dir).resolve() if args.logs_dir else None,
        default_cwd=Path(args.default_cwd).resolve() if args.default_cwd else None,
        model=args.model,
        sandbox=args.sandbox,
        approval_policy=args.approval_policy,
        prompt_template=Path(args.prompt_template).resolve() if args.prompt_template else None,
        poll_interval=args.poll_interval,
        stale_after=args.stale_after,
        dry_run=args.dry_run,
        log_to_stdout=not args.quiet,
    )


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    worker = CodexWorker(config_from_args(args))
    try:
        return worker.run_next()
    except RunnerError as exc:
        Console(stderr=True).print(
            Panel.fit(
                str(exc),
                title="codex-worker error",
                border_style="red",
            )
        )
        return 1
