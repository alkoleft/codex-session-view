from __future__ import annotations

import sys

from rich.console import Console
from rich.text import Text

from codex_worker.event_model import EventProjector, summarize_event, truncate_text
from codex_worker.models import EventRecord, TaskBlock, WorkerConfig


class WorkerConsole:
    def __init__(self, config: WorkerConfig):
        self.config = config
        self.console = Console()
        self.projector = EventProjector(timeline_limit=12, agent_line_limit=4)
        self.started = False
        self.status_enabled = bool(getattr(sys.stdout, "isatty", lambda: False)())
        self.status_line = ""

    def __enter__(self) -> "WorkerConsole":
        self.started = True
        self._redraw_status()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.status_enabled and self.status_line:
            self._clear_status_line()
            self.console.print(f"[dim]{self.status_line}[/]")
        self.started = False

    def on_claim(self, task: TaskBlock, run_id: str) -> None:
        self.projector.set_claimed(task.task_id, task.title, run_id)
        self._update_status_line()
        label = truncate_text(task.title or task.task_id, 96)
        self._print_stream_line(
            self._format_timeline_line(
                f"Задача взята в работу: {label} (id={task.task_id}, run={run_id})",
                "claim",
            )
        )

    def on_start(self, task: TaskBlock, run_id: str) -> None:
        self.projector.reset_run(task.task_id, task.title, run_id, task.cwd)
        self._update_status_line()
        self._print_stream_line(
            self._format_timeline_line(
                f"Запуск worker в {task.cwd or '.'}",
                "start",
            )
        )

    def on_result(self, task_id: str, task_title: str, run_id: str, status: str, reason: str | None = None) -> None:
        suffix = f" reason={reason}" if reason else ""
        self.projector.set_status(status)
        self._update_status_line()
        label = truncate_text(task_title or task_id, 96)
        self._print_stream_line(
            self._format_timeline_line(
                f"Задача завершена: {label} (id={task_id}, run={run_id}, status={status}{suffix})",
                status,
            )
        )

    def on_emit(self, kind: str, message: str) -> None:
        if kind == "idle":
            self.projector.set_status("idle")
            self._update_status_line()
            self._print_stream_line(self._format_timeline_line(message, "idle"))
            return
        if kind == "recovery":
            self._print_stream_line(self._format_timeline_line(message, "warning"))
            return
        if kind == "stderr":
            self._print_stream_line(self._format_timeline_line(message, "failed"))
            return
        if kind == "subagent":
            self._print_stream_line(self._format_timeline_line(truncate_text(message, 180), "info"))

    def on_event(self, event: EventRecord) -> None:
        self.projector.apply_event(event)
        self._update_status_line()
        self._print_stream_line(self._format_event_line(event))

    def _format_event_line(self, event: EventRecord) -> Text:
        return self._format_timeline_line(summarize_event(event), self._event_timeline_kind(event), event.ts, bold_label=True)

    def _tool_badge(self, event: EventRecord) -> tuple[str, str]:
        if event.event_type == "tool.call":
            return "›", "white"
        exit_code = event.payload.get("exit_code")
        if isinstance(exit_code, int):
            return ("●", "bright_green") if exit_code == 0 else ("●", "red")
        status = str(event.payload.get("status", "") or "")
        if status in {"completed", "ok", "success"}:
            return "●", "bright_green"
        if status in {"failed", "error", "cancelled"}:
            return "●", "red"
        return "●", "white"

    def _event_summary_style(self, event: EventRecord) -> str:
        if event.event_type == "file.change":
            return "bold blue"
        if event.event_type == "tool.result":
            badge_style = self._tool_badge(event)[1]
            return "dim red" if badge_style == "red" else "dim bright_green"
        return "dim"

    def _event_timeline_kind(self, event: EventRecord) -> str:
        if event.event_type in {"agent.turn.failed", "raw.unparsed", "stderr.line", "error"}:
            return "failed"
        if event.event_type in {"agent.turn.completed"}:
            return "completed"
        if event.event_type == "tool.result":
            badge_style = self._tool_badge(event)[1]
            if badge_style == "bright_green":
                return "completed"
            if badge_style == "red":
                return "failed"
        if event.event_type == "file.change":
            return "file"
        if event.event_type == "tool.call":
            return "info"
        return "default"

    def _event_thread_id(self, event: EventRecord) -> str | None:
        value = event.payload.get("thread_id")
        if isinstance(value, str) and value:
            return value
        receivers = event.payload.get("receiver_thread_ids") or []
        if isinstance(receivers, list) and receivers:
            first = receivers[0]
            if isinstance(first, str) and first:
                return first
        return self.projector.snapshot.root_thread_id

    def _thread_path(self, thread_id: str | None) -> Text:
        if not thread_id:
            return Text("•")
        agents = self.projector.snapshot.agents
        node = agents.get(thread_id)
        if node is None:
            return Text("•")
        parts: list[tuple[str, str | None]] = []
        current = node
        while current is not None:
            label = current.nickname or current.thread_id
            parts.append((label, current.color))
            parent_id = current.parent_thread_id
            current = agents.get(parent_id) if parent_id else None
        parts.reverse()
        if len(parts) == 1:
            return Text("•")
        text = Text("└─ ", style="dim")
        for index, (label, color) in enumerate(parts[1:]):
            if index:
                text.append(" / ", style="dim")
            style = f"bold {color}" if color else "bold"
            text.append(label, style=style)
        return text

    def _format_timeline_line(self, message: str, kind: str, ts: str | None = None, bold_label: bool = False) -> Text:
        badge, badge_style, message_style = self._timeline_styles(kind)
        lines = str(message).splitlines() or [""]

        text = Text()
        text.append(f"{badge} ", style=badge_style)
        self._append_labeled_line(text, lines[0], message_style, bold_label)

        for line in lines[1:]:
            text.append("\n")
            text.append("│ ", style="dim")
            text.append("  ", style="default")
            self._append_labeled_line(text, line, message_style, False)
        return text

    def _append_labeled_line(self, text: Text, line: str, style: str, bold_label: bool) -> None:
        if not bold_label:
            text.append(line, style=style)
            return
        label, separator, remainder = line.partition(":")
        if not separator:
            text.append(line, style=style)
            return
        prefix, suffix = self._split_bold_prefix(label, separator, remainder)
        label_style = f"bold {style}"
        text.append(prefix, style=label_style)
        if suffix:
            text.append(suffix, style=style)

    def _split_bold_prefix(self, label: str, separator: str, remainder: str) -> tuple[str, str]:
        normalized_label = label.strip().lower()
        base_prefix = f"{label}{separator}"
        if not remainder:
            return base_prefix, ""
        if normalized_label in {"assistant", "stderr", "error"} or normalized_label.startswith("subagent["):
            return base_prefix, remainder
        leading_spaces = len(remainder) - len(remainder.lstrip(" "))
        body = remainder.lstrip(" ")
        if not body:
            return base_prefix, remainder
        first_token, separator_space, rest = body.partition(" ")
        prefix = f"{base_prefix}{' ' * leading_spaces}{first_token}"
        if not separator_space:
            return prefix, ""
        token, token_sep, token_tail = rest.partition(" ")
        key, eq, value = token.partition("=")
        if eq and key:
            prefix += f" {key}"
            suffix = f"={value}"
            if token_sep:
                suffix += f" {token_tail}"
            return prefix, suffix
        return prefix, f" {rest}"

    def _timeline_styles(self, kind: str) -> tuple[str, str, str]:
        return {
            "claim": ("○", "bold cyan", "white"),
            "start": ("○", "bold cyan", "white"),
            "completed": ("○", "bold cyan", "white"),
            "failed": ("○", "bold red", "white"),
            "warning": ("○", "bold yellow", "white"),
            "file": ("○", "bold blue", "white"),
            "idle": ("○", "bold cyan", "white"),
            "info": ("○", "bold cyan", "white"),
            "default": ("○", "bold cyan", "white"),
        }.get(kind, ("○", "bold cyan", "white"))

    def _print_stream_line(self, renderable: object = "") -> None:
        if self.status_enabled:
            self._clear_status_line()
        self.console.print(renderable)
        self._redraw_status()

    def _clear_status_line(self) -> None:
        if not self.status_enabled:
            return
        self.console.file.write("\r\033[2K")
        self.console.file.flush()

    def _redraw_status(self) -> None:
        if not self.status_enabled or not self.status_line:
            return
        self.console.file.write(f"\r\033[2K{self.status_line}")
        self.console.file.flush()

    def _update_status_line(self) -> None:
        snapshot = self.projector.snapshot
        status = self._status_chip(snapshot.status)
        task = snapshot.task_title or snapshot.task_id
        task_label = truncate_text(task, 96) if task else None
        run_chip = self._format_run_chip(snapshot.run_id)
        parts = [status]
        if task_label:
            parts.append(task_label)
        if run_chip:
            parts.append(run_chip)
        line = " · ".join(parts)
        self.status_line = truncate_text(line, 180)

    def _status_chip(self, status: str) -> str:
        return {
            "idle": "○ idle",
            "claimed": "◔ claim",
            "running": "▶ run",
            "completed": "● done",
            "failed": "✖ fail",
        }.get(status, "• wait")

    def _compact_run_id(self, run_id: str | None) -> str | None:
        if not run_id:
            return None
        normalized = run_id.strip()
        if not normalized or normalized == "-":
            return None
        if len(normalized) <= 12:
            return normalized
        return normalized[:8]

    def _format_run_chip(self, run_id: str | None) -> str | None:
        compact = self._compact_run_id(run_id)
        if not compact:
            return None
        return f"#{compact}"
