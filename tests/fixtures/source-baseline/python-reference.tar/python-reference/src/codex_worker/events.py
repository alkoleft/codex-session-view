from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from typing import Any


LEGACY_EVENT_TYPE_BY_KIND = {
    "thread_started": "thread.started",
    "turn_started": "agent.turn.started",
    "turn_completed": "agent.turn.completed",
    "turn_failed": "agent.turn.failed",
    "assistant_message": "agent.message",
    "reasoning": "agent.reasoning",
    "tool_call": "tool.call",
    "tool_result": "tool.result",
    "file_change": "file.change",
    "todo_list": "todo.update",
    "error_event": "error",
    "raw_unparsed": "raw.unparsed",
    "stderr_line": "stderr.line",
    "subagent_event": "tool.result",
    "subagent_session": "agent.session",
    "subagent_tool_call": "tool.call",
    "subagent_tool_result": "tool.result",
    "subagent_message": "agent.message",
    "subagent_meta": "agent.meta",
    "subagent_raw_unparsed": "raw.unparsed",
}


@dataclass
class EventRecord:
    schema_version: int
    ts: str
    task_id: str
    run_id: str
    seq: int
    event_type: str
    raw_type: str
    parse_status: str
    payload: dict[str, Any]

    def payload_obj(self) -> Any:
        return parse_payload(self.event_type, self.payload)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "ts": self.ts,
            "task_id": self.task_id,
            "run_id": self.run_id,
            "seq": self.seq,
            "event_type": self.event_type,
            "raw_type": self.raw_type,
            "parse_status": self.parse_status,
            "payload": payload_to_dict(self.payload),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "EventRecord":
        event_type = payload.get("event_type")
        if not isinstance(event_type, str) or not event_type:
            legacy_kind = str(payload.get("kind", "raw_unparsed"))
            event_type = LEGACY_EVENT_TYPE_BY_KIND.get(legacy_kind, legacy_kind.replace("_", "."))
        return cls(
            schema_version=int(payload.get("schema_version", 1)),
            ts=str(payload.get("ts", "")),
            task_id=str(payload.get("task_id", "")),
            run_id=str(payload.get("run_id", "")),
            seq=int(payload.get("seq", 0)),
            event_type=event_type,
            raw_type=str(payload.get("raw_type", "")),
            parse_status=str(payload.get("parse_status", "")),
            payload=payload.get("payload", {}) if isinstance(payload.get("payload"), dict) else {},
        )


@dataclass
class CodexEvent:
    schema_version: int
    ts: str
    task_id: str
    run_id: str
    seq: int
    event_type: str
    raw_type: str
    parse_status: str
    payload: dict[str, Any]
    source: str = "codex"

    def payload_obj(self) -> Any:
        return parse_payload(self.event_type, self.payload)

    def to_record(self) -> EventRecord:
        return EventRecord(
            schema_version=self.schema_version,
            ts=self.ts,
            task_id=self.task_id,
            run_id=self.run_id,
            seq=self.seq,
            event_type=self.event_type,
            raw_type=self.raw_type,
            parse_status=self.parse_status,
            payload=payload_to_dict(self.payload),
        )

    @classmethod
    def from_record(cls, record: EventRecord, source: str = "event_log") -> "CodexEvent":
        return cls(
            schema_version=record.schema_version,
            ts=record.ts,
            task_id=record.task_id,
            run_id=record.run_id,
            seq=record.seq,
            event_type=record.event_type,
            raw_type=record.raw_type,
            parse_status=record.parse_status,
            payload=record.payload,
            source=source,
        )


@dataclass
class EventContextPayload:
    actor_type: str | None = None
    thread_id: str | None = None
    parent_thread_id: str | None = None
    session_path: str | None = None


@dataclass
class AgentTurnPayload(EventContextPayload):
    usage: Any = None
    result: Any = None
    error: Any = None
    message: str | None = None
    text_links: "TextLinksPayload | None" = None


@dataclass
class AgentMessagePayload(EventContextPayload):
    item_id: str | None = None
    text: str = ""
    role: str | None = None
    phase: str | None = None
    text_links: "TextLinksPayload | None" = None


@dataclass
class AgentSessionPayload(EventContextPayload):
    forked_from_id: str | None = None
    cwd: str | None = None
    agent_nickname: str | None = None
    agent_role: str | None = None


@dataclass
class AgentMetaPayload(EventContextPayload):
    meta_type: str = "meta"
    text: str | None = None
    role: str | None = None
    phase: str | None = None
    turn_id: str | None = None
    last_agent_message: str | None = None
    total_tokens: int | None = None
    rate_limits: Any = None
    cwd: str | None = None
    current_date: str | None = None
    timezone: str | None = None
    approval_policy: str | None = None
    sandbox_policy_type: str | None = None
    model: str | None = None
    effort: str | None = None
    summary: str | None = None
    collaboration_mode_kind: str | None = None
    raw: Any = None


@dataclass
class ToolCallPayload(EventContextPayload):
    tool_name: str = "unknown"
    tool_use_id: str | None = None
    input: Any = None
    status: str | None = None
    server: str | None = None
    phase: str | None = None
    sender_thread_id: str | None = None
    receiver_thread_ids: list[str] | None = None
    prompt: str | None = None
    agents_states: dict[str, dict[str, Any]] | None = None
    detection_source: str | None = None
    detection_confidence: str | None = None
    raw_ref: str | None = None


@dataclass
class ToolResultPayload(ToolCallPayload):
    output: Any = None
    error: Any = None
    stderr: Any = None
    exit_code: int | None = None


@dataclass
class FileChange:
    kind: str
    path: str


@dataclass
class FileChangePayload(EventContextPayload):
    item_id: str | None = None
    status: str | None = None
    changes: list[FileChange] | None = None


@dataclass
class TodoItem:
    text: str
    completed: bool


@dataclass
class TodoUpdatePayload(EventContextPayload):
    item_id: str | None = None
    status: str | None = None
    phase: str | None = None
    items: list[TodoItem] | None = None
    completed_count: int = 0
    total_count: int = 0


@dataclass
class ErrorPayload(EventContextPayload):
    item_id: str | None = None
    status: str | None = None
    phase: str | None = None
    message: str | None = None
    error_type: str | None = None
    request_id: str | None = None
    reconnect_attempt: int | None = None
    reconnect_limit: int | None = None
    is_fallback: bool | None = None
    fallback_from: str | None = None
    fallback_to: str | None = None
    text_links: "TextLinksPayload | None" = None


@dataclass
class TextLinksPayload:
    request_id: str | None = None
    reconnect_attempt: int | None = None
    reconnect_limit: int | None = None
    is_fallback: bool | None = None
    fallback_from: str | None = None
    fallback_to: str | None = None
    status_code: int | None = None
    status_text: str | None = None
    url: str | None = None
    scheme: str | None = None
    host: str | None = None
    cf_ray: str | None = None
    disconnect_reason: str | None = None


@dataclass
class RawPayload(EventContextPayload):
    raw: Any = None
    text: str | None = None


@dataclass
class StderrPayload(EventContextPayload):
    text: str = ""


PAYLOAD_CLASS_BY_EVENT_TYPE = {
    "agent.turn.started": AgentTurnPayload,
    "agent.turn.completed": AgentTurnPayload,
    "agent.turn.failed": AgentTurnPayload,
    "agent.message": AgentMessagePayload,
    "agent.reasoning": AgentMessagePayload,
    "agent.session": AgentSessionPayload,
    "agent.meta": AgentMetaPayload,
    "tool.call": ToolCallPayload,
    "tool.result": ToolResultPayload,
    "file.change": FileChangePayload,
    "todo.update": TodoUpdatePayload,
    "error": ErrorPayload,
    "raw.unparsed": RawPayload,
    "stderr.line": StderrPayload,
}


def payload_to_dict(payload: Any) -> dict[str, Any]:
    if isinstance(payload, dict):
        return payload
    if is_dataclass(payload):
        data = asdict(payload)
        return {key: value for key, value in data.items() if value is not None}
    raise TypeError(f"unsupported payload type: {type(payload)!r}")


def parse_payload(event_type: str, payload: dict[str, Any]) -> Any:
    payload_cls = PAYLOAD_CLASS_BY_EVENT_TYPE.get(event_type)
    if payload_cls is None:
        return payload
    normalized = dict(payload)
    if payload_cls is FileChangePayload:
        changes = normalized.get("changes")
        if isinstance(changes, list):
            normalized["changes"] = [
                change if isinstance(change, FileChange) else FileChange(kind=str(change.get("kind", "")), path=str(change.get("path", "")))
                for change in changes
                if isinstance(change, (dict, FileChange))
            ]
    if payload_cls is TodoUpdatePayload:
        items = normalized.get("items")
        if isinstance(items, list):
            normalized["items"] = [
                item if isinstance(item, TodoItem) else TodoItem(text=str(item.get("text", "")), completed=bool(item.get("completed")))
                for item in items
                if isinstance(item, (dict, TodoItem))
            ]
    if payload_cls in {AgentTurnPayload, AgentMessagePayload, ErrorPayload}:
        text_links = normalized.get("text_links")
        if isinstance(text_links, dict):
            normalized["text_links"] = TextLinksPayload(**text_links)
    return payload_cls(**normalized)
