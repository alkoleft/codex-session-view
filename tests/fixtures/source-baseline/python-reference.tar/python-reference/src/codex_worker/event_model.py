from __future__ import annotations

import json
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from codex_worker.event_readers import EventLogFileReader
from codex_worker.models import EventRecord


def truncate_text(value: str, limit: int = 90) -> str:
    normalized = " ".join(str(value).split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + "..."


def _command_from_payload(payload: dict[str, Any]) -> str | None:
    raw_input = payload.get("input")
    if not isinstance(raw_input, dict):
        return None
    for key in ("command", "cmd"):
        value = raw_input.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _truncate_command_text(command: str, limit: int = 120) -> str:
    lines = str(command).splitlines()
    if not lines:
        return ""
    return "\n".join(truncate_text(line, limit) for line in lines)


def _web_search_detail(payload: dict[str, Any]) -> str:
    container = payload.get("input")
    if not isinstance(container, dict):
        container = payload.get("output")
    if not isinstance(container, dict):
        return ""
    query = container.get("query")
    action = container.get("action")
    parts: list[str] = []
    if isinstance(query, str) and query.strip():
        parts.append(f"query={truncate_text(query.strip(), 120)}")
    elif payload.get("input") is container:
        parts.append("query=<pending>")
    if isinstance(action, dict):
        action_type = action.get("type")
        if isinstance(action_type, str) and action_type.strip():
            parts.append(f"action={truncate_text(action_type.strip(), 40)}")
        url = action.get("url")
        if isinstance(url, str) and url.strip():
            parts.append(f"url={truncate_text(url.strip(), 120)}")
    return " ".join(parts)


def _format_tool_event(prefix: str, payload: dict[str, Any]) -> str:
    label = f"{prefix}: {payload.get('tool_name', '?')}"
    tool_name = str(payload.get("tool_name", "") or "")
    detail = ""
    if tool_name == "web_search":
        detail = _web_search_detail(payload)
    else:
        command = _command_from_payload(payload)
        if command:
            detail = _truncate_command_text(command, 120)
    if detail:
        label += f" {detail}"
    exit_code = payload.get("exit_code")
    if prefix == "tool result" and exit_code is not None:
        label += f" exit={exit_code}"
    if prefix == "tool result":
        diagnostic = _tool_result_diagnostic(payload)
        if diagnostic:
            label += f" -> {diagnostic}"
    return label


def _is_failed_tool_result(payload: dict[str, Any]) -> bool:
    exit_code = payload.get("exit_code")
    if isinstance(exit_code, int):
        return exit_code != 0
    status = str(payload.get("status", "") or "").lower()
    return status in {"failed", "error", "cancelled"}


def _stringify_tool_detail(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        for key in ("stderr", "error", "message", "output"):
            nested = value.get(key)
            rendered = _stringify_tool_detail(nested)
            if rendered:
                return rendered
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value).strip()


def _tool_result_diagnostic(payload: dict[str, Any]) -> str:
    if not _is_failed_tool_result(payload):
        return ""
    for key in ("stderr", "error", "output"):
        rendered = _stringify_tool_detail(payload.get(key))
        if rendered:
            return truncate_text(rendered.replace("\n", " "), 120)
    return ""


def _actor_type(event: EventRecord) -> str:
    payload = event.payload_obj()
    value = getattr(payload, "actor_type", None)
    return str(value or "agent")


def _thread_id(event: EventRecord) -> str | None:
    payload = event.payload_obj()
    value = getattr(payload, "thread_id", None)
    if isinstance(value, str) and value:
        return value
    return None


def _text_links_suffix(payload: dict[str, Any]) -> str:
    raw_links = payload.get("text_links")
    if not isinstance(raw_links, dict):
        return ""
    parts: list[str] = []
    request_id = raw_links.get("request_id")
    if isinstance(request_id, str) and request_id:
        parts.append(f"request_id={request_id}")
    status_code = raw_links.get("status_code")
    if status_code is not None:
        parts.append(f"status={status_code}")
    host = raw_links.get("host")
    if isinstance(host, str) and host:
        parts.append(f"host={host}")
    cf_ray = raw_links.get("cf_ray")
    if isinstance(cf_ray, str) and cf_ray:
        parts.append(f"cf_ray={cf_ray}")
    fallback_to = raw_links.get("fallback_to")
    if raw_links.get("is_fallback") and isinstance(fallback_to, str) and fallback_to:
        parts.append(f"fallback={fallback_to}")
    if not parts:
        return ""
    return " [" + " ".join(parts) + "]"


@dataclass
class TimelineEntry:
    ts: str
    label: str
    event_kind: str


@dataclass
class AgentSnapshot:
    thread_id: str
    parent_thread_id: str | None = None
    status: str = "idle"
    nickname: str | None = None
    role: str | None = None
    cwd: str | None = None
    color: str | None = None
    recent_lines: deque[str] = field(default_factory=lambda: deque(maxlen=4))


@dataclass
class RunSnapshot:
    task_id: str | None = None
    task_title: str | None = None
    run_id: str | None = None
    cwd: str | None = None
    status: str = "idle"
    root_thread_id: str | None = None
    agents: dict[str, AgentSnapshot] = field(default_factory=dict)
    timeline: deque[TimelineEntry] = field(default_factory=lambda: deque(maxlen=12))


class EventProjector:
    def __init__(self, timeline_limit: int = 12, agent_line_limit: int = 4):
        self.timeline_limit = timeline_limit
        self.agent_line_limit = agent_line_limit
        self.snapshot = RunSnapshot(timeline=deque(maxlen=timeline_limit))
        self._agent_palette = deque(
            [
                "#e76f51",
                "#f4a261",
                "#e9c46a",
                "#90be6d",
                "#43aa8b",
                "#4d908e",
                "#577590",
                "#277da1",
                "#9b5de5",
                "#f15bb5",
                "#ff006e",
                "#fb5607",
                "#3a86ff",
                "#06d6a0",
                "#8ecae6",
                "#bc6c25",
            ]
        )
        self._claimed_agent_colors: dict[str, str] = {}

    def reset_run(self, task_id: str, task_title: str, run_id: str, cwd: str | None) -> None:
        preserved: list[TimelineEntry] = []
        if self.snapshot.task_id == task_id and self.snapshot.run_id == run_id:
            preserved = [entry for entry in self.snapshot.timeline if entry.event_kind == "claim"]
        self._agent_palette.extend(self._claimed_agent_colors.values())
        self._claimed_agent_colors.clear()
        self.snapshot = RunSnapshot(
            task_id=task_id,
            task_title=task_title,
            run_id=run_id,
            cwd=cwd,
            status="running",
            timeline=deque(maxlen=self.timeline_limit),
        )
        for entry in preserved:
            self.snapshot.timeline.append(entry)
        self.push_timeline("start", f"start: {task_id} cwd={cwd or '.'}")

    def set_claimed(self, task_id: str, task_title: str, run_id: str) -> None:
        self.snapshot.task_id = task_id
        self.snapshot.task_title = task_title
        self.snapshot.run_id = run_id
        self.snapshot.status = "claimed"
        self.push_timeline("claim", f"claim: {task_id} -> {run_id}")

    def set_status(self, status: str, label: str | None = None) -> None:
        self.snapshot.status = status
        if label:
            self.push_timeline(status, label)

    def push_timeline(self, event_kind: str, label: str, ts: str = "") -> None:
        self.snapshot.timeline.append(TimelineEntry(ts=ts, label=truncate_text(label, 160), event_kind=event_kind))

    def apply_event(self, event: EventRecord) -> None:
        self._apply_event_state(event)
        self.push_timeline(event.event_type, summarize_event(event), event.ts)

    def apply_events(self, events: Iterable[EventRecord]) -> RunSnapshot:
        for event in events:
            self.apply_event(event)
        return self.snapshot

    def _ensure_agent(self, thread_id: str, parent_thread_id: str | None = None) -> AgentSnapshot:
        agent = self.snapshot.agents.get(thread_id)
        if agent is None:
            agent = AgentSnapshot(thread_id=thread_id, parent_thread_id=parent_thread_id, recent_lines=deque(maxlen=self.agent_line_limit))
            self.snapshot.agents[thread_id] = agent
        elif parent_thread_id and not agent.parent_thread_id:
            agent.parent_thread_id = parent_thread_id
        return agent

    def _claim_agent_color(self, thread_id: str) -> str | None:
        color = self._claimed_agent_colors.get(thread_id)
        if color:
            return color
        if not self._agent_palette:
            return None
        color = self._agent_palette.popleft()
        self._claimed_agent_colors[thread_id] = color
        return color

    def _assign_subagent_color(self, thread_id: str) -> None:
        root_thread_id = self.snapshot.root_thread_id
        if thread_id == root_thread_id:
            return
        agent = self._ensure_agent(thread_id)
        if agent.color:
            return
        agent.color = self._claim_agent_color(thread_id)

    def _release_subagent_color(self, thread_id: str) -> None:
        agent = self.snapshot.agents.get(thread_id)
        if agent is None or not agent.color:
            return
        color = self._claimed_agent_colors.pop(thread_id, None)
        if color:
            self._agent_palette.appendleft(color)
        agent.color = None

    def _append_agent_line(self, thread_id: str, line: str, parent_thread_id: str | None = None) -> None:
        agent = self._ensure_agent(thread_id, parent_thread_id)
        agent.recent_lines.append(truncate_text(line, 140))

    def _apply_event_state(self, event: EventRecord) -> None:
        if event.event_type == "thread.started":
            thread_id = str(event.payload.get("thread_id", "root"))
            self.snapshot.root_thread_id = thread_id
            self._ensure_agent(thread_id).status = "running"
            return
        if event.event_type == "agent.message":
            thread_id = _thread_id(event) or self.snapshot.root_thread_id
            if thread_id:
                self._append_agent_line(thread_id, str(event.payload.get("text", "")), event.payload.get("parent_thread_id"))
            return
        if event.event_type == "agent.turn.completed" and self.snapshot.root_thread_id:
            self.snapshot.status = "completed"
            self._ensure_agent(self.snapshot.root_thread_id).status = "completed"
            return
        if event.event_type == "agent.turn.failed" and self.snapshot.root_thread_id:
            self.snapshot.status = "failed"
            self._ensure_agent(self.snapshot.root_thread_id).status = "failed"
            return
        if event.event_type == "tool.result" and event.payload.get("receiver_thread_ids"):
            sender = str(_thread_id(event) or self.snapshot.root_thread_id or "root")
            self._ensure_agent(sender)
            tool_name = str(event.payload.get("tool_name") or "")
            receivers = event.payload.get("receiver_thread_ids") or []
            if isinstance(receivers, list):
                for receiver in receivers:
                    receiver_id = str(receiver)
                    self._assign_subagent_color(receiver_id)
                    agent = self._ensure_agent(receiver_id, sender)
                    if event.payload.get("status"):
                        agent.status = str(event.payload["status"])
                    if tool_name == "close_agent" or agent.status in {"completed", "failed", "cancelled"}:
                        self._release_subagent_color(receiver_id)
            states = event.payload.get("agents_states") or {}
            if isinstance(states, dict):
                for state_thread_id, raw_state in states.items():
                    if not isinstance(raw_state, dict):
                        continue
                    agent_id = str(state_thread_id)
                    self._assign_subagent_color(agent_id)
                    agent = self._ensure_agent(agent_id, sender)
                    if raw_state.get("status"):
                        agent.status = str(raw_state["status"])
                    if raw_state.get("message"):
                        self._append_agent_line(agent_id, str(raw_state["message"]), sender)
                    if agent.status in {"completed", "failed", "cancelled"}:
                        self._release_subagent_color(agent_id)
            return
        if event.event_type == "agent.session":
            thread_id = str(_thread_id(event) or "unknown")
            self._assign_subagent_color(thread_id)
            parent = event.payload.get("parent_thread_id")
            agent = self._ensure_agent(thread_id, str(parent) if parent else None)
            if event.payload.get("agent_nickname"):
                agent.nickname = str(event.payload.get("agent_nickname"))
            if event.payload.get("agent_role"):
                agent.role = str(event.payload.get("agent_role"))
            if event.payload.get("cwd"):
                agent.cwd = str(event.payload.get("cwd"))
            agent.status = "session_loaded"
            return
        if event.event_type == "tool.call" and _actor_type(event) == "subagent":
            thread_id = str(_thread_id(event) or "unknown")
            self._assign_subagent_color(thread_id)
            self._append_agent_line(thread_id, f"tool: {event.payload.get('tool_name', 'unknown')}")
            self._ensure_agent(thread_id).status = "working"
            return
        if event.event_type == "tool.result" and _actor_type(event) == "subagent":
            thread_id = str(_thread_id(event) or "unknown")
            self._assign_subagent_color(thread_id)
            output = str(event.payload.get("output", "")).strip()
            self._append_agent_line(thread_id, f"result {event.payload.get('tool_name', 'unknown')}: {output or 'ok'}")
            return
        if event.event_type == "agent.meta" and _actor_type(event) == "subagent":
            thread_id = str(_thread_id(event) or "unknown")
            self._assign_subagent_color(thread_id)
            parent = event.payload.get("parent_thread_id")
            meta_type = str(event.payload.get("meta_type", "meta"))
            agent = self._ensure_agent(thread_id, str(parent) if parent else None)
            if meta_type == "task_started":
                agent.status = "running"
                return
            if meta_type == "task_complete":
                agent.status = "completed"
                last_message = str(event.payload.get("last_agent_message", "") or "").strip()
                if last_message:
                    self._append_agent_line(thread_id, last_message, str(parent) if parent else None)
                self._release_subagent_color(thread_id)
                return
            if meta_type == "user_message":
                text = str(event.payload.get("text", "") or "").strip()
                if text:
                    self._append_agent_line(thread_id, f"user: {text}", str(parent) if parent else None)
                return


def summarize_event(event: EventRecord) -> str:
    if event.event_type == "agent.message":
        label = "subagent" if _actor_type(event) == "subagent" else "assistant"
        thread_label = f"[{_thread_id(event) or '?'}]" if _actor_type(event) == "subagent" else ""
        return f"{label}{thread_label}: {truncate_text(str(event.payload.get('text', '')), 100)}{_text_links_suffix(event.payload)}"
    if event.event_type == "agent.session":
        return f"subagent session loaded: {_thread_id(event) or '?'}"
    if event.event_type == "agent.meta":
        thread_id = _thread_id(event) or "?"
        meta_type = str(event.payload.get("meta_type", "meta"))
        if meta_type == "message":
            role = str(event.payload.get("role", "unknown"))
            text = truncate_text(str(event.payload.get("text", "")), 100)
            suffix = f": {text}" if text else ""
            return f"subagent[{thread_id}] {role}{suffix}"
        if meta_type == "user_message":
            text = truncate_text(str(event.payload.get("text", "")), 100)
            suffix = f": {text}" if text else ""
            return f"subagent[{thread_id}] user{suffix}"
        if meta_type == "task_started":
            mode = str(event.payload.get("collaboration_mode_kind", "") or "")
            suffix = f" mode={mode}" if mode else ""
            return f"subagent[{thread_id}] task started{suffix}"
        if meta_type == "task_complete":
            text = truncate_text(str(event.payload.get("last_agent_message", "")), 80)
            suffix = f": {text}" if text else ""
            return f"subagent[{thread_id}] task complete{suffix}"
        if meta_type == "token_count":
            total_tokens = event.payload.get("total_tokens")
            total_suffix = f" total={total_tokens}" if total_tokens is not None else ""
            rate_limits = event.payload.get("rate_limits")
            limit_suffix = ""
            if isinstance(rate_limits, dict):
                primary = rate_limits.get("primary")
                if isinstance(primary, dict) and primary.get("used_percent") is not None:
                    limit_suffix = f" primary={primary['used_percent']}%"
            return f"subagent[{thread_id}] tokens{total_suffix}{limit_suffix}"
        if meta_type == "turn_context":
            cwd = str(event.payload.get("cwd", "") or "")
            suffix = f" cwd={truncate_text(cwd, 60)}" if cwd else ""
            return f"subagent[{thread_id}] turn context{suffix}"
        return f"subagent[{thread_id}] meta {meta_type}"
    if event.event_type == "tool.call":
        if _actor_type(event) == "subagent":
            return f"subagent[{_thread_id(event) or '?'}] tool {event.payload.get('tool_name', '?')}"
        return _format_tool_event("tool", event.payload)
    if event.event_type == "tool.result":
        if (
            event.payload.get("receiver_thread_ids") is not None
            or event.payload.get("sender_thread_id") is not None
            or event.payload.get("agents_states") is not None
        ):
            tool_name = str(event.payload.get("tool_name", "subagent"))
            phase = str(event.payload.get("phase", "") or "")
            status = str(event.payload.get("status", "") or "")
            receiver_ids = event.payload.get("receiver_thread_ids") or []
            states = event.payload.get("agents_states") or {}
            state_parts: list[str] = []
            if isinstance(states, dict):
                for thread_id, raw_state in states.items():
                    if isinstance(raw_state, dict) and raw_state.get("status"):
                        state_parts.append(f"{thread_id}:{raw_state['status']}")
            details = [tool_name]
            if phase:
                details.append(f"phase={phase}")
            if status:
                details.append(f"status={status}")
            if receiver_ids:
                details.append(f"agents={','.join(str(item) for item in receiver_ids)}")
            if state_parts:
                details.append(f"states={','.join(state_parts)}")
            return "subagent: " + " ".join(details)
        if _actor_type(event) == "subagent" and not event.payload.get("receiver_thread_ids"):
            output = truncate_text(str(event.payload.get("output", "")).strip().replace("\n", " "), 60)
            suffix = f" -> {output}" if output else ""
            return f"subagent[{_thread_id(event) or '?'}] result {event.payload.get('tool_name', '?')}{suffix}"
        return _format_tool_event("tool result", event.payload)
    if event.event_type == "file.change":
        changes = event.payload.get("changes") or []
        if isinstance(changes, list) and changes:
            first = changes[0]
            if isinstance(first, dict):
                kind = str(first.get("kind", "change"))
                path = str(first.get("path", ""))
                suffix = f" {truncate_text(path, 80)}" if path else ""
                extra = f" (+{len(changes) - 1})" if len(changes) > 1 else ""
                return f"files: {kind}{suffix}{extra}"
        return "files changed"
    if event.event_type == "todo.update":
        phase = str(event.payload.get("phase", "") or "")
        completed = int(event.payload.get("completed_count", 0) or 0)
        total = int(event.payload.get("total_count", 0) or 0)
        items = event.payload.get("items") or []
        next_item = ""
        if isinstance(items, list):
            for raw_item in items:
                if isinstance(raw_item, dict) and not raw_item.get("completed"):
                    next_item = truncate_text(str(raw_item.get("text", "")), 80)
                    break
        summary = f"todo {phase}: {completed}/{total}"
        if next_item:
            summary += f" next={next_item}"
        return summary
    if event.event_type == "stderr.line":
        return f"stderr: {truncate_text(str(event.payload.get('text', '')), 100)}"
    if event.event_type == "error":
        return f"error: {truncate_text(str(event.payload.get('message', '')), 100)}{_text_links_suffix(event.payload)}"
    if event.event_type == "agent.turn.failed":
        message = str(event.payload.get("message", "") or "")
        if not message:
            raw_error = event.payload.get("error")
            if isinstance(raw_error, dict):
                message = str(raw_error.get("message", "") or "")
        summary = "agent turn failed"
        if message:
            summary += f": {truncate_text(message, 100)}"
        return summary + _text_links_suffix(event.payload)
    return event.event_type


def load_event_records(path: Path) -> list[EventRecord]:
    return EventLogFileReader.load_records(path)
