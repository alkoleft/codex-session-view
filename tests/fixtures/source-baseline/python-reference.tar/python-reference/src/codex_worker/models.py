from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from codex_worker.events import EventRecord


TASK_START_MARKER = "<!-- codex-task:start -->"
TASK_END_MARKER = "<!-- codex-task:end -->"
WORKER_OWNED_METADATA = {
    "last_run_id",
    "last_started_at",
    "last_heartbeat_at",
    "last_finished_at",
    "last_result",
    "last_error",
    "lease_owner",
    "lease_pid",
}


@dataclass
class TaskBlock:
    title: str
    status: str
    metadata: dict[str, str]
    explicit_metadata_keys: set[str]
    body: str
    raw_text: str
    start: int
    end: int

    @property
    def task_id(self) -> str:
        return self.metadata["id"]

    @property
    def cwd(self) -> str:
        return self.metadata.get("cwd", "")


@dataclass
class TaskFileSnapshot:
    path: Path
    content: str
    tasks: list[TaskBlock]
    sha256: str
    mtime_ns: int


@dataclass
class WorkerConfig:
    task_file: Path
    codex_bin: str = "codex"
    codex_home: Path | None = None
    logs_dir: Path | None = None
    default_cwd: Path | None = None
    model: str | None = None
    sandbox: str | None = None
    approval_policy: str | None = None
    prompt_template: Path | None = None
    poll_interval: float = 2.0
    stale_after: float = 30.0
    dry_run: bool = False
    log_to_stdout: bool = True


@dataclass
class ClaimedTask:
    task: TaskBlock
    run_id: str
    worker_id: str
    worker_pid: int
    snapshot: TaskFileSnapshot


@dataclass
class RunSummary:
    schema_version: int = 1
    task_id: str = ""
    run_id: str = ""
    status: str = "failed"
    failure_reason: str | None = None
    failure_analysis: dict[str, Any] = field(default_factory=dict)
    started_at: str = ""
    finished_at: str = ""
    exit_code: int | None = None
    event_counts: dict[str, int] = field(default_factory=dict)
    tool_counts: dict[str, int] = field(default_factory=dict)
    subagent_counts: dict[str, int] = field(default_factory=dict)
    paths: dict[str, str] = field(default_factory=dict)
