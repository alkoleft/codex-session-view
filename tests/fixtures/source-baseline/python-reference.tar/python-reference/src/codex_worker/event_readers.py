from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse
from typing import Any, Iterable

from codex_worker.events import (
    AgentMessagePayload,
    AgentMetaPayload,
    AgentSessionPayload,
    AgentTurnPayload,
    CodexEvent,
    ErrorPayload,
    EventRecord,
    FileChange,
    FileChangePayload,
    RawPayload,
    StderrPayload,
    TextLinksPayload,
    TodoItem,
    TodoUpdatePayload,
    ToolCallPayload,
    ToolResultPayload,
    payload_to_dict,
)
from codex_worker.util import utc_now_iso


REQUEST_ID_RE = re.compile(r"\brequest ID ([0-9a-fA-F-]{8,})\b")
RECONNECT_RE = re.compile(r"Reconnecting\.\.\.\s*(\d+)\s*/\s*(\d+)")
STATUS_RE = re.compile(r"\bstatus\s+(\d{3})\s+([A-Za-z]+)\b")
URL_RE = re.compile(r"\burl:\s*(https?://[^\s,)]+|wss?://[^\s,)]+)")
CF_RAY_RE = re.compile(r"\bcf-ray:\s*([^\s,)]+)", re.IGNORECASE)
DISCONNECT_RE = re.compile(r"^(stream disconnected before completion)\b", re.IGNORECASE)
FALLBACK_RE = re.compile(r"Falling back from ([A-Za-z]+)s? to ([A-Za-z]+) transport", re.IGNORECASE)


@dataclass
class RunEventContext:
    task_id: str
    run_id: str


@dataclass
class JsonOutputState:
    valid_json: bool = True
    saw_turn_completed: bool = False
    saw_turn_failed: bool = False
    saw_thread_started: bool = False
    saw_top_error: bool = False
    top_errors: list[dict[str, Any]] = field(default_factory=list)
    item_errors: list[dict[str, Any]] = field(default_factory=list)
    last_terminal: str | None = None
    final_agent_message: str | None = None
    current_turn_messages: list[str] = field(default_factory=list)
    turn_open: bool = False
    thread_id: str | None = None


class JsonOutputEventReader:
    def __init__(self, context: RunEventContext, state: JsonOutputState | None = None):
        self.context = context
        self.state = state or JsonOutputState()

    def parse_main_output_line(
        self,
        seq: int,
        line: str,
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
        subagent_threads: set[str],
    ) -> tuple[int, CodexEvent]:
        stripped = line.rstrip("\n")
        seq += 1
        ts = utc_now_iso()
        try:
            parsed = json.loads(stripped)
            if not isinstance(parsed, dict):
                raise ValueError("not an object")
        except Exception:
            self.state.valid_json = False
            return seq, CodexEvent(
                schema_version=1,
                ts=ts,
                task_id=self.context.task_id,
                run_id=self.context.run_id,
                seq=seq,
                event_type="raw.unparsed",
                raw_type="invalid_json",
                parse_status="unparsed",
                payload=payload_to_dict(RawPayload(text=stripped)),
                source="json_output",
            )

        raw_type = str(parsed.get("type", "unknown"))
        event_type = "raw.unparsed"
        payload: dict[str, Any] = {"raw": parsed, "actor_type": "agent", "thread_id": self.state.thread_id}
        parse_status = "best_effort"

        if raw_type == "thread.started":
            self.state.saw_thread_started = True
            self.state.thread_id = parsed.get("thread_id")
            event_type = "thread.started"
            parse_status = "parsed"
            payload = {"thread_id": parsed.get("thread_id"), "model": parsed.get("model")}
        elif raw_type == "turn.started":
            self.state.turn_open = True
            self.state.current_turn_messages = []
            event_type = "agent.turn.started"
            parse_status = "parsed"
            payload = payload_to_dict(AgentTurnPayload(actor_type="agent", thread_id=self.state.thread_id))
        elif raw_type == "turn.completed":
            self.state.saw_turn_completed = True
            self.state.last_terminal = "turn.completed"
            self.state.turn_open = False
            if self.state.current_turn_messages:
                self.state.final_agent_message = self.state.current_turn_messages[-1]
            event_type = "agent.turn.completed"
            parse_status = "parsed"
            payload = payload_to_dict(
                AgentTurnPayload(actor_type="agent", thread_id=self.state.thread_id, usage=parsed.get("usage"), result=parsed.get("result"))
            )
        elif raw_type == "turn.failed":
            self.state.saw_turn_failed = True
            self.state.last_terminal = "turn.failed"
            self.state.turn_open = False
            turn_message = parsed.get("message")
            turn_error = parsed.get("error")
            error_message = turn_message if isinstance(turn_message, str) else None
            if error_message is None and isinstance(turn_error, dict):
                nested_message = turn_error.get("message")
                if isinstance(nested_message, str):
                    error_message = nested_message
            event_type = "agent.turn.failed"
            parse_status = "parsed"
            payload = payload_to_dict(
                AgentTurnPayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    error=turn_error,
                    message=turn_message,
                    text_links=self._extract_text_links(error_message),
                )
            )
        elif raw_type == "error":
            self.state.saw_top_error = True
            self.state.top_errors.append(parsed)
            event_type = "error"
            parse_status = "parsed"
            payload = payload_to_dict(self._build_error_payload(parsed.get("message"), parsed.get("type")))
        elif raw_type in {"item.started", "item.updated", "item.completed"}:
            item = parsed.get("item")
            if isinstance(item, dict):
                event_type, payload, parse_status = self._parse_item_event(
                    item,
                    raw_type,
                    tool_counts,
                    subagent_counts,
                    subagent_threads,
                )
                if event_type == "error":
                    self.state.item_errors.append(payload)
                if event_type == "agent.message":
                    text = item.get("text")
                    if isinstance(text, str) and text.strip():
                        if self.state.turn_open:
                            self.state.current_turn_messages.append(text)
                        elif self.state.last_terminal == "turn.completed":
                            self.state.final_agent_message = text

        return seq, CodexEvent(
            schema_version=1,
            ts=ts,
            task_id=self.context.task_id,
            run_id=self.context.run_id,
            seq=seq,
            event_type=event_type,
            raw_type=raw_type,
            parse_status=parse_status,
            payload=payload,
            source="json_output",
        )

    def parse_subagent_session_payload(
        self,
        seq: int,
        parsed: dict[str, Any],
        imported_path: Path,
        parent_thread_id: str,
        thread_id: str,
        call_names: dict[str, str],
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
    ) -> CodexEvent | None:
        ts = str(parsed.get("timestamp") or utc_now_iso())
        raw_type = str(parsed.get("type", "unknown"))
        event_type = "raw.unparsed"
        payload: dict[str, Any] = {
            "actor_type": "subagent",
            "thread_id": thread_id,
            "parent_thread_id": parent_thread_id,
            "session_path": str(imported_path),
            "raw": parsed,
        }
        parse_status = "best_effort"

        if raw_type == "session_meta":
            meta = parsed.get("payload")
            if isinstance(meta, dict):
                meta_thread_id = str(meta.get("id") or thread_id)
                if meta_thread_id != thread_id:
                    return None
                source = meta.get("source")
                source_parent = None
                if isinstance(source, dict):
                    subagent = source.get("subagent")
                    if isinstance(subagent, dict):
                        thread_spawn = subagent.get("thread_spawn")
                        if isinstance(thread_spawn, dict):
                            source_parent = thread_spawn.get("parent_thread_id")
                event_type = "agent.session"
                parse_status = "parsed"
                payload = {
                    "actor_type": "subagent",
                    "thread_id": meta_thread_id,
                    "parent_thread_id": str(source_parent or parent_thread_id),
                    "forked_from_id": meta.get("forked_from_id"),
                    "cwd": meta.get("cwd"),
                    "agent_nickname": meta.get("agent_nickname"),
                    "agent_role": meta.get("agent_role"),
                    "session_path": str(imported_path),
                }
        elif raw_type == "response_item":
            item = parsed.get("payload")
            if isinstance(item, dict):
                item_type = str(item.get("type", "unknown"))
                if item_type == "function_call":
                    name = str(item.get("name", "unknown"))
                    call_id = str(item.get("call_id", ""))
                    if call_id:
                        call_names[call_id] = name
                    tool_counts[name] += 1
                    if name in {"spawn_agent", "send_input", "wait_agent", "close_agent", "resume_agent"}:
                        subagent_counts[name] += 1
                    arguments = item.get("arguments")
                    parsed_arguments = arguments
                    if isinstance(arguments, str):
                        try:
                            parsed_arguments = json.loads(arguments)
                        except Exception:
                            parsed_arguments = arguments
                    event_type = "tool.call"
                    parse_status = "parsed"
                    payload = {
                        "actor_type": "subagent",
                        "thread_id": thread_id,
                        "parent_thread_id": parent_thread_id,
                        "tool_name": name,
                        "tool_use_id": call_id,
                        "input": parsed_arguments,
                        "session_path": str(imported_path),
                    }
                elif item_type == "function_call_output":
                    call_id = str(item.get("call_id", ""))
                    name = call_names.get(call_id, "unknown")
                    tool_counts[name] += 1
                    event_type = "tool.result"
                    parse_status = "parsed"
                    payload = {
                        "actor_type": "subagent",
                        "thread_id": thread_id,
                        "parent_thread_id": parent_thread_id,
                        "tool_name": name,
                        "tool_use_id": call_id,
                        "output": item.get("output"),
                        "session_path": str(imported_path),
                    }
                elif item_type in {"message", "reasoning"}:
                    event_type = "agent.message" if item_type == "message" else "agent.reasoning"
                    parse_status = "parsed"
                    text = self._extract_message_text(item) if item_type == "message" else self._extract_reasoning_text(item)
                    payload = {
                        "actor_type": "subagent",
                        "thread_id": thread_id,
                        "parent_thread_id": parent_thread_id,
                        "role": item.get("role"),
                        "phase": item.get("phase"),
                        "text": text,
                        "text_links": payload_to_dict(self._extract_text_links(text)) if self._extract_text_links(text) is not None else None,
                        "session_path": str(imported_path),
                    }
        elif raw_type == "event_msg":
            item = parsed.get("payload")
            if isinstance(item, dict) and item.get("type") == "agent_message":
                event_type = "agent.message"
                parse_status = "parsed"
                payload = {
                    "actor_type": "subagent",
                    "thread_id": thread_id,
                    "parent_thread_id": parent_thread_id,
                    "text": item.get("message", ""),
                    "phase": item.get("phase"),
                    "text_links": payload_to_dict(self._extract_text_links(item.get("message"))) if self._extract_text_links(item.get("message")) is not None else None,
                    "session_path": str(imported_path),
                }
            elif isinstance(item, dict):
                meta_type = str(item.get("type", "unknown"))
                event_type = "agent.meta"
                parse_status = "parsed"
                payload = {
                    "actor_type": "subagent",
                    "thread_id": thread_id,
                    "parent_thread_id": parent_thread_id,
                    "meta_type": meta_type,
                    "session_path": str(imported_path),
                }
                if meta_type == "user_message":
                    payload.update(
                        {
                            "text": item.get("message", ""),
                            "images_count": len(item.get("images")) if isinstance(item.get("images"), list) else 0,
                            "local_images_count": len(item.get("local_images")) if isinstance(item.get("local_images"), list) else 0,
                            "text_elements_count": len(item.get("text_elements")) if isinstance(item.get("text_elements"), list) else 0,
                        }
                    )
                elif meta_type == "task_started":
                    payload.update(
                        {
                            "turn_id": item.get("turn_id"),
                            "model_context_window": item.get("model_context_window"),
                            "collaboration_mode_kind": item.get("collaboration_mode_kind"),
                        }
                    )
                elif meta_type == "task_complete":
                    payload.update(
                        {
                            "turn_id": item.get("turn_id"),
                            "last_agent_message": item.get("last_agent_message"),
                        }
                    )
                elif meta_type == "token_count":
                    rate_limits = item.get("rate_limits")
                    info = item.get("info")
                    total_tokens = None
                    if isinstance(info, dict):
                        total_usage = info.get("total_token_usage")
                        if isinstance(total_usage, dict):
                            total_tokens = total_usage.get("total_tokens")
                    payload.update(
                        {
                            "total_tokens": total_tokens,
                            "rate_limits": rate_limits,
                        }
                    )
                else:
                    payload["raw"] = item
        elif raw_type == "turn_context":
            event_type = "agent.meta"
            parse_status = "parsed"
            context = parsed.get("payload")
            payload = {
                "actor_type": "subagent",
                "thread_id": thread_id,
                "parent_thread_id": parent_thread_id,
                "meta_type": "turn_context",
                "session_path": str(imported_path),
            }
            if isinstance(context, dict):
                sandbox_policy = context.get("sandbox_policy")
                collaboration_mode = context.get("collaboration_mode")
                payload.update(
                    {
                        "turn_id": context.get("turn_id"),
                        "cwd": context.get("cwd"),
                        "current_date": context.get("current_date"),
                        "timezone": context.get("timezone"),
                        "approval_policy": context.get("approval_policy"),
                        "sandbox_policy_type": sandbox_policy.get("type") if isinstance(sandbox_policy, dict) else None,
                        "model": context.get("model"),
                        "effort": context.get("effort"),
                        "summary": context.get("summary"),
                        "collaboration_mode_kind": collaboration_mode.get("mode") if isinstance(collaboration_mode, dict) else None,
                    }
                )

        return CodexEvent(
            schema_version=1,
            ts=ts,
            task_id=self.context.task_id,
            run_id=self.context.run_id,
            seq=seq,
            event_type=event_type,
            raw_type=raw_type,
            parse_status=parse_status,
            payload=payload,
            source="subagent_session",
        )

    def _parse_item_event(
        self,
        item: dict[str, Any],
        event_type: str,
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
        subagent_threads: set[str],
    ) -> tuple[str, dict[str, Any], str]:
        item_type = str(item.get("type", "unknown"))
        if item_type in {"item.started", "item.updated", "item.completed"}:
            nested_item = item.get("item")
            if isinstance(nested_item, dict):
                return self._parse_item_event(
                    nested_item,
                    item_type,
                    tool_counts,
                    subagent_counts,
                    subagent_threads,
                )
        phase = {
            "item.started": "started",
            "item.updated": "updated",
            "item.completed": "completed",
        }.get(event_type, "completed")
        if item_type == "agent_message":
            return "agent.message", payload_to_dict(
                AgentMessagePayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    item_id=item.get("id"),
                    text=str(item.get("text", "")),
                    text_links=self._extract_text_links(item.get("text")),
                )
            ), "parsed"
        if item_type == "reasoning":
            return "agent.reasoning", payload_to_dict(
                AgentMessagePayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    text=str(item.get("text", "")),
                    text_links=self._extract_text_links(item.get("text")),
                )
            ), "parsed"
        if item_type == "error":
            payload = self._build_error_payload(item.get("message"), item.get("type"))
            payload.item_id = item.get("id")
            payload.status = item.get("status")
            payload.phase = phase
            return "error", payload_to_dict(payload), "parsed"
        if item_type == "todo_list":
            raw_items = item.get("items")
            if not isinstance(raw_items, list):
                raw_items = []
            normalized_items: list[TodoItem] = []
            completed_count = 0
            for raw_entry in raw_items:
                if not isinstance(raw_entry, dict):
                    continue
                completed = bool(raw_entry.get("completed"))
                if completed:
                    completed_count += 1
                normalized_items.append(TodoItem(text=str(raw_entry.get("text", "")), completed=completed))
            return "todo.update", payload_to_dict(
                TodoUpdatePayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    item_id=item.get("id"),
                    status=item.get("status"),
                    phase=phase,
                    items=normalized_items,
                    completed_count=completed_count,
                    total_count=len(normalized_items),
                )
            ), "parsed"
        if item_type == "command_execution":
            tool_counts["command_execution"] += 1
            result_type = "tool.call" if phase == "started" else "tool.result"
            if result_type == "tool.call":
                return result_type, payload_to_dict(
                    ToolCallPayload(
                        actor_type="agent",
                        thread_id=self.state.thread_id,
                        tool_name="command_execution",
                        tool_use_id=item.get("id"),
                        status=item.get("status"),
                        input={"command": item.get("command")},
                    )
                ), "parsed"
            return result_type, payload_to_dict(
                ToolResultPayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    tool_name="command_execution",
                    tool_use_id=item.get("id"),
                    status=item.get("status"),
                    input={"command": item.get("command")},
                    exit_code=item.get("exit_code") if result_type == "tool.result" else None,
                    stderr=item.get("stderr") if result_type == "tool.result" else None,
                    output=item.get("aggregated_output") if result_type == "tool.result" else None,
                )
            ), "parsed"
        if item_type == "mcp_tool_call":
            tool_name = str(item.get("tool", "mcp_tool_call"))
            tool_counts[tool_name] += 1
            if phase == "started":
                return "tool.call", {
                    "actor_type": "agent",
                    "thread_id": self.state.thread_id,
                    "tool_name": tool_name,
                    "tool_use_id": item.get("id"),
                    "status": item.get("status"),
                    "server": item.get("server"),
                    "input": item.get("arguments"),
                }, "parsed"
            return "tool.result", {
                "actor_type": "agent",
                "thread_id": self.state.thread_id,
                "tool_name": tool_name,
                "tool_use_id": item.get("id"),
                "status": item.get("status"),
                "server": item.get("server"),
                "error": item.get("error"),
                "output": item.get("result"),
            }, "parsed"
        if item_type == "web_search":
            tool_counts["web_search"] += 1
            if phase == "started":
                return "tool.call", {
                    "actor_type": "agent",
                    "thread_id": self.state.thread_id,
                    "tool_name": "web_search",
                    "tool_use_id": item.get("id"),
                    "input": {"query": item.get("query"), "action": item.get("action")},
                }, "parsed"
            return "tool.result", {
                "actor_type": "agent",
                "thread_id": self.state.thread_id,
                "tool_name": "web_search",
                "tool_use_id": item.get("id"),
                "output": {"query": item.get("query"), "action": item.get("action")},
            }, "parsed"
        if item_type == "collab_tool_call":
            tool_name = str(item.get("tool", "collab_tool_call"))
            tool_counts[tool_name] += 1
            receiver_ids = item.get("receiver_thread_ids")
            if not isinstance(receiver_ids, list):
                receiver_ids = []
            receiver_ids = [str(value) for value in receiver_ids]
            subagent_threads.update(receiver_ids)
            agents_states_raw = item.get("agents_states")
            agents_states: dict[str, dict[str, Any]] = {}
            if isinstance(agents_states_raw, dict):
                for agent_id, raw_state in agents_states_raw.items():
                    if isinstance(raw_state, dict):
                        agents_states[str(agent_id)] = {
                            "status": raw_state.get("status"),
                            "message": raw_state.get("message"),
                        }
            payload = {
                "actor_type": "agent",
                "thread_id": item.get("sender_thread_id") or self.state.thread_id,
                "tool_name": tool_name,
                "tool_use_id": item.get("id"),
                "phase": phase,
                "status": item.get("status"),
                "sender_thread_id": item.get("sender_thread_id"),
                "receiver_thread_ids": receiver_ids,
                "prompt": item.get("prompt"),
                "agents_states": agents_states,
                "detection_source": "tool_payload",
                "detection_confidence": "high" if tool_name in {"spawn_agent", "wait"} else "medium",
                "raw_ref": item.get("id"),
            }
            subagent_counts[tool_name] += 1
            return "tool.result", payload, "parsed"
        if item_type == "tool_use":
            name = str(item.get("name", "unknown"))
            tool_counts[name] += 1
            payload = {
                "actor_type": "agent",
                "thread_id": self.state.thread_id,
                "tool_name": name,
                "tool_use_id": item.get("id"),
                "input": item.get("input"),
            }
            if name in {"spawn_agent", "send_input", "wait_agent", "close_agent", "resume_agent"}:
                subagent_counts[name] += 1
                return "tool.call", {
                    **payload,
                    "detection_source": "tool_name",
                    "detection_confidence": "high",
                    "raw_ref": item.get("id"),
                }, "parsed"
            return "tool.call", payload, "parsed"
        if item_type == "tool_result":
            name = str(item.get("name", "unknown"))
            tool_counts[name] += 1
            return "tool.result", {
                "actor_type": "agent",
                "thread_id": self.state.thread_id,
                "tool_name": name,
                "tool_use_id": item.get("tool_use_id") or item.get("id"),
                "status": item.get("status"),
                "stderr": item.get("stderr"),
                "error": item.get("error"),
                "output": item.get("output") or item.get("content") or item.get("result"),
            }, "parsed"
        if item_type == "file_change":
            changes = item.get("changes")
            if not isinstance(changes, list):
                changes = []
            normalized_changes: list[FileChange] = []
            for change in changes:
                if isinstance(change, dict):
                    normalized_changes.append(FileChange(kind=str(change.get("kind", "")), path=str(change.get("path", ""))))
            return "file.change", payload_to_dict(
                FileChangePayload(
                    actor_type="agent",
                    thread_id=self.state.thread_id,
                    item_id=item.get("id"),
                    status=item.get("status"),
                    changes=normalized_changes,
                )
            ), "parsed"
        return "raw.unparsed", payload_to_dict(RawPayload(actor_type="agent", thread_id=self.state.thread_id, raw=item)), "best_effort"

    def _extract_message_text(self, item: dict[str, Any]) -> str:
        content = item.get("content")
        if not isinstance(content, list):
            return ""
        parts: list[str] = []
        for chunk in content:
            if isinstance(chunk, dict):
                text = chunk.get("text")
                if isinstance(text, str) and text:
                    parts.append(text)
        return "\n".join(parts).strip()

    def _extract_reasoning_text(self, item: dict[str, Any]) -> str:
        summary = item.get("summary")
        if not isinstance(summary, list):
            return ""
        parts: list[str] = []
        for entry in summary:
            if isinstance(entry, dict):
                text = entry.get("text")
                if isinstance(text, str) and text:
                    parts.append(text)
        return "\n".join(parts).strip()

    def _build_error_payload(self, message: Any, error_type: Any) -> ErrorPayload:
        text = message if isinstance(message, str) else None
        text_links = self._extract_text_links(text)
        payload = ErrorPayload(
            actor_type="agent",
            thread_id=self.state.thread_id,
            message=text,
            error_type=str(error_type) if error_type is not None else None,
            text_links=text_links,
        )
        if text_links is not None:
            payload.request_id = text_links.request_id
            payload.reconnect_attempt = text_links.reconnect_attempt
            payload.reconnect_limit = text_links.reconnect_limit
            payload.is_fallback = text_links.is_fallback
            payload.fallback_from = text_links.fallback_from
            payload.fallback_to = text_links.fallback_to
        return payload

    def _extract_text_links(self, text: Any) -> TextLinksPayload | None:
        if not isinstance(text, str) or not text.strip():
            return None
        links = TextLinksPayload()
        request_match = REQUEST_ID_RE.search(text)
        if request_match:
            links.request_id = request_match.group(1)
        reconnect_match = RECONNECT_RE.search(text)
        if reconnect_match:
            links.reconnect_attempt = int(reconnect_match.group(1))
            links.reconnect_limit = int(reconnect_match.group(2))
        status_match = STATUS_RE.search(text)
        if status_match:
            links.status_code = int(status_match.group(1))
            links.status_text = status_match.group(2)
        url_match = URL_RE.search(text)
        if url_match:
            links.url = url_match.group(1)
            parsed_url = urlparse(links.url)
            links.scheme = parsed_url.scheme or None
            links.host = parsed_url.netloc or parsed_url.hostname or None
        cf_ray_match = CF_RAY_RE.search(text)
        if cf_ray_match:
            links.cf_ray = cf_ray_match.group(1)
        disconnect_match = DISCONNECT_RE.search(text)
        if disconnect_match:
            links.disconnect_reason = disconnect_match.group(1)
        fallback_match = FALLBACK_RE.search(text)
        if fallback_match:
            links.is_fallback = True
            links.fallback_from = self._normalize_transport_name(fallback_match.group(1))
            links.fallback_to = self._normalize_transport_name(fallback_match.group(2))
        if payload_to_dict(links):
            return links
        return None

    def _normalize_transport_name(self, value: str) -> str:
        normalized = value.strip().lower()
        if normalized in {"websocket", "websockets", "ws", "wss"}:
            return "websocket"
        if normalized in {"https", "http"}:
            return normalized
        return normalized


class EventLogFileReader:
    @staticmethod
    def iter_events(path: Path) -> Iterable[CodexEvent]:
        if not path.exists():
            return []
        return _iter_event_lines(path)

    @staticmethod
    def load_events(path: Path) -> list[CodexEvent]:
        return list(EventLogFileReader.iter_events(path))

    @staticmethod
    def load_records(path: Path) -> list[EventRecord]:
        return [event.to_record() for event in EventLogFileReader.load_events(path)]


def _iter_event_lines(path: Path) -> Iterable[CodexEvent]:
    with path.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            payload = json.loads(raw_line)
            if isinstance(payload, dict):
                yield CodexEvent.from_record(EventRecord.from_dict(payload))
