from __future__ import annotations

import fcntl
import json
import os
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from codex_worker.util import ensure_parent, utc_now_iso


@dataclass
class LockPayload:
    pid: int
    hostname: str
    worker_id: str
    started_at: str
    task_file: str
    last_heartbeat_at: str


class TaskFileLock:
    def __init__(self, task_file: Path):
        self.task_file = task_file
        self.path = task_file.parent / f".{task_file.name}.lock"
        self._handle = None

    def __enter__(self) -> "TaskFileLock":
        ensure_parent(self.path)
        self._handle = self.path.open("a+", encoding="utf-8")
        fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._handle is not None:
            self._handle.flush()
            os.fsync(self._handle.fileno())
            fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
            self._handle.close()
            self._handle = None

    def write_payload(self, worker_id: str) -> LockPayload:
        if self._handle is None:
            raise RuntimeError("lock is not held")
        payload = LockPayload(
            pid=os.getpid(),
            hostname=socket.gethostname(),
            worker_id=worker_id,
            started_at=utc_now_iso(),
            task_file=str(self.task_file.resolve()),
            last_heartbeat_at=utc_now_iso(),
        )
        self._handle.seek(0)
        self._handle.truncate()
        self._handle.write(json.dumps(payload.__dict__, sort_keys=True))
        self._handle.flush()
        os.fsync(self._handle.fileno())
        return payload

    def heartbeat(self, worker_id: str) -> LockPayload:
        return self.write_payload(worker_id)

    def read_payload(self) -> dict[str, str] | None:
        if not self.path.exists():
            return None
        text = self.path.read_text(encoding="utf-8").strip()
        if not text:
            return None
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return None
        if not isinstance(payload, dict):
            return None
        return payload
