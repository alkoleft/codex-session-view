from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import threading
import time
import uuid
from collections import Counter
from contextlib import nullcontext
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from codex_worker.console_ui import WorkerConsole
from codex_worker.event_readers import EventLogFileReader, JsonOutputEventReader, JsonOutputState, RunEventContext
from codex_worker.lockfile import TaskFileLock
from codex_worker.logs import RunPaths, append_task_run, update_task_snapshot, write_event, write_summary
from codex_worker.models import ClaimedTask, EventRecord, RunSummary, TaskBlock, WorkerConfig
from codex_worker.task_file import (
    TaskFileError,
    archive_snapshot_if_completed,
    claim_next_task,
    finalize_task,
    has_non_worker_conflict,
    load_snapshot,
    recover_stale_tasks,
    refresh_heartbeat,
    write_snapshot_atomic,
)
from codex_worker.util import process_exists, utc_now_iso


class RunnerError(RuntimeError):
    pass


@dataclass
class SubagentSessionTail:
    thread_id: str
    imported_path: Path
    session_path: Path | None = None
    read_cursor: int = 0
    partial_line: str = ""
    announced: bool = False
    missing_announced: bool = False
    call_names: dict[str, str] = field(default_factory=dict)
    last_lookup_at: float = 0.0


SUBAGENT_SESSION_LOOKUP_RETRY_SECONDS = 1.0
RECENT_SUBAGENT_SESSION_DAY_WINDOW = 3


class CodexWorker:
    def __init__(self, config: WorkerConfig):
        self.config = config
        self.worker_id = str(uuid.uuid4())
        self.ui = WorkerConsole(config) if config.log_to_stdout else None

    def run_next(self) -> int:
        processed_any = False
        session = self.ui if self.ui is not None else nullcontext()
        with session:
            while True:
                claimed = self._claim_next_task()
                if claimed is None:
                    if not processed_any:
                        self._emit("idle", f"no pending tasks in {self.config.task_file}")
                    return 0
                processed_any = True
                exit_code = self._execute_claimed_task(claimed)
                if exit_code != 0:
                    return exit_code

    def _claim_next_task(self) -> ClaimedTask | None:
        task_file = self.config.task_file
        task_file.parent.mkdir(parents=True, exist_ok=True)
        if not task_file.exists():
            raise RunnerError(
                f"Task file was not found.\n"
                f"Path: {task_file}\n"
                f"Pass an existing markdown file via --task-file."
            )
        with TaskFileLock(task_file) as lock:
            lock.write_payload(self.worker_id)
            snapshot = load_snapshot(task_file)
            recovered_content, recovered_ids = recover_stale_tasks(snapshot, self.config.stale_after)
            if recovered_ids:
                self._emit("recovery", f"marked stale tasks as failed: {', '.join(recovered_ids)}")
                write_snapshot_atomic(task_file, recovered_content)
                snapshot = load_snapshot(task_file)
            run_id = str(uuid.uuid4())
            claimed = claim_next_task(snapshot, run_id, self.worker_id)
            if claimed is None:
                return None
            new_content, task = claimed
            write_snapshot_atomic(task_file, new_content)
            latest_snapshot = load_snapshot(task_file)
            fresh_task = next(item for item in latest_snapshot.tasks if item.task_id == task.task_id)
            self._emit_task_banner(fresh_task, run_id)
            self._emit("claim", f"task_id={task.task_id} title={task.title!r} run_id={run_id}")
            return ClaimedTask(
                task=fresh_task,
                run_id=run_id,
                worker_id=self.worker_id,
                worker_pid=os.getpid(),
                snapshot=latest_snapshot,
            )

    def _execute_claimed_task(self, claimed: ClaimedTask) -> int:
        started_at = utc_now_iso()
        logs_root = self.config.logs_dir or claimed.snapshot.path.parent / ".codex-worker"
        paths = RunPaths(logs_root, claimed.task, claimed.run_id, started_at)
        paths.ensure()
        prompt = self._build_prompt(claimed.task)
        paths.prompt.write_text(prompt, encoding="utf-8")
        self._emit("start", f"task_id={claimed.task.task_id} run_id={claimed.run_id} cwd={claimed.task.cwd}")
        if self.ui is not None:
            self.ui.on_start(claimed.task, claimed.run_id)

        summary = RunSummary(task_id=claimed.task.task_id, run_id=claimed.run_id, started_at=started_at)
        summary.paths = {
            "prompt": str(paths.prompt),
            "stdout": str(paths.stdout),
            "stderr": str(paths.stderr),
            "events": str(paths.events),
            "summary": str(paths.summary),
            "subagents_dir": str(paths.subagents_dir),
            "raw_unparsed_dir": str(paths.raw_unparsed_dir),
            "problem_examples_dir": str(paths.problem_examples_dir),
        }
        proc = self._spawn_codex(claimed.task, prompt)
        event_counts: Counter[str] = Counter()
        tool_counts: Counter[str] = Counter()
        subagent_counts: Counter[str] = Counter()
        subagent_threads: set[str] = set()
        subagent_sessions: dict[str, SubagentSessionTail] = {}
        output_reader = JsonOutputEventReader(
            RunEventContext(task_id=claimed.task.task_id, run_id=claimed.run_id),
            JsonOutputState(),
        )
        stream_state = output_reader.state
        seq = 0
        stderr_error: list[str] = []
        stderr_lines: list[str] = []
        out_queue: queue.Queue[tuple[str, str | None]] = queue.Queue()
        stop_heartbeat = threading.Event()

        def reader_thread(pipe, stream_name: str, sink_path: Path):
            try:
                with pipe, sink_path.open("a", encoding="utf-8") as sink:
                    for raw_line in iter(pipe.readline, ""):
                        sink.write(raw_line)
                        sink.flush()
                        out_queue.put((stream_name, raw_line))
            except Exception as exc:  # pragma: no cover
                stderr_error.append(f"{stream_name}_reader_error:{exc}")
            finally:
                out_queue.put((stream_name, None))

        threads = [
            threading.Thread(target=reader_thread, args=(proc.stdout, "stdout", paths.stdout), daemon=True),
            threading.Thread(target=reader_thread, args=(proc.stderr, "stderr", paths.stderr), daemon=True),
        ]
        for thread in threads:
            thread.start()

        hb_thread = threading.Thread(target=self._heartbeat_loop, args=(claimed, stop_heartbeat), daemon=True)
        hb_thread.start()

        closed_streams = set()
        while len(closed_streams) < 2:
            try:
                stream_name, payload = out_queue.get(timeout=0.2)
            except queue.Empty:
                seq = self._sync_subagent_sessions(
                    claimed,
                    paths,
                    seq,
                    event_counts,
                    tool_counts,
                    subagent_counts,
                    subagent_threads,
                    str(stream_state.thread_id or ""),
                    subagent_sessions,
                    final=False,
                )
                continue
            if payload is None:
                closed_streams.add(stream_name)
                seq = self._sync_subagent_sessions(
                    claimed,
                    paths,
                    seq,
                    event_counts,
                    tool_counts,
                    subagent_counts,
                    subagent_threads,
                    str(stream_state.thread_id or ""),
                    subagent_sessions,
                    final=False,
                )
                continue
            if stream_name == "stderr":
                stripped = payload.rstrip("\n")
                stderr_lines.append(stripped)
                seq += 1
                event = EventRecord(
                    schema_version=1,
                    ts=utc_now_iso(),
                    task_id=claimed.task.task_id,
                    run_id=claimed.run_id,
                    seq=seq,
                    event_type="stderr.line",
                    raw_type="stderr",
                    parse_status="parsed",
                    payload={"actor_type": "system", "text": stripped},
                )
                self._write_run_event(paths, event)
                event_counts[event.event_type] += 1
                self._emit("stderr", stripped)
                seq = self._sync_subagent_sessions(
                    claimed,
                    paths,
                    seq,
                    event_counts,
                    tool_counts,
                    subagent_counts,
                    subagent_threads,
                    str(stream_state.thread_id or ""),
                    subagent_sessions,
                    final=False,
                )
                continue
            seq, codex_event = output_reader.parse_main_output_line(
                seq,
                payload,
                tool_counts,
                subagent_counts,
                subagent_threads,
            )
            event = codex_event.to_record()
            self._write_run_event(paths, event)
            event_counts[event.event_type] += 1
            self._emit_event(event)
            seq = self._sync_subagent_sessions(
                claimed,
                paths,
                seq,
                event_counts,
                tool_counts,
                subagent_counts,
                subagent_threads,
                str(stream_state.thread_id or ""),
                subagent_sessions,
                final=False,
            )

        for thread in threads:
            thread.join()
        return_code = proc.wait()
        stop_heartbeat.set()
        hb_thread.join(timeout=5)
        seq = self._sync_subagent_sessions(
            claimed,
            paths,
            seq,
            event_counts,
            tool_counts,
            subagent_counts,
            subagent_threads,
            str(stream_state.thread_id or ""),
            subagent_sessions,
            final=True,
        )

        summary.finished_at = utc_now_iso()
        summary.exit_code = return_code
        summary.event_counts = dict(event_counts)
        summary.tool_counts = dict(tool_counts)
        summary.subagent_counts = dict(subagent_counts)

        failure_reason = None
        failure_analysis = self._analyze_failure(
            return_code,
            stderr_error,
            stderr_lines,
            stream_state,
            paths.problem_examples_dir / "main.jsonl",
        )
        if stderr_error:
            failure_reason = "process_error"
        elif failure_analysis:
            failure_reason = str(failure_analysis.get("failure_reason") or "connection_error")
        elif return_code != 0:
            failure_reason = "process_exit_nonzero"
        elif not stream_state.valid_json:
            failure_reason = "runtime_output_invalid"
        elif not stream_state.saw_thread_started:
            failure_reason = "runtime_output_invalid"
        elif not stream_state.saw_turn_completed:
            failure_reason = "runtime_output_invalid"
        elif stream_state.saw_turn_failed:
            failure_reason = "runtime_output_invalid"
        elif stream_state.saw_top_error:
            failure_reason = "runtime_output_invalid"
        elif stream_state.last_terminal != "turn.completed":
            failure_reason = "runtime_output_invalid"
        elif not stream_state.final_agent_message:
            failure_reason = "runtime_output_invalid"

        if failure_reason:
            summary.status = "failed"
            summary.failure_reason = failure_reason
            summary.failure_analysis = failure_analysis or {}
            finalize_status = "!"
            finalize_result = failure_reason
            exit_code = 1
        else:
            summary.status = "completed"
            finalize_status = "x"
            finalize_result = "success"
            exit_code = 0

        write_summary(paths.summary, summary)
        append_task_run(
            paths.runs_jsonl,
            {
                "task_id": claimed.task.task_id,
                "run_id": claimed.run_id,
                "status": summary.status,
                "failure_reason": summary.failure_reason,
                "started_at": summary.started_at,
                "finished_at": summary.finished_at,
                "summary_path": str(paths.summary),
            },
        )
        task_file_path = self._finalize_task(claimed, finalize_status, finalize_result, summary.failure_reason or "")
        latest = load_snapshot(task_file_path)
        final_task = next(item for item in latest.tasks if item.task_id == claimed.task.task_id)
        update_task_snapshot(paths.task_json, final_task, str(paths.summary))
        self._emit(
            "result",
            f"task_id={claimed.task.task_id} run_id={claimed.run_id} status={summary.status}"
            + (f" reason={summary.failure_reason}" if summary.failure_reason else ""),
        )
        if self.ui is not None:
            self.ui.on_result(
                claimed.task.task_id,
                claimed.task.title,
                claimed.run_id,
                summary.status,
                summary.failure_reason,
            )
        return exit_code

    def _build_prompt(self, task: TaskBlock) -> str:
        template_path = self.config.prompt_template or (Path(__file__).resolve().parents[2] / "prompts" / "orchestrator.md")
        template = template_path.read_text(encoding="utf-8").rstrip()
        extra_prompt = task.metadata.get("prompt", "").strip()
        metadata_lines = [f"{key}: {value}" for key, value in task.metadata.items() if key != "prompt"]
        parts = [
            template,
            "",
            "Task Metadata:",
            *metadata_lines,
            "",
        ]
        if extra_prompt:
            parts.extend(
                [
                    "Additional Instructions:",
                    extra_prompt,
                    "",
                ]
            )
        parts.extend(
            [
            "Task Body:",
            task.body,
            "",
            ]
        )
        return "\n".join(parts).rstrip() + "\n"

    def _write_run_event(self, paths: RunPaths, event: EventRecord) -> None:
        write_event(paths.events, event)
        actor_type = str(event.payload.get("actor_type") or "agent")
        if event.event_type == "raw.unparsed":
            target = "subagents.jsonl" if actor_type == "subagent" else "main.jsonl"
            write_event(paths.raw_unparsed_dir / target, event)
            write_event(paths.problem_examples_dir / target, event)
        elif event.event_type == "error":
            write_event(paths.problem_examples_dir / "main.jsonl", event)

    def _spawn_codex(self, task: TaskBlock, prompt: str) -> subprocess.Popen:
        cwd = Path(task.cwd)
        if not str(cwd):
            cwd = self.config.default_cwd or Path.cwd()
        elif not cwd.is_absolute():
            base = self.config.default_cwd or Path.cwd()
            cwd = (base / cwd).resolve()
        cmd = [self.config.codex_bin, "exec", "--json", "-C", str(cwd), "-"]
        model = task.metadata.get("model") or self.config.model
        sandbox = task.metadata.get("sandbox") or self.config.sandbox
        approval = task.metadata.get("approval_policy") or self.config.approval_policy
        profile = task.metadata.get("profile")
        if model:
            cmd[2:2] = ["--model", model]
        if sandbox:
            cmd[2:2] = ["--sandbox", sandbox]
        if approval:
            cmd[2:2] = ["--ask-for-approval", approval]
        if profile:
            cmd[2:2] = ["--profile", profile]
        if self.config.dry_run:
            raise RunnerError("dry-run is not implemented")
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        assert proc.stdin is not None
        proc.stdin.write(prompt)
        proc.stdin.close()
        return proc

    def _heartbeat_loop(self, claimed: ClaimedTask, stop_event: threading.Event) -> None:
        while not stop_event.wait(max(1.0, min(self.config.stale_after / 3.0, 10.0))):
            with TaskFileLock(self.config.task_file) as lock:
                lock.heartbeat(self.worker_id)
                snapshot = load_snapshot(self.config.task_file)
                new_content = refresh_heartbeat(snapshot, claimed.task.task_id, claimed.worker_id)
                write_snapshot_atomic(self.config.task_file, new_content)

    def _analyze_failure(
        self,
        return_code: int,
        stderr_error: list[str],
        stderr_lines: list[str],
        stream_state: JsonOutputState,
        problem_examples_path: Path,
    ) -> dict[str, Any] | None:
        if stderr_error:
            return None
        texts = list(stderr_lines)
        observed_request_ids: list[str] = []
        observed_cf_rays: list[str] = []
        observed_hosts: list[str] = []
        observed_endpoints: list[str] = []
        observed_statuses: list[int] = []
        observed_reasons: list[str] = []
        transports: list[str] = []
        failure_chain: list[dict[str, Any]] = []
        incident_groups: list[dict[str, Any]] = []
        for raw_error in stream_state.top_errors:
            if isinstance(raw_error, dict):
                message = raw_error.get("message")
                if isinstance(message, str) and message.strip():
                    texts.append(message.strip())
        for raw_error in stream_state.item_errors:
            if isinstance(raw_error, dict):
                message = raw_error.get("message")
                if isinstance(message, str) and message.strip():
                    texts.append(message.strip())
                self._collect_text_link_observations(raw_error.get("text_links"), observed_request_ids, observed_cf_rays, observed_hosts, observed_endpoints, observed_statuses, observed_reasons, transports)
        texts.extend(self._load_problem_example_messages(problem_examples_path))
        failure_chain = self._build_failure_chain(problem_examples_path)
        incident_groups = self._group_failure_chain(failure_chain)
        self._load_problem_example_observations(
            problem_examples_path,
            observed_request_ids,
            observed_cf_rays,
            observed_hosts,
            observed_endpoints,
            observed_statuses,
            observed_reasons,
            transports,
        )
        joined = "\n".join(texts)
        if not joined:
            return None

        if "connect to websocket" not in joined and "unexpected status" not in joined:
            return None

        url_match = re.search(r"(wss?://\S+)", joined)
        status_match = re.search(r"\b(\d{3})\s+([A-Za-z][A-Za-z ]+)", joined)
        endpoint = url_match.group(1).rstrip("),.;]}>\"'") if url_match else None
        http_status = int(status_match.group(1)) if status_match else None
        http_reason = status_match.group(2).strip() if status_match else None

        analysis = {
            "failure_reason": "connection_error",
            "transport": transports[0] if transports else "websocket",
            "stage": "connect",
            "endpoint": observed_endpoints[0] if observed_endpoints else endpoint,
            "message": "Failed to establish Codex websocket connection.",
            "raw_excerpt": self._trim_error_excerpt(joined),
        }
        if return_code != 0:
            analysis["exit_code"] = return_code
        if http_status is not None:
            analysis["http_status"] = http_status
        if http_reason:
            analysis["http_reason"] = http_reason
        if observed_request_ids:
            analysis["request_ids"] = observed_request_ids
        if observed_cf_rays:
            analysis["cf_rays"] = observed_cf_rays
        if observed_hosts:
            analysis["hosts"] = observed_hosts
        if observed_endpoints:
            analysis["endpoints"] = observed_endpoints
        if failure_chain:
            analysis["failure_chain"] = failure_chain
        if incident_groups:
            analysis["incident_groups"] = incident_groups

        if not analysis.get("http_status") and observed_statuses:
            analysis["http_status"] = observed_statuses[0]
        if not analysis.get("http_reason") and observed_reasons:
            analysis["http_reason"] = observed_reasons[0]
        effective_http_status = analysis.get("http_status")

        if effective_http_status == 403:
            analysis["category"] = "authz_forbidden"
            analysis["message"] = "Codex websocket connection was rejected with HTTP 403 Forbidden."
            analysis["hint"] = (
                "Check Codex CLI authentication, workspace access to Codex, and whether proxy or Cloudflare "
                "blocks requests to the Codex websocket endpoint."
            )
        elif effective_http_status == 401:
            analysis["category"] = "authn_required"
            analysis["message"] = "Codex websocket connection was rejected with HTTP 401 Unauthorized."
            analysis["hint"] = "Refresh CLI login or token credentials used by the worker."
        else:
            analysis["category"] = "network_connect"
            analysis["hint"] = "Inspect stderr.log and network path to the Codex websocket endpoint."
        return analysis

    def _load_problem_example_observations(
        self,
        path: Path,
        observed_request_ids: list[str],
        observed_cf_rays: list[str],
        observed_hosts: list[str],
        observed_endpoints: list[str],
        observed_statuses: list[int],
        observed_reasons: list[str],
        transports: list[str],
    ) -> None:
        if not path.exists():
            return
        for event in EventLogFileReader.load_events(path):
            payload = event.payload_obj()
            self._collect_text_link_observations(
                getattr(payload, "text_links", None),
                observed_request_ids,
                observed_cf_rays,
                observed_hosts,
                observed_endpoints,
                observed_statuses,
                observed_reasons,
                transports,
            )

    def _build_failure_chain(self, path: Path) -> list[dict[str, Any]]:
        if not path.exists():
            return []
        chain: list[dict[str, Any]] = []
        for event in EventLogFileReader.load_events(path):
            if event.event_type not in {"error", "agent.turn.failed"}:
                continue
            payload = event.payload_obj()
            raw_links = getattr(payload, "text_links", None)
            links = raw_links.__dict__ if raw_links is not None else {}
            message = getattr(payload, "message", None)
            if not isinstance(message, str) or not message:
                raw_error = getattr(payload, "error", None)
                if isinstance(raw_error, dict):
                    nested_message = raw_error.get("message")
                    if isinstance(nested_message, str):
                        message = nested_message
            chain.append(
                {
                    "event_type": event.event_type,
                    "raw_type": event.raw_type,
                    "message": self._trim_error_excerpt(message or "", 160),
                    "request_id": links.get("request_id"),
                    "status_code": links.get("status_code"),
                    "status_text": links.get("status_text"),
                    "endpoint": links.get("url"),
                    "host": links.get("host"),
                    "transport": self._transport_from_links(links),
                    "reconnect_attempt": links.get("reconnect_attempt"),
                    "reconnect_limit": links.get("reconnect_limit"),
                    "cf_ray": links.get("cf_ray"),
                    "disconnect_reason": links.get("disconnect_reason"),
                    "fallback_to": links.get("fallback_to"),
                }
            )
        return chain

    def _group_failure_chain(self, chain: list[dict[str, Any]]) -> list[dict[str, Any]]:
        grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
        ordered_keys: list[tuple[Any, ...]] = []
        for entry in chain:
            key = (
                entry.get("request_id") or "",
                entry.get("endpoint") or "",
                entry.get("host") or "",
                entry.get("status_code"),
                entry.get("transport") or "",
            )
            if key not in grouped:
                grouped[key] = {
                    "request_id": entry.get("request_id"),
                    "endpoint": entry.get("endpoint"),
                    "host": entry.get("host"),
                    "status_code": entry.get("status_code"),
                    "status_text": entry.get("status_text"),
                    "transport": entry.get("transport"),
                    "fallback_to": entry.get("fallback_to"),
                    "count": 0,
                    "events": [],
                    "cf_rays": [],
                    "reconnect_attempts": [],
                }
                ordered_keys.append(key)
            group = grouped[key]
            group["count"] += 1
            if entry.get("event_type") not in group["events"]:
                group["events"].append(entry.get("event_type"))
            if isinstance(entry.get("cf_ray"), str) and entry["cf_ray"] not in group["cf_rays"]:
                group["cf_rays"].append(entry["cf_ray"])
            reconnect_attempt = entry.get("reconnect_attempt")
            if isinstance(reconnect_attempt, int) and reconnect_attempt not in group["reconnect_attempts"]:
                group["reconnect_attempts"].append(reconnect_attempt)
            if group.get("fallback_to") is None and entry.get("fallback_to") is not None:
                group["fallback_to"] = entry.get("fallback_to")
        return [grouped[key] for key in ordered_keys]

    def _collect_text_link_observations(
        self,
        raw_links: Any,
        observed_request_ids: list[str],
        observed_cf_rays: list[str],
        observed_hosts: list[str],
        observed_endpoints: list[str],
        observed_statuses: list[int],
        observed_reasons: list[str],
        transports: list[str],
    ) -> None:
        if raw_links is None:
            return
        links = raw_links if isinstance(raw_links, dict) else raw_links.__dict__
        self._append_unique_string(observed_request_ids, links.get("request_id"))
        self._append_unique_string(observed_cf_rays, links.get("cf_ray"))
        self._append_unique_string(observed_hosts, links.get("host"))
        self._append_unique_string(observed_endpoints, links.get("url"))
        status_code = links.get("status_code")
        if isinstance(status_code, int) and status_code not in observed_statuses:
            observed_statuses.append(status_code)
        self._append_unique_string(observed_reasons, links.get("status_text"))
        if links.get("scheme") in {"ws", "wss", "websocket"}:
            self._append_unique_string(transports, "websocket")
        elif links.get("scheme") in {"http", "https"}:
            self._append_unique_string(transports, str(links.get("scheme")))
        elif links.get("fallback_from"):
            self._append_unique_string(transports, str(links.get("fallback_from")))

    def _append_unique_string(self, target: list[str], value: Any) -> None:
        if isinstance(value, str) and value and value not in target:
            target.append(value)

    def _transport_from_links(self, links: dict[str, Any]) -> str | None:
        scheme = links.get("scheme")
        if scheme in {"ws", "wss", "websocket"}:
            return "websocket"
        if scheme in {"http", "https"}:
            return str(scheme)
        fallback_from = links.get("fallback_from")
        if isinstance(fallback_from, str) and fallback_from:
            return fallback_from
        return None

    def _load_problem_example_messages(self, path: Path) -> list[str]:
        if not path.exists():
            return []
        messages: list[str] = []
        with path.open("r", encoding="utf-8") as handle:
            for raw_line in handle:
                try:
                    parsed = json.loads(raw_line)
                except Exception:
                    continue
                if not isinstance(parsed, dict):
                    continue
                payload = parsed.get("payload")
                if not isinstance(payload, dict):
                    continue
                raw_payload = payload.get("raw")
                if isinstance(raw_payload, dict):
                    message = raw_payload.get("message")
                else:
                    message = payload.get("message")
                if isinstance(message, str) and message.strip():
                    messages.append(message.strip())
        return messages

    def _trim_error_excerpt(self, text: str, limit: int = 280) -> str:
        collapsed = re.sub(r"\s+", " ", text).strip()
        if len(collapsed) <= limit:
            return collapsed
        return collapsed[: limit - 3] + "..."

    def _sync_subagent_sessions(
        self,
        claimed: ClaimedTask,
        paths: RunPaths,
        seq: int,
        event_counts: Counter[str],
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
        subagent_threads: set[str],
        parent_thread_id: str,
        session_tails: dict[str, SubagentSessionTail],
        final: bool,
    ) -> int:
        if not subagent_threads:
            return seq
        sessions_root = self._sessions_root() / "sessions"
        if not sessions_root.exists():
            if final:
                self._emit("subagent", f"sessions root not found: {sessions_root}")
            return seq
        for thread_id in sorted(subagent_threads):
            tail = session_tails.get(thread_id)
            if tail is None:
                tail = SubagentSessionTail(thread_id=thread_id, imported_path=paths.subagents_dir / f"{thread_id}.jsonl")
                session_tails[thread_id] = tail
            if tail.session_path is None or not tail.session_path.exists():
                now = time.monotonic()
                should_lookup = final or tail.last_lookup_at == 0.0
                if not should_lookup and now - tail.last_lookup_at >= SUBAGENT_SESSION_LOOKUP_RETRY_SECONDS:
                    should_lookup = True
                if should_lookup:
                    tail.last_lookup_at = now
                    tail.session_path = self._find_session_file(sessions_root, thread_id, exhaustive=final)
            if tail.session_path is None:
                if final and not tail.missing_announced:
                    self._emit("subagent", f"session missing thread_id={thread_id}")
                    tail.missing_announced = True
                continue
            if not tail.announced:
                self._emit("subagent", f"session_imported thread_id={thread_id}")
                tail.announced = True
            seq = self._tail_subagent_session(
                claimed,
                paths,
                seq,
                tail,
                event_counts,
                tool_counts,
                subagent_counts,
                parent_thread_id,
                final=final,
            )
        return seq

    def _tail_subagent_session(
        self,
        claimed: ClaimedTask,
        paths: RunPaths,
        seq: int,
        tail: SubagentSessionTail,
        event_counts: Counter[str],
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
        parent_thread_id: str,
        final: bool,
    ) -> int:
        assert tail.session_path is not None
        output_reader = JsonOutputEventReader(
            RunEventContext(task_id=claimed.task.task_id, run_id=claimed.run_id),
            JsonOutputState(thread_id=parent_thread_id),
        )
        tail.imported_path.parent.mkdir(parents=True, exist_ok=True)
        with tail.session_path.open("r", encoding="utf-8") as source:
            source.seek(tail.read_cursor)
            chunk = source.read()
            tail.read_cursor = source.tell()
        if not chunk and not final:
            return seq
        with tail.imported_path.open("a", encoding="utf-8") as imported:
            if chunk:
                imported.write(chunk)
        combined = tail.partial_line + chunk
        if final:
            lines = combined.splitlines()
            tail.partial_line = ""
        else:
            if combined.endswith("\n"):
                lines = combined.splitlines()
                tail.partial_line = ""
            else:
                lines = combined.splitlines()
                tail.partial_line = lines.pop() if lines else combined
        for stripped in lines:
            if not stripped:
                continue
            seq += 1
            ts = utc_now_iso()
            try:
                parsed = json.loads(stripped)
                if not isinstance(parsed, dict):
                    raise ValueError("not an object")
            except Exception:
                event = EventRecord(
                    schema_version=1,
                    ts=ts,
                    task_id=claimed.task.task_id,
                    run_id=claimed.run_id,
                    seq=seq,
                    event_type="raw.unparsed",
                    raw_type="invalid_json",
                    parse_status="unparsed",
                    payload={"actor_type": "subagent", "thread_id": tail.thread_id, "text": stripped},
                )
                self._write_run_event(paths, event)
                event_counts[event.event_type] += 1
                self._emit_event(event)
                continue
            codex_event = output_reader.parse_subagent_session_payload(
                seq,
                parsed,
                tail.imported_path,
                parent_thread_id,
                tail.thread_id,
                tail.call_names,
                tool_counts,
                subagent_counts,
            )
            if codex_event is None:
                seq -= 1
                continue
            event = codex_event.to_record()
            self._write_run_event(paths, event)
            event_counts[event.event_type] += 1
            self._emit_event(event)
        return seq

    def _parse_subagent_session_line(
        self,
        task_id: str,
        run_id: str,
        seq: int,
        parsed: dict[str, Any],
        imported_path: Path,
        parent_thread_id: str,
        thread_id: str,
        call_names: dict[str, str],
        tool_counts: Counter[str],
        subagent_counts: Counter[str],
    ) -> EventRecord | None:
        reader = JsonOutputEventReader(RunEventContext(task_id=task_id, run_id=run_id), JsonOutputState())
        event = reader.parse_subagent_session_payload(
            seq,
            parsed,
            imported_path,
            parent_thread_id,
            thread_id,
            call_names,
            tool_counts,
            subagent_counts,
        )
        return event.to_record() if event is not None else None

    def _sessions_root(self) -> Path:
        if self.config.codex_home is not None:
            return self.config.codex_home
        return Path(os.environ.get("CODEX_HOME", "~/.codex")).expanduser()

    def _find_session_file(self, sessions_root: Path, thread_id: str, exhaustive: bool = False) -> Path | None:
        filename_pattern = f"*{thread_id}*.jsonl"
        for day_dir in self._candidate_session_dirs(sessions_root, exhaustive=exhaustive):
            matches = sorted(day_dir.glob(filename_pattern))
            if matches:
                return matches[-1]
        return None

    def _candidate_session_dirs(self, sessions_root: Path, exhaustive: bool) -> list[Path]:
        if exhaustive:
            return list(self._iter_session_dirs(sessions_root))

        today = datetime.now().date()
        candidates: list[Path] = []
        for offset in range(RECENT_SUBAGENT_SESSION_DAY_WINDOW):
            day = today - timedelta(days=offset)
            day_dir = sessions_root / f"{day.year:04d}" / f"{day.month:02d}" / f"{day.day:02d}"
            if day_dir.is_dir():
                candidates.append(day_dir)
        return candidates

    def _iter_session_dirs(self, sessions_root: Path) -> list[Path]:
        result: list[Path] = []
        try:
            years = sorted((path for path in sessions_root.iterdir() if path.is_dir()), reverse=True)
        except FileNotFoundError:
            return result
        for year_dir in years:
            months = sorted((path for path in year_dir.iterdir() if path.is_dir()), reverse=True)
            for month_dir in months:
                days = sorted((path for path in month_dir.iterdir() if path.is_dir()), reverse=True)
                result.extend(days)
        return result

    def _finalize_task(self, claimed: ClaimedTask, status: str, result: str, error: str) -> Path:
        with TaskFileLock(self.config.task_file) as lock:
            lock.write_payload(self.worker_id)
            snapshot = load_snapshot(self.config.task_file)
            original_task = next(item for item in claimed.snapshot.tasks if item.task_id == claimed.task.task_id)
            current_task = next(item for item in snapshot.tasks if item.task_id == claimed.task.task_id)
            if has_non_worker_conflict(original_task, current_task):
                raise RunnerError("task_file_conflict")
            new_content = finalize_task(snapshot, claimed, status, result, error)
            write_snapshot_atomic(self.config.task_file, new_content)
            archived_path = archive_snapshot_if_completed(self.config.task_file, new_content)
            if archived_path is not None:
                self.config.task_file = archived_path
                return archived_path
            return self.config.task_file

    def _emit(self, kind: str, message: str) -> None:
        if not self.config.log_to_stdout:
            return
        if self.ui is not None:
            self.ui.on_emit(kind, message)

    def _emit_event(self, event: EventRecord) -> None:
        if not self.config.log_to_stdout:
            return
        if self.ui is not None:
            self.ui.on_event(event)

    def _emit_task_banner(self, task: TaskBlock, run_id: str) -> None:
        if not self.config.log_to_stdout:
            return
        if self.ui is not None:
            self.ui.on_claim(task, run_id)
