from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path

from codex_worker.models import ClaimedTask, TaskBlock, TaskFileSnapshot, WORKER_OWNED_METADATA
from codex_worker.util import process_exists, sha256_text, slugify, utc_now_iso


TASK_HEADING_PATTERN = re.compile(r"^(?P<level>#+) \[(?P<status>[ >x!])\] (?P<title>.+?)\s*$")


class TaskFileError(RuntimeError):
    pass


def load_snapshot(path: Path) -> TaskFileSnapshot:
    content = path.read_text(encoding="utf-8")
    stat = path.stat()
    tasks = parse_tasks(content)
    ids = [task.task_id for task in tasks]
    duplicates = sorted({task_id for task_id in ids if ids.count(task_id) > 1})
    if duplicates:
        raise TaskFileError(f"duplicate task ids: {', '.join(duplicates)}")
    return TaskFileSnapshot(
        path=path,
        content=content,
        tasks=tasks,
        sha256=sha256_text(content),
        mtime_ns=stat.st_mtime_ns,
    )


def parse_tasks(content: str) -> list[TaskBlock]:
    lines = content.splitlines(keepends=True)
    offsets: list[int] = []
    cursor = 0
    for line in lines:
        offsets.append(cursor)
        cursor += len(line)

    headers: list[tuple[int, re.Match[str]]] = []
    for index, line in enumerate(lines):
        match = TASK_HEADING_PATTERN.match(line.rstrip("\n"))
        if match:
            headers.append((index, match))

    raw_tasks: list[dict[str, object]] = []
    used_ids: set[str] = set()
    for position, (line_index, match) in enumerate(headers):
        next_index = headers[position + 1][0] if position + 1 < len(headers) else len(lines)
        start = offsets[line_index]
        end = offsets[next_index] if next_index < len(lines) else len(content)
        block_lines = [line.rstrip("\n") for line in lines[line_index:next_index]]
        status = match.group("status")
        title = match.group("title").strip()
        metadata: dict[str, str] = {}
        explicit_metadata_keys: set[str] = set()

        body_start = 1
        while body_start < len(block_lines):
            line = block_lines[body_start]
            if not line.strip():
                body_start += 1
                break
            if ":" not in line:
                break
            key, value = line.split(":", 1)
            key = key.strip()
            if not key or any(ch.isspace() for ch in key):
                break
            metadata[key] = value.strip()
            explicit_metadata_keys.add(key)
            body_start += 1

        body = "\n".join(block_lines[body_start:]).rstrip()
        raw_tasks.append(
            {
                "title": title,
                "status": status,
                "metadata": metadata,
                "explicit_metadata_keys": explicit_metadata_keys,
                "body": body,
                "raw_text": content[start:end],
                "start": start,
                "end": end,
                "position": position,
            }
        )
        if "id" in metadata:
            used_ids.add(metadata["id"])

    tasks: list[TaskBlock] = []
    generated_ids: dict[str, int] = {}
    for raw_task in raw_tasks:
        metadata = dict(raw_task["metadata"])  # type: ignore[arg-type]
        if "id" not in metadata:
            base = slugify(str(raw_task["title"]))
            candidate = base
            next_suffix = generated_ids.get(base, 0)
            while not candidate or candidate in used_ids:
                next_suffix += 1
                candidate = f"{base}-{next_suffix}" if base else f"task-{next_suffix}"
            generated_ids[base] = next_suffix
            metadata["id"] = candidate
            used_ids.add(candidate)
        tasks.append(
            TaskBlock(
                title=str(raw_task["title"]),
                status=str(raw_task["status"]),
                metadata=metadata,
                explicit_metadata_keys=set(raw_task["explicit_metadata_keys"]),  # type: ignore[arg-type]
                body=str(raw_task["body"]),
                raw_text=str(raw_task["raw_text"]),
                start=int(raw_task["start"]),
                end=int(raw_task["end"]),
            )
        )

    return tasks


def serialize_task(task: TaskBlock) -> str:
    heading = f"## [{task.status}] {task.title}"
    parts = [heading]

    metadata_lines: list[str] = []
    explicit_keys = [key for key in task.metadata.keys() if key in task.explicit_metadata_keys]
    for key in explicit_keys:
        metadata_lines.append(f"{key}: {task.metadata[key]}")

    for key in ("id", "cwd"):
        if key in task.metadata and key not in task.explicit_metadata_keys:
            metadata_lines.append(f"{key}: {task.metadata[key]}")

    for key in task.metadata.keys():
        if key in WORKER_OWNED_METADATA and key not in task.explicit_metadata_keys:
            metadata_lines.append(f"{key}: {task.metadata[key]}")

    if metadata_lines:
        parts.extend(metadata_lines)
        if task.body:
            parts.append("")
    elif task.body:
        parts.append("")

    if task.body:
        parts.append(task.body.rstrip())

    return "\n".join(parts).rstrip() + "\n"


def write_snapshot_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
        dir_fd = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def archive_snapshot_if_completed(path: Path, content: str) -> Path | None:
    tasks = parse_tasks(content)
    if not tasks or any(task.status != "x" for task in tasks):
        return None

    archive_dir = path.parent / "archive"
    archive_dir.mkdir(parents=True, exist_ok=True)
    target = archive_dir / path.name
    if target.exists():
        stem = path.stem
        suffix = path.suffix
        index = 1
        while target.exists():
            target = archive_dir / f"{stem}-{index}{suffix}"
            index += 1

    os.replace(path, target)

    source_dir_fd = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(source_dir_fd)
    finally:
        os.close(source_dir_fd)

    target_dir_fd = os.open(target.parent, os.O_DIRECTORY)
    try:
        os.fsync(target_dir_fd)
    finally:
        os.close(target_dir_fd)

    return target


def apply_task_update(snapshot: TaskFileSnapshot, task_id: str, updater) -> str:
    target = next((task for task in snapshot.tasks if task.task_id == task_id), None)
    if target is None:
        raise TaskFileError(f"task not found: {task_id}")

    updated = updater(
        TaskBlock(
            title=target.title,
            status=target.status,
            metadata=dict(target.metadata),
            explicit_metadata_keys=set(target.explicit_metadata_keys),
            body=target.body,
            raw_text=target.raw_text,
            start=target.start,
            end=target.end,
        )
    )
    prefix = snapshot.content[: target.start]
    suffix = snapshot.content[target.end :]
    separator = "" if not prefix or prefix.endswith("\n") else "\n"
    return prefix + separator + serialize_task(updated) + suffix


def claim_next_task(snapshot: TaskFileSnapshot, run_id: str, worker_id: str) -> tuple[str, TaskBlock] | None:
    available = next((task for task in snapshot.tasks if task.status in {" ", ">"}), None)
    if available is None:
        return None

    def updater(task: TaskBlock) -> TaskBlock:
        task.status = ">"
        task.metadata["last_run_id"] = run_id
        task.metadata["last_started_at"] = utc_now_iso()
        task.metadata["last_heartbeat_at"] = task.metadata["last_started_at"]
        task.metadata["last_result"] = "running"
        task.metadata["last_error"] = ""
        task.metadata["lease_owner"] = worker_id
        task.metadata["lease_pid"] = str(os.getpid())
        return task

    return apply_task_update(snapshot, available.task_id, updater), available


def finalize_task(
    snapshot: TaskFileSnapshot,
    claimed: ClaimedTask,
    status: str,
    result: str,
    error: str = "",
) -> str:
    def updater(task: TaskBlock) -> TaskBlock:
        owner = task.metadata.get("lease_owner")
        run_id = task.metadata.get("last_run_id")
        if owner != claimed.worker_id or run_id != claimed.run_id:
            raise TaskFileError("claim ownership changed before finalize")
        task.status = status
        task.metadata["last_finished_at"] = utc_now_iso()
        task.metadata["last_result"] = result
        task.metadata["last_error"] = error
        task.metadata["last_heartbeat_at"] = task.metadata["last_finished_at"]
        return task

    return apply_task_update(snapshot, claimed.task.task_id, updater)


def refresh_heartbeat(snapshot: TaskFileSnapshot, task_id: str, worker_id: str) -> str:
    def updater(task: TaskBlock) -> TaskBlock:
        if task.metadata.get("lease_owner") != worker_id:
            raise TaskFileError("claim ownership changed before heartbeat")
        task.metadata["last_heartbeat_at"] = utc_now_iso()
        return task

    return apply_task_update(snapshot, task_id, updater)


def recover_stale_tasks(snapshot: TaskFileSnapshot, stale_after: float) -> tuple[str, list[str]]:
    content = snapshot.content
    recovered: list[str] = []
    for task in snapshot.tasks:
        if task.status != ">":
            continue
        heartbeat = task.metadata.get("last_heartbeat_at")
        pid = int(task.metadata.get("lease_pid", "0") or "0")
        if heartbeat is None:
            stale = True
        else:
            try:
                from datetime import datetime, timezone

                beat_dt = datetime.fromisoformat(heartbeat.replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - beat_dt).total_seconds()
                stale = age > stale_after
            except ValueError:
                stale = True
        if process_exists(pid) and not stale:
            continue
        if not stale and not process_exists(pid):
            stale = True
        if not stale:
            continue

        def updater(current: TaskBlock) -> TaskBlock:
            current.status = "!"
            current.metadata["last_finished_at"] = utc_now_iso()
            current.metadata["last_result"] = "worker_interrupted"
            current.metadata["last_error"] = "stale_running_recovered"
            return current

        temp_snapshot = TaskFileSnapshot(
            path=snapshot.path,
            content=content,
            tasks=parse_tasks(content),
            sha256=sha256_text(content),
            mtime_ns=snapshot.mtime_ns,
        )
        content = apply_task_update(temp_snapshot, task.task_id, updater)
        recovered.append(task.task_id)
    return content, recovered


def has_non_worker_conflict(old_task: TaskBlock, new_task: TaskBlock) -> bool:
    if old_task.title != new_task.title or old_task.body != new_task.body or old_task.status != new_task.status:
        return True
    old_non = {
        k: v
        for k, v in old_task.metadata.items()
        if k not in WORKER_OWNED_METADATA and (k in old_task.explicit_metadata_keys or k not in {"id", "cwd"})
    }
    new_non = {
        k: v
        for k, v in new_task.metadata.items()
        if k not in WORKER_OWNED_METADATA and (k in new_task.explicit_metadata_keys or k not in {"id", "cwd"})
    }
    return old_non != new_non
